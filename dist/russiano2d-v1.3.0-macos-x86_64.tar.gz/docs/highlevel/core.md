# Ядро — `$`, `ctx` и реестр узлов

`$` — единственная точка входа (философия в [ARCHITECTURE.md](../ARCHITECTURE.md)):
любой вызов возвращает один и тот же wrapper, поэтому работают цепочки; создание
как в HTML, поиск как в CSS.

```js
const hero = $('<player>', { id: 'hero' }).at(100, 200).appendTo($.world);
$('#hero').hp(100).speed(180);          // цепочка возвращает тот же узел
$('.enemy:alive').each((i, el) => el.flash('#f00'));
$('.enemy').within('#hero', 500);       // выборка в радиусе (нативный broadphase)
```

---

## 1. Что экспортирует модуль

| Группа | Имена |
|---|---|
| Контекст | `ctx` — общий контекст подсистем (реестр, камера, время, сети подсистем) |
| Узлы | `Node`, `Wrapper`, `wrap`, `wrapOne`, `query`, `def`, `defGet` |
| Реестр | `registryIndex`, `nodesByTag`, `nodesByClass`, `nodesWithFacet`, `facetCount`, `liveNodes`, `dropFromRegistry`, `touchRegistry`, `registryVersion`, `registrySummary`, `nativeNodes`, `wrapper_proto_ready` |
| Пакетная правка | `beginBatch`, `endBatch`, `inBatch` |
| Выборки | `registerSelector`, `compileSelector`, `TAGS` |
| Радиус | `withinRadius` — чистая фильтрация «центр в радиусе» (метод обёртки `.within()`) |
| Геометрия | `halfExtents`, `nodeBounds`, `boundsOverlap` |
| Спрайты | `dotSprite`, `resolveSprite`, `resolveSheet`, `sheetFrames`, `spriteSize`, `forgetTexture`, `textureSizeOf`, `regionSprite` |
| Цвет | `packColor`, `withAlpha` |
| Случайность | `makeRandom`, `fxRandom` |
| §39 трансформы | `isLocalSpace`, `enterLocalSpace`, `exitLocalSpace`, `resolveLocalTransforms`, `installTransformResolution`, `worldTransformOf`, `worldPointOf`, `localPointOf`, `setWorldPosition`, `setWorldAngle`, `setWorldScale`, `worldScaleOf`, `invalidateNodeTransform` |
| §40 области | `areaDefine`, `areaEnable`, `areaFind`, `areaListOf`, `areaByIndex`, `areaInfo`, `areaOwnerNode`, `areaOverlap`, `applyAreas`, `areaNativeEnabled`, `areaSync`, `areaSyncAll` |
| Прочее | `eventName`, `engineOf`, `countUiNodes` |

`engineOf()` — безопасная заглушка движка: подсистемы берут движок через неё,
поэтому API ставится и без движка (юнит-тесты).

## 2. Реестр узлов

Реестр — источник правды о живых узлах: `liveNodes()` отдаёт их списком,
`registrySummary(key, compute)` кеширует дорогие выборки до изменения реестра.
`beginBatch()`/`endBatch()` откладывают пересчёт индексов при массовой правке.

## 3. Facets

Facet — общий признак узлов (`hp`, `body`, …): `nodesWithFacet('hp')` даёт все
узлы с этим полем, не перебирая классы. Так подсистемы находят «всё живое» и
«всё с телом», не зная конкретных классов игры.

## 4. Ограничения

* **реестр линейный по узлам**: миллионы узлов не предполагаются; для больших
  миров используйте `$.raid` со стримингом чанков;
* **селекторы разбираются при каждом вызове** (кроме зарегистрированных):
  в горячем цикле держите ссылку на узел;
* **`ctx` — общий объект**: подсистемы дописывают в него свои поля, поэтому
  имена уникальны на весь API (см. `docs/highlevel/_CONTRACT.md`).

### 4.1. `$.ctx` — контекст ядра (внутреннее)

`$.ctx` — объект, через который подсистемы `$` видят друг друга: реестры узлов,
состояние кадра, ссылки на установленные модули и служебные функции ядра.

**Это не контракт игры.** Имена видимы публично (их читают DevTools, агент,
отладчик и сам движок), поэтому они перечислены здесь целиком — но семантика
внутренняя и меняется вместе с подсистемами. Игре нужен `$` и его
документированные неймспейсы; `$.ctx` — для инструментов и кода подсистем.

#### Ссылки на подсистемы

После установки модуля в `$.ctx` лежит тот же объект, что и в `$.<имя>`
(`$.ctx.world === $.world`):

| Поле | Что это |
|---|---|
| `$.ctx.agent` | `$.agent` — снимок мира и описания узлов для агента |
| `$.ctx.alive` | `$.alive` — живность, директор, психика |
| `$.ctx.audio` | `$.audio` — шины, эффекты, акустика |
| `$.ctx.barks` | `$.barks` — реплики |
| `$.ctx.camera` | `$.camera` — камеры, зум, тряска |
| `$.ctx.cels` | `$.cels` — cel-анимации |
| `$.ctx.collision` | `$.collision` — имена слоёв коллизий |
| `$.ctx.combat` | `$.combat` — урон, здоровье |
| `$.ctx.console` | `$.console` — команды и история консоли |
| `$.ctx.csv` | `$.csv` — разбор CSV |
| `$.ctx.curve` | `$.curve` — кривые и градиенты |
| `$.ctx.debug` | `$.debug` — счётчики, оверлей, профилировщик |
| `$.ctx.devtools` | `$.devtools` — панели F1/F2 |
| `$.ctx.dialog` | `$.dialog` — диалоги |
| `$.ctx.expect` | `$.expect` — проверки-ожидания |
| `$.ctx.font` | `$.font` — шрифты |
| `$.ctx.fs` | `$.fs` — файлы |
| `$.ctx.fx` | `$.fx` — ленты, молнии, поля сил |
| `$.ctx.gfx` | `$.gfx` — отрисовка |
| `$.ctx.grid` | `$.grid` — сетки |
| `$.ctx.hits` | `$.hits` — хит-фидбек |
| `$.ctx.http` | `$.http` — HTTP-клиент |
| `$.ctx.i18n` | `$.i18n` — переводы |
| `$.ctx.input` | `$.input` — ввод |
| `$.ctx.items` | `$.items` — предметы и инвентарь |
| `$.ctx.loading` | `$.loading` — экраны загрузки |
| `$.ctx.math` | `$.math` — математика |
| `$.ctx.nav` | `$.nav` — навигация |
| `$.ctx.net` | `$.net` — сетевой слой |
| `$.ctx.pool` | `$.pool` — пулы объектов |
| `$.ctx.proc` | `$.proc` — процедурная генерация |
| `$.ctx.quest` | `$.quest` — задания |
| `$.ctx.raid` | `$.raid` — стриминг чанков |
| `$.ctx.random` | `$.random` — ГПСЧ, потоки, шум |
| `$.ctx.reload` | `$.reload` — горячая перезагрузка ассетов |
| `$.ctx.resource` | `$.resource` — ресурсы и запросы |
| `$.ctx.room` | `$.room` — комнаты |
| `$.ctx.save` | `$.save` — слоты и снимки |
| `$.ctx.scene` | `$.scene` — сцены и области |
| `$.ctx.screen` | `$.screen` — эффекты экрана |
| `$.ctx.script` | `$.script` — перезапуск скриптов |
| `$.ctx.sound` | `$.sound` — звук |
| `$.ctx.soundBank` | `$.soundBank` — банки звуков |
| `$.ctx.steps` | `$.steps` — шаги-подсказки |
| `$.ctx.store` | `$.store` — key-value хранилище |
| `$.ctx.story` | `$.story` — сюжетные скрипты |
| `$.ctx.task` | `$.task` — кооперативные задачи |
| `$.ctx.test` | `$.test` — самопроверки игры |
| `$.ctx.tilemap` | `$.tilemap` — тайлмапы |
| `$.ctx.time` | `$.time` — время, таймеры, hit-stop |
| `$.ctx.ui` | `$.ui` — RmlUi-интерфейс |
| `$.ctx.weapons` | `$.weapons` — оружие |
| `$.ctx.world` | `$.world` — мир и физика |

#### Реестры и состояние мира

| Поле | Что это |
|---|---|
| `$.ctx.nodes` | все живые узлы мира в порядке создания (`liveNodes()` — его копия) |
| `$.ctx.byId` | `Map` «id → узел» для `$('#hero')` и `$.ctx.byId.get(id)` |
| `$.ctx.byBody` | `Map` «индекс тела Box2D → узел»: по нему лучи и контакты находят узел |
| `$.ctx.timers` | активные таймеры `$.time.after/every` |
| `$.ctx.animations` | активные анимации времени |
| `$.ctx.hovered` | узел под курсором (мир, не интерфейс) — обновляет кадровый шаг |
| `$.ctx.frame` | состояние кадра: `started`, очереди `ready/update/render`, счётчики |
| `$.ctx.roomState` | текущая комната (`$.room.current()` собирает её из этого поля) |
| `$.ctx.scope_current` | область владения, внутри которой создаётся узел (см. §7) |
| `$.ctx.tagAliases` | `Map` «алиас тега → канонический тег» (`$.aliasTag`, `ru.js`) |
| `$.ctx.fx_fields` | поля сил `$.fx` текущего кадра |
| `$.ctx.audio_spatial` | имя активного пространственного аудио-режима (`$.audio`) |

#### Служебные функции

| Функция | Что делает |
|---|---|
| `$.ctx.$` | сам `$` — селектор и конструктор узлов |
| `$.ctx.defineTag(name, defaults)` | регистрирует тег (канонический или алиас) |
| `$.ctx.normalizeKind(kind)` | приводит `kind` узла к известному значению |
| `$.ctx.engineFrame()` | номер кадра движка (даже там, где нет `$,` — для replay) |
| `$.ctx.log(message)` | строка в журнал движка (`$.log` — обёртка над ней) |
| `$.ctx.reportError(where, error)` | структурированная ошибка в диагностику |
| `$.ctx.watch(...)` | регистрация наблюдения (`$.debug.watch`) |
| `$.ctx.tweens_active()` | сколько твинов живо сейчас |
| `$.ctx.scopeEnsure(name, opts)` | область по имени, создавая при отсутствии |
| `$.ctx.scopeGet(name)` | область по имени или `null` |
| `$.ctx.scopeTrack(node)` | привязать узел к области владения |
| `$.ctx.translateAttrsHook` | перевод атрибутов на русские имена (`ru.js`) |

Гейт `tests/api_docs_sync_test.py` следит, чтобы имена отсюда не остались без
упоминания в документации; таблицы выше — его источник для `$.ctx`.

## 5. Свойства тела у узла

Тело узла настраивается цепочкой: `.body(kind)`, `.bullet(on)` (CCD),
`.gravity(on)`, `.layerBits(bits)` (слой тела) и `.mask(bits)` (с какими слоями
сталкиваться). Флаги хранятся на узле (`bullet_on`, `gravity_on`), поэтому тело,
пересозданное после смены размера, получает те же настройки.

Слоям можно давать имена — `$.collision` (`collision.js`): после
`$.collision.define('walls', 0x1)` работают `.layerName('walls')`,
`.maskBy('walls|enemies')` и `$.collision.mask('all|!enemies')`; список имён —
`$.collision.names()`.

## 6. Локальные трансформы (§39)

`x/y/angle/scale_x/scale_y` узла — **мировой** трансформ: их читают отрисовка,
физика и старый игровой код. В локальном режиме (`local_mode === true`) узел
хранит исходные локальные значения в `local_x/local_y/local_angle/
local_scale_x/local_scale_y`, а в тех же мировых полях лежит результат
композиции по цепочке родителей:

```
angle = angle_родителя + local_angle
scale = scale_родителя * local_scale        (знак сохраняется: flip зеркалит)
point = parent + R(angle_родителя) * (local_xy * scale_родителя)
```

Поэтому ни одна подсистема не меняется: рендер и физика читают прежние поля.
Неравномерный масштаб родителя масштабирует сдвиг по своим осям, но не даёт
shear — произвольный наклон запрещён (§39).

Экспорт (используется `api.js` и тестами без движка):

| Имя | Смысл |
|---|---|
| `isLocalSpace(node)` | включён ли у узла локальный режим |
| `enterLocalSpace(node)` / `exitLocalSpace(node)` | включить (keep-world) / выключить |
| `resolveLocalTransforms()` | кадровый пакетный проход; возвращает число изменённых |
| `installTransformResolution()` | регистрация прохода в движке (`engine.setResolveTransforms`) |
| `worldTransformOf(node, out?)` | мировой трансформ `{ x, y, angle, sx, sy }` |
| `worldPointOf(node, lx, ly)` / `localPointOf(node, wx, wy)` | точка туда/обратно |
| `setWorldPosition/setWorldAngle/setWorldScale(node, …)` | запись МИРОВОГО значения (обратная композиция) |
| `worldScaleOf(node)` | скомпонованный масштаб (для `.flip()`) |
| `invalidateNodeTransform(node)` | пометить поддерево устаревшим и пересчитать узел |

Проход идёт по списку локальных узлов (`local_nodes`), а не по реестру: в
проекте без локальных узлов он выходит на первой строке и ничего не стоит.
Поколение (`local_gen`) и поля `_t_gen`/`_t_busy` не дают считать узел дважды и
**защищают от цикла** в цепочке родителей. Если локальных узлов нет, запись
мирового трансформа не платит даже за обход детей (проверка длины списка).

Нативный проход — `engine.nodes.resolveTransforms(list, gen, cb)`; без движка
(юнит-тест qjs, `$.debug.nativePasses(false)`) работает тот же алгоритм на JS.
Движок зовёт проход в конце кадра логики и перед отрисовкой (`src/script.c`),
поэтому к следующему физическому шагу и к сборке кадра дети уже скомпонованы;
локальный ребёнок с телом ставится в мировую точку через `cb`.

## 7. Области узла (§40)

Описания областей — данные узла (`node.area_list`), нативные формы — на теле.
Экспорт: `areaDefine`, `areaEnable`, `areaFind`, `areaListOf`, `areaByIndex`,
`areaInfo`, `areaOwnerNode`, `areaOverlap`, `applyAreas` (пересборка форм после
создания тела). Внутреннее представление — compound shapes: `applyAreas` зовёт
`engine.setShape`/`engine.addShape`, а `enabled: false` реализуется нулевым
фильтром через `engine.setShapeEnabled`, поэтому gameplay от представления не
зависит (§40).

`areaOverlap` — явный геометрический запрос (`engine.shapeOverlaps`), а не
история событий: цель, уже стоящая внутри при открытии окна атаки, находится
сразу. `index` области переживает пересборку формы — дедупликация попаданий в
игре опирается на имя области и окно атаки, а не на handle.

Фильтр запроса — **односторонний, по маске области**: у запроса нет своего
слоя, поэтому решает только `mask` области, а маска ЦЕЛИ не участвует. Это то
же правило, что у `$.world.raycast` и `$.world.queryPoint/Box/Circle`
(`r2d__query_filter`: категория запроса — все биты). Раньше фильтр области был
двусторонним (как у коллизий Box2D), и маска чужого тела решала, увидит ли его
моя область: цель со слоем `0x2` и маской `0x1|0x4` не находилась областью со
слоем `0x8`, хотя область её видит (A3 отчёта BASHNYA). Правило и исключение
(тело с маской `0` не отдаётся ни одному запросу) — в
[collision.md](collision.md) §5; прежний двусторонний режим остался доступен
явно: `.areaOverlap('hurt', { both: true })`. Приёмка —
`tests/agent/area_overlap_filter_test.py`.

Источник истины о состоянии области — **нативный фильтр формы**:
`engine.shapeEnabled(body, index)` читает его, а выключенную форму не возвращает
и сам запрос пересечений. Если форму переключил внешний драйвер (дорожка
`shape.enabled` §41) напрямую через `engine.setShapeEnabled`, JS-описание
подтягивается при чтении: `areaSync`/`areaSyncAll`/`areaNativeEnabled`, поэтому
`.areas()` и `.areaOverlap()` не расходятся с native-состоянием.


