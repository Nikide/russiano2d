# Сторонние компоненты и их лицензии

Russiano2D собирается из исходников и тянет зависимости через CMake
`FetchContent` (см. `cmake/Dependencies.cmake` и `cmake/Shaders.cmake`).
Ниже — что именно используется, под какой лицензией и где это закреплено.

Документ описывает **сторонние** компоненты. Лицензия самого движка —
авторская и лежит в `LICENSE`: использовать, менять и распространять свободно.

## Сводная таблица

| Компонент | Версия / пин | Лицензия |
|---|---|---|
| SDL3 | `release-3.4.16` | zlib |
| SDL3_image | `release-3.4.8` (`0891fc3`) | zlib |
| SDL3_mixer | `release-3.2.4` (`72a8186`) | zlib |
| QuickJS-ng | `v0.10.1` (`3c9afc9`) | MIT |
| Box2D | `v3.1.1` (`8c66146`) | MIT |
| RmlUi | `6.3` (`ba95ffe`) | MIT |
| Dear ImGui | ветка `docking` (`64944b4`) | MIT |
| trylock/visibility | `master` (`71eb5c0`) | MIT |
| glslang | `16.6.0` | Apache-2.0 (части — BSD-3-Clause / MIT) |
| SPIRV-Cross | `vulkan-sdk-1.4.363.0` | Apache-2.0 |
| Noto Sans | файл в репозитории | SIL OFL 1.1 |
| LatoLatin | файл в репозитории | SIL OFL 1.1 |
| Material Design Icons | шрифт `MaterialIcons-Regular.ttf`, коммит `737e332` | Apache-2.0 |

Все библиотеки берутся из своих официальных репозиториев при сборке
(`cmake/Dependencies.cmake`, `cmake/Shaders.cmake`) — тексты их лицензий
распространяются вместе с исходниками, а уведомления обязаны сохраняться в
поставке. Шрифты и иконки лежат в репозитории вместе с текстами лицензий
(`assets/fonts/LICENSE-*.txt`).

Состав и лицензии сверены с `README.md` (раздел «Лицензии сторонних
компонентов») и с `cmake/Dependencies.cmake` / `cmake/Shaders.cmake`.

## Что именно попадает в сборку

### SDL3 — zlib
Платформа, окно, ввод, тайминги и SDL_GPU (Vulkan / Metal / DirectX 12).
Если системный SDL3 не найден, CMake собирает `release-3.4.16` из исходников.
Бинарник распространяется под zlib — текст лицензии разрешает использование
в проприетарных продуктах при сохранении уведомления.

### SDL3_image — zlib
Загрузка PNG/BMP/TGA/GIF/QOI. Подмодули ограничены нужным набором:
`external/jpeg`, `external/libpng`, `external/zlib`. Вместе с ними в сборку
приходят их собственные лицензии:

| Встроенная библиотека | Лицензия |
|---|---|
| zlib | zlib |
| libpng | libpng-2.0 |
| libjpeg (из набора SDL_image) | IJG (BSD-подобная) |

Тяжёлые форматы (AVIF, JXL, TIFF, WebP, SVG) отключены и не собираются.

### SDL3_mixer — zlib
Звук и музыка (WAV, OGG, MP3). Подмодули: `external/ogg` и `external/vorbis`
(оба под BSD-3-Clause). MP3 декодируется через `dr_mp3` — заголовочную
библиотеку в составе SDL_mixer (public domain / MIT-0), поэтому libmpg123
не тянется. Прочие кодеки (FLAC, Opus, MOD, MIDI, GME, WavPack) отключены.

### QuickJS-ng — MIT
Скриптовый рантайм. Статическая библиотека `qjs` линкуется в движок,
компилятор `qjsc` используется при `R2D_EMBED_SCRIPTS=ON`.

### Box2D — MIT
Физика v3 (чистый C).

### RmlUi — MIT
Игровой GUI. Собираются ядро и бэкенды под SDL_GPU (файлы бэкендов
компилируются из `Backends/` напрямую, см. `src/CMakeLists.txt`).

### Dear ImGui — MIT
Отладочный оверлей, ветка docking. Собирается как исходники без
upstream-CMakeLists.

### trylock/visibility — MIT
Полигоны видимости (2D-свет и тени). Используются только заголовки,
C-обёртка — `src/light.cpp`.

### glslang и SPIRV-Cross — Apache-2.0
Инструменты сборки шейдеров: GLSL → SPIR-V (`glslangValidator`) и
SPIR-V → MSL (`spirv-cross`). В **готовый бинарник не попадают** — работают
только на этапе сборки и генерируют `src/generated/shaders.h`. glslang
включает отдельные файлы под BSD-3-Clause и MIT; при распространении
уведомление Apache-2.0 и уведомления этих файлов должны сохраняться.

### Шрифты — SIL OFL 1.1
- **Noto Sans** — `assets/fonts/NotoSans-Regular.ttf`,
  полный текст: `assets/fonts/LICENSE-NotoSans.txt`.
- **LatoLatin** — `assets/fonts/LatoLatin-Regular.ttf`,
  полный текст: `assets/fonts/LICENSE-Lato.txt`. Это подмножество только
  с латиницей: кириллица в нём не отрисуется.

Шрифты распространяются по SIL OFL 1.1: их можно встраивать и поставлять
вместе с продуктом, в том числе проприетарным. Если шрифт **изменяется**,
OFL требует распространять его под другим именем.

### Material Design Icons — Apache-2.0
Шрифт `MaterialIcons-Regular.ttf` и таблица `.codepoints` не лежат в
репозитории: `cmake/Icons.cmake` скачивает их с конкретного коммита
`google/material-design-icons` и проверяет SHA256. Шрифт встраивается в
исполняемый файл байтами, поэтому уведомление Apache-2.0 в релизной сборке
сохраняется (см. раздел «Что нужно сделать до релиза»).

## Ассеты

| Что | Происхождение | Статус |
|---|---|---|
| `assets/icons/russiano2d.png`, `assets/icons/russiano.ico` | материалы владельца проекта | права заявлены владельцем |
| `assets/audio/**` (OGG) | подготовлены инструментами репозитория; исходники — вне репозитория | **происхождение не подтверждено** |
| `demos/assets/art/**` | `tools/make_demo_assets.py` из исходных листов, лежащих вне репозитория (`R2D_SOURCE_ART`) | **происхождение не подтверждено** |
| Текстуры/атласы, генерируемые `tools/make_wall_textures.py`, `tools/make_atlas.py`, `tools/make_demo_assets.py` | генерируются из исходников | зависит от исходников |

README заявляет лишь то, что «иконка приложения и иллюстрация для README —
материалы владельца проекта». Для демо-арта и звука источник в репозитории
не зафиксирован, поэтому **до публичного релиза владелец должен подтвердить
права** на эти файлы либо заменить их. Это второй блокер после выбора
лицензии движка (см. `docs/RELEASING.md`).

## Что нужно сделать до релиза

1. **Выбрать лицензию самого движка** (см. `docs/RELEASING.md`) и положить
   `LICENSE` в корень.
2. Добавить в `dist/<os>-<arch>/` тексты лицензий сторонних компонентов.
   Полные тексты проще всего скопировать из исходников, скачанных
   FetchContent, в `build/_deps/`: у каждой зависимости есть `LICENSE*`.
   Минимум — zlib (SDL3, SDL3_image, SDL3_mixer), MIT (QuickJS-ng, Box2D,
   RmlUi, Dear ImGui, visibility), Apache-2.0 (glslang, SPIRV-Cross, MDI),
   SIL OFL (шрифты), а также лицензии встроенных libpng/libjpeg/ogg/vorbis.
3. Подтвердить права на демо-арт и звук либо исключить их из поставки.
4. После выбора лицензии добавить её в `README.md` (это делает владелец:
   файл вне зоны правки этого документа).
