# История изменений

> Unreleased / Re2D: явная колонка направления `node.sprite_col` для flat
> atlas sprites (упакованный слоистый персонаж из отчёта re2d_gta_test 1.2.9).
> Если `sprite_col` задан, C использует его вместо angle/camera-выбора:
> клэмп в `0..columns-1`, без зеркалирования и LOD-прореживания направлений;
> `sprite_row` и `sprite_col` независимы, читаются каждый кадр, перерегистрация
> не нужна, атлас не перезагружается (пересобирается только клетка).
> `directions`-режим по `angle` сохранён и остаётся дефолтом; удаление
> `sprite_col` возвращает его на лету. Тесты: `tests/re2d/atlas_test.c`
> (явная колонка/клэмп), `tests/agent/re2d_sprite_col_test.py` (изолированная
> сцена: col 0≠2 по пикселям и цвету, row 0≠1, 10 live-кадров без ошибок,
> стабильный `visibleAtlasSprites`; на старом коде тест красный — 0.000% diff),
> JS-обёртки (37 проверок: регистрация не затирает `sprite_col`).
>
> Unreleased / Re2D visibility near portals:
> `r2d_world_portal_window()` больше не теряет дальние клетки, когда апертура
> портала пересекает плоскость камеры/near-plane (отвесная top-down камера
> видит портал «с ребра»): в этом случае окно консервативно расширяется до
> полного кадра, обычные порталы впереди сохраняют ограниченное окно. Исправлен
> pop «geometry disappears for one frame» из отчёта re2d_gta_test 1.2.8:
> sweep по y 1437.5..1442.5 давал 12/39 → 7/21 cells/surfaces, теперь стабильно
> 52/176 на обоих backend'ах, скриншоты у плоскости идентичны, стоимость на
> карте 52 клетки ~0.15 мс/кадр. Регрессии:
> `test_aperture_crossing_near_plane_keeps_far_cells` (FAIL на старом коде) и
> `tests/agent/re2d_portal_edge_visibility_test.py` (публичный API, 4-клеточная
> цепочка, CPU=GPU). Наблюдаемость: `world.info().portalsConservative` считает
> порталы, чьё окно расширено до полного кадра (edge-on/near-plane), — видно,
> когда включён консервативный путь. Preflight для любых карт:
> `python3 tools/visibility_sweep.py` (sweep обеих сторон всех плоскостей
> порталов, exit 1 при падениях; на отчёте 1.2.8 даёт 208 подозрений, на
> текущем дереве — 0).
>
> Unreleased / Re2D top-down camera (GTA2-стиль):
> `world.camera({mode:'topdown', ...})` — удобный bird's-eye режим:
> `projection:'orthographic'`, `pitch:-89.99°`, `near:1`, `orthoHeight:1200`
> по умолчанию; любое поле переопределяется, `mode:'perspective'` сохраняет
> legacy defaults. Отвесный `pitch:-90` теперь clamp'ится в ±89.99° (было ±89°),
> поэтому камера может быть практически строго сверху без вырождения
> проекции. Потолки из этого ракурса — крыши; открытые улицы — sky-поверхности
> (`world.surface(i).sky(true)`); атмосферу для обзора обычно выключают.
> Тесты: `tests/agent/re2d_topdown_camera_test.py` (topdown ≠ perspective,
> стабильный кадр, RangeError на неверный mode/projection, возврат в
> perspective), JS-обёртки `re2d_world_api_test.mjs` (36 проверок), native
> `re2d_test` (проекция под отвесной камерой без NaN и pitch < 90°).
>
> Unreleased / portal closure surfaces: движок сам выводит закрывающую геометрию
> плоскости портала — opening closures (как раньше) плюс solid-band closures для
> полос между/вокруг openings, если автор их не задал. Это закрывает утечку
> панорамы через solid-перекрытие между этажами (BASHNYA: розовые полосы неба,
> strip-пиксели 2615 → 0 на позе отчёта). Границы полос — по floor/ceiling
> соседних spans (min floor/max ceiling), author walls на той же плоскости
> вычитаются; automap не дублирует портальные линии. Тест
> `tests/re2d/portal_closure_test.c` (5 кейсов). Старые baked-карты грузятся без
> изменений; новые полосы появляются после перекомпиляции исходника.
>
> Unreleased / отчёт BASHNYA 1.2.5/1.2.6 (движок 1.2.7+):
> **MEDIUM-регрессия рендера исправлена.** Причина — неограниченный height fog
> R-02 (`optical += density·max(0,z−base)`) насыщался почти в 1 на высокой
> вертикальной карте, haze подтягивал насыщенный туман к серому; CPU-путь R-02
> отсутствовал. Формула заменена ограниченной интегральной
> `density·scale·(1−exp(−above/scale))·(1−exp(−depth·0.002))` в шейдере и в C-
> эталоне; `fog_height_falloff` — масштабная высота в мировых единицах (0
> отключает высотный член). Калибровка асимптот MEDIUM/HIGH/ULTRA 24/42/55 %.
> Repro BASHNYA: доля плоско-серых пикселей GPU **31,6 % → 0,06 %**, MAD
> CPU/GPU **24,2 → 3,8**, счётчики видимости идентичны, LOW байт-в-байт.
> Референсы visual lab перегенерированы осознанно; bloom-пара принимает
> локальный пик >8 при малой площади (гало — локальный эффект).
> **`world.quality({poseBudget,poseStep})` больше не меняет визуальный tier**
> (было `>=4 HIGH / >=2 MEDIUM / иначе LOW`). Явные контролы:
> `world.renderQuality('low'|'medium'|'high'|'ultra')` и
> `world.atmosphere({heightDensity,baseHeight,falloff,hazeStrength,hazeColor,skyLayers,sunDisc})`
> — только переданные поля, возвращает применённые значения, `hazeColor:null` =
> авто от авторского sky tint. `world.qualityPreset` остаётся полным пресетом;
> дефолтный мир создаётся с LOW-кадром. **Миграция:** MEDIUM теперь через
> `renderQuality('medium')`/`qualityPreset('medium')`, не через `quality({poseBudget:2})`.
> Тесты: `tests/agent/re2d_quality_decoupling_test.py` (46 проверок), JS-обёртки
> (35), `re2d_visual_lab_acceptance_test` зелёный.
> **GPU-профайлер: устранён класс падения exit 139.** Удалён поток
> `r2d_gpu_prof`; все вызовы SDL_GPU (Query/Release fence) — только на главном
> потоке, неблокирующий опрос в submit/frame_end, shutdown отпускает оставшиеся
> fence. GPU ms — по-прежнему CPU-наблюдение сигнала, не аппаратный timestamp.
> Тест `tests/re2d/r2d_profile_fence_test.c` (7 кейсов); 2400 кадров BASHNYA
> level1 с профайлером — exit 0, `gpu_ms >= 0`; 60 с окна — exit 0.
> **Impostor LOD:** карточки дальней геометрии больше не выдаются внутри
> near-band (`r2d_world_region_impostor_min_distance`; 0 — только явным
> `regionLod(0,...)`). level1: default near=600 → 33 карточки, ближайшая 743;
> старый режим — 36, из них 3 внутри полосы. Тест
> `tests/re2d/impostor_lod_policy_test.c`.
> **Видимость ровно на плоскости портала:** камера в пределах 1e-4 от линии
> портала получает полное окно вместо вырожденной апертуры
> (`visibleCells` 1 → 319/402/1401 на позе отчёта); регрессионный тест
> `test_camera_on_portal_plane_keeps_visibility` (на старом коде FAIL).
> Issue #2 отчёта (draw calls) измерен и задокументирован без спекулятивных
> оптимизаций: `gpuDraws` 10 315 — логическая атрибуция, реальных батч-групп 8,
> CPU p50 9,7 мс; `docs/RE2D_WORLD_PERF.md`. Guardian pop-in объяснён как
> прогрев residency на старте сцены, не дефект рендера. Пункты 1/3/4/7 отчёта
> (save 4097 spans, `R2D_SCENE_ENTER`, SDK PVS 0,2 с, WAV 1,0 с) перепроверены
> на 1.2.7. Розовые полосы неба — проверенный авторский пропуск (solid-щель
> между проёмами порталов, стен ноль), не ошибка видимости; рекомендация
> будущей задаче — portal-closure поверхности. Решения по всем пунктам:
> `docs/EXTERNAL_FEEDBACK.md`.
>
> Unreleased / VN narrative: dialog logic/view/theme split, semantic RML roles,
> speaker registry + expressions + portrait slots, theme stack/hot reload,
> input lock tokens, narrative IR/story adapter, backend/save/backlog/voice,
> native `r2d-sdk story validate` / `dialog validate`. Public `$` API additions
> are additive; existing `$.dialog` calls keep working.
>
> Unreleased / task-9 DoD gaps: real `$.sound` voice playback, real
> `$.resource`/`$.sound` prefetch, `$.i18n.lookup()` dictionary lookup,
> dynamic `choiceSlots`/`choiceTemplate` (1..64), optional hard input lock
> (`$.input.lock(..., {hard:true})`), narrative DevTools tab, `world.debug`
> views/features/budget helpers, BASHNYA RML/RCSS theme. Purely additive;
> advisory input locks, the 6-slot default RML and event-only voice/prefetch
> listeners continue to work.


## 1.2.10 — 2026-10-18

<!-- release-notes:begin — генерируется tools/release_notes.py, правьте текст вне маркеров -->

1 коммит в релизе.

### Добавлено

- Re2D: явная колонка направления node.sprite_col для flat atlas (`7293f579f`)
  Фича одобрена (отчёт re2d_gta_test 1.2.9: упакованный слоистый персонаж
  legs/tail/torso/head, 16 направлений x 9 кадров). В их repro angle 0 и π давали
  одинаковый кадр, потому что камера стояла ровно над спрайтом: angle-режим
  выбирает колонку из facing И позиции камеры, а относительный yaw в этой точке
  вырожден (0). Для упакованных персонажей нужна детерминированная колонка из
  игры, а не из ракурса.
  Добавлено:
  - C читает node.sprite_col каждый кадр; при наличии колонка берётся из него
  (клэмп 0..columns-1), без mirror/flip и без LOD-прореживания направлений;
  sprite_row и sprite_col независимы, перерегистрация не нужна;
  - смена колонки/строки пересобирает одну клетку crop-буфера, полной
  перезагрузки атласа нет;
  …

<!-- release-notes:end -->
## 1.2.9 — 2026-10-18

<!-- release-notes:begin — генерируется tools/release_notes.py, правьте текст вне маркеров -->

2 коммита в релизе.

### Исправления

- Re2D: не терять дальние клетки у портала при top-down камере (`c7c83e31b`)
  Отчёт re2d_gta_test 1.2.8: камера (1060.4, 1439.5..1439.9, h=700),
  pitch=-89.99, портал y=1440: visibleCells 12->7, visibleSurfaces 39->21,
  здание исчезает на кадр; при y=1440.0 стабильно. Воспроизведено на CPU и GPU.
  Причина: r2d_world_portal_window() клипал апертуру по near-plane. У отвесной
  камеры портал виден «с ребра», верх апертуры пересекает плоскость камеры, и
  near-clip обрезает проекцию, хотя конус видимости через апертуру продолжает
  расширяться. Дальние клетки проецируются вне усечённого окна, traversal их
  отбрасывает; полоса ±0.1..0.5 — ровно там, где окно не дотягивается до
  проекции следующего портала.
  Стало: если угол апертуры ближе near-plane (включая «за камерой») и есть
  угол впереди, окно портала консервативно = полный кадр. Недобор — видимый pop,
  перебор occlusion-safe (depth/BSP скрывают невидимое). Обычные порталы впереди
  …

### Документация

- Re2D: preflight видимости у порталов + счётчик консервативных окон (`2c9f1cc38`)

<!-- release-notes:end -->
## 1.2.8 — 2026-10-18

<!-- release-notes:begin — генерируется tools/release_notes.py, правьте текст вне маркеров -->

3 коммита в релизе.

### Исправления

- Re2D: закрыты P1/P2 отчёта BASHNYA (MEDIUM, профайлер, качество, LOD, граница портала) (`b827300b7`)
  MEDIUM: неограниченный height fog R-02 насыщался на высокой карте и заливал
  материалы серым. Формула заменена ограниченной интегральной в шейдере и C-
  эталоне (falloff = масштабная высота), калибровка MEDIUM/HIGH/ULTRA 24/42/55%.
  Repro BASHNYA: плоско-серые пиксели GPU 31,6% -> 0,06%, MAD CPU/GPU 24,2 -> 3,8,
  видимость идентична, LOW без изменений. Референсы visual lab перегенерированы;
  bloom-пара принимает локальный пик >8 (гало локально), остальные фичи >=0,1%.
  world.quality() теперь только бюджет поз; явные world.renderQuality() и
  world.atmosphere(); qualityPreset - полный пресет; дефолт LOW. Тесты 46+35.
  Профайлер: удалён поток r2d_gpu_prof, все SDL_GPU fence-вызовы на главном
  потоке (класс падения exit 139); 7 native-кейсов, 2400 кадров BASHNYA и 60 с
  окна с профайлером без падения.
  LOD: impostor-карточки не выдаются внутри near-band (level1: 33 карточки,
  …

### Документация

- Re2D: top-down камера (GTA2-стиль) — явный mode:'topdown' (`174a36e3c`)

### Тесты и гейты

- Re2D: portal closure для solid-полос между openings (розовые полосы неба) (`99cde262c`)

<!-- release-notes:end -->
## 1.2.7 — 2026-10-18

<!-- release-notes:begin — генерируется tools/release_notes.py, правьте текст вне маркеров -->

1 коммит в релизе.

### Тесты и гейты

- Close roadmap acceptance wave: visual lab/refs, debug overlays, GPU batching, brush entities, sky leak, scene-W, coverage 0 red; web build fixes (`443e12c78`)

<!-- release-notes:end -->
## 1.2.6 — 2026-10-18

<!-- release-notes:begin — генерируется tools/release_notes.py, правьте текст вне маркеров -->

22 коммита в релизе.

### Добавлено

- api: regenerate schema/typings/docs for runtime 1.2.5 (scene.status) (`548fff4c3`)
  - 3985 публичных имён после добавления $.scene.status.
  - dist/.DS_Store снова удалён из индекса (релизный коммит вернул его).
  - ci_verify зелёный: api check/doctor/recipes.

### Тесты и гейты

- Roadmap closure: visual lab/refs, debug overlays, GPU SSBO batching, brush entities/sky leak, scaling, scene-W, coverage 0 red (`591fb9501`)
- Re2D: true streaming, batching data, hint/occluder, sky layers, brush CSG, coverage audit (`651abf6fc`)
- Re2D: fix CPU/GPU parity for shadows, transparency, decals (`572cfe273`)
- Re2D final composite/streaming: post bloom/reflection/heat, decals2, ambient/detail, GPU residency/origin/LOD (`6b6065d26`)
- Roadmap closure wave 2: full huge-world streaming, renderer P4/P5, advanced brushes, VN gaps, QA (`f68815887`)
- Re2D: brush compiler, tool-material policy, sky boundary, region PVS (`b886dc132`)
- Re2D: grounding/edges/material/lighting/sky/VFX + runtime region info (`52898787b`)
- VN: dialog/view/theme split, Narrative IR, speakers, skip/lock, native linters (`a267d3731`)
- Re2D perf: cache wall->span incidence, draw attribution, empty-scissor skips (`7d0940238`)
- Re2D: fix BASHNYA engine issues (save limits, scene enter diagnostics, WAV duration, PVS) (`a38856b44`)

### Прочее

- handoff: wave 4 CPU/GPU parity task (`fd29dcebf`)
- handoff: wave 2 tasks for full roadmap closure (`47f96d980`)
- handoff: final roadmap integration, gates, metrics and remaining gaps (`2f21cebee`)
- site: publish VN/Re2D roadmap docs on documentation site (`34da74659`)
- handoff: R-04..R-06 / #5 / #6 complete + region runtime wiring (`a39168a04`)
- handoff: R-01/R-02 + VFX GPU pass complete (`b9d395f79`)
- handoff: VN-01..03 complete (`1b4e7b046`)
- handoff: R-03 VFX complete (`3f02a40ec`)
- docs: roadmap acceptance matrix in handoff (`07eb446ae`)
- docs: assign VN/render/world/VFX roadmap tasks (`cb5d919d7`)
- docs: handoff для VN + Re2D render roadmap (`3818628a0`)

<!-- release-notes:end -->
## 1.2.5 — 2026-10-17

<!-- release-notes:begin — генерируется tools/release_notes.py, правьте текст вне маркеров -->

8 коммитов в релизе.

### Добавлено

- SDK tooling: Phase 0 cleanup + API metadata registry, schema/typings, lint (`1474fdd0b`)
  - Phase 0: root AGENTS.md, .gitignore service patterns, удалён tracked
  dist/.DS_Store, отчёт docs/SDK_TOOLING_PHASE0_REPORT.md.
  - Runtime: --dump-api (r2d_api_metadata snapshot) — живой $ API как источник
  истины; deterministic flat metadata (3594 entries incl. engine/selector).
  - r2d-sdk api dump/check/generate: JSON snapshot, structural check, stale-schema
  gate, api.schema.json + russiano2d.d.ts generation (generated headers).
  - r2d-sdk lint: API-aware scanner с R2D001/002/004/014, suggestion, --json,
  schema-based; реальная игра проходит чисто.
  - docs SDK.md/AGENTS обновлены под новые команды позже; CTest 140/140.

### Документация

- docs: SDK agent tooling guide + публикация SDK/API reference и recipes на сайте (`c04a369e3`)

### Тесты и гейты

- SDK tooling: Phase 6 GUI + Phase 7 recipes/CI (`148d16c7b`)
- SDK tooling: doctor + deterministic metadata/docs (`d941b7bbc`)
- SDK tooling: api generate schema/typings, project validate, lint hardening (`b134f906a`)

### Сборка и версии

- release: package SDK schema/typings/docs and gate artifacts before packing (`3afc5e001`)

### Прочее

- Re2D controller: восстановление grounded-контакта из JS-моста (`e204176f0`)
- SDK tooling: generated $ API reference (Phase 5) (`ff334d144`)

<!-- release-notes:end -->
## 1.2.4 — 2026-10-17

<!-- release-notes:begin — генерируется tools/release_notes.py, правьте текст вне маркеров -->

30 коммитов в релизе.

### Исправления

- Re2D P1-C…F: particles, nav graph, automap, map metadata/spawns (`e29549c5a`)
  - Particles: native fixed pool (2048/world) с детерминированным LCG, шаг в
  worldStep, curves size/alpha, режимы screen/billboard/axis/floor и blends;
  CPU reference — lit quads с depth/fog; SDL_GPU — actor-billboard pipeline с
  1x1 white + tint (бюджет 512). world.particles.burst/continuous/info/clear.
  15 Unity-кейсов + JS-контракт + agent-пиксели CPU/GPU.
  - Nav: world.navBuild/navNearest/navPath — span/portal граф и детерминированный
  A*; runtime кэширует CSR/scratch, без аллокаций на запрос; 13 Unity-кейсов,
  dust2 path 25 spans. Попутно исправлена инициализация open_fraction для
  загруженных baked-карт (иначе все порталы считались закрытыми).
  - Automap: world.automapLines/automapProject — XY-линии стен и порталов +
  2D-трансформ; 8 Unity-кейсов, lab probe.
  - Metadata/spawns: meta/metadata + typed spawns из .re2dmap переживают
  …

### Добавлено

- Re2D P1: audio voice virtualization в runtime (`b4fa6842b`)
  - Runtime строит R2DAudioVoices pool из активных источников (priority, range);
  budget (default 24) ограничивает реальные каналы, остальные virtual с gain 0;
  promotion/demotion каждый кадр; profiler audioVoicesActive/Virtual.
  - world.audio.budget(n)/state(), source priority/low-level audioPriority;
  ленивое подключение audio engine к world при создании первого source.
  - Agent: 3 источника, budget 1 -> priority 30 реален, два virtual, стабильно
  после шагов. JS-контракт 30 проверок; docs раздел; CTest 140/140.
- Re2D P2: animated materials (scroll/emissive) в runtime и $ API (`e4b7350b9`)
  - R2DWorldMaterial.anim_u/anim_v/anim_emissive; CPU material sampling
  добавляет UV offset и множит emissive; SDL_GPU — новые uniform-поля anim
  (std140 68*16) и та же формула в world.frag.
  - Runtime: material_anims[R2D_WORLD_MAX_MATERIALS], шаг в worldStep.
  - $ API: world.materialIndex / world.materialAnim(name,opts).info/remove.
  - JS-контракт (20 проверок) и agent-проверка: scrolling/emissive материал
  меняет кадр; docs — раздел Animated materials.
  - Остальные P2-ядра (portal visuals/volume) уже в дереве с тестами, интеграция
  рендера — следующий проход.
- Re2D P0-A: нативные atlas world sprites вместо ui.image оверлея (`fbcc5cdee`)
  - world.sprite(node, opts): flat directional atlas (1/4/5+mirror/8/16),
  feet/center/custom pivot, masked/opaque/translucent/additive, sprite_row.
  - Нативный C: выбор колонки и зеркала по facing+камере, кроп клетки,
  depth/fog/light в общем композиторе мира (CPU reference и SDL_GPU).
  - Профайлер: info().atlasSprites/visibleAtlasSprites, actorMs.
  - Демо demos/re2d_boomer_lab: приёмочный стенд P0-A с пиксельной
  окклюзией стеной и проверкой CPU/GPU parity.
  - re2d_testroom: враги переведены с ui.image+world.ray на world.sprite;
  JS-проекционный цикл для отрисовки убран.
  - P0-B core: src/re2d_world_trace.{h,c} — nearest hit мира и прокси,
  category masks, ignore, multi-hit, детерминизм (Unity).
  - Unity: r2d_re2d_atlas_test (16), r2d_world_trace_test (8),
  …

### Удалено и изменено

- Re2D P2: mirror pass clipping fix (per-subdraw clip rect) (`581f7e639`)

### Тесты и гейты

- demos: sky-lab переключает mirror/sky горячими клавишами (`2f77c0e7c`)
- Re2D P4: nav nodes в debug overlay + capabilities mirror=true (`f352d14ea`)
- Re2D P4/P5: live profiler HUD + mist bands (`a043789e0`)
- Re2D P3: rotating polywall runtime groups (`d854e9a50`)
- Re2D P4: debug overlay draw layer + demo (`5a6217a17`)
- Re2D P1/P3: conveyor gameplay tick (world.conveyorMotion) (`4d39e68b8`)
- Re2D P1: polygon cells compiler tiling + audio zones per span (`4363222da`)
- Re2D P2/P4: postprocess stack, aim assist, quality/feel presets, debug entities + audio cores (`d6ca907f1`)
- Re2D P2: volumetric sprites + P1/P3 polygon & polywall cores (`ac70b73fe`)
- Re2D P1-H…J + P2 cores: save/load, secrets, terrain, portal math, volumes, material anim (`544baeeac`)
- Re2D P1-B: passenger carry на лифте и crusher-контакт для mover (`e7502d953`)
- Re2D P0-C…P0-H: controller, semantic IDs, movers, triggers, viewmodel, native gate (`511997a97`)
- Re2D P0-B: world.trace/hit в $ API + JS-контракт (`8bbf25d48`)

### Прочее

- Re2D P2: mirror portal (scissored reflected-world pass) (`824ad2f0d`)
- docs Re2D: dynamic nav masks и P3 progress (`ab222b391`)
- Re2D P3: dynamic nav masks (blocked spans/portals без rebuild) (`fda16a8ac`)
- Re2D P2: sky portal (visibility window) + save persistence (`769f3340a`)
- Re2D P2: impactInfo/ricochet + surfaceMaterialName (`fd1eba505`)
- Re2D P4: debug overlay data + determinism audit (`846a43649`)
- Re2D P3: multi-zone boss hit proxies (`31d5f8e44`)
- Re2D P1/P2: save secrets/breakables, sky animation, fog zones (`e230096d6`)
- Re2D P4: benchmark lab со сценариями и честными native-числами (`0943122e3`)
- Re2D P4: capabilities API + profiler fields для trace/controller/nav/audio (`ad7e5f2c3`)
- Re2D P1-G: VFX bundles поверх particles/light/decal/sound (`1101516b7`)
- Re2D P1-A: Portals 2.0 — плавная open fraction вместо бинарного closed (`52faa99b1`)

<!-- release-notes:end -->
## 1.2.3 — 2026-10-17

<!-- release-notes:begin — генерируется tools/release_notes.py, правьте текст вне маркеров -->

39 коммитов в релизе.

### Исправления

- UI: убран ReferenceError ui is not defined в tickWidgets (Escape/back) (`6623a0370`)
  tickWidgets вызывал ui.closeTop(), но `ui` — локальная ссылка installUiApi,
  её в области видимости tickWidgets нет: при Escape/возврате в меню кадр
  падал. Вызов идёт через module-level api.ui с проверкой типа. Регрессия —
  tests/js/widgets_anchor_test.mjs (24 проверки, включая «Escape закрывает
  верхний контекст через $.ui.closeTop»), ci_verify exit 0.
- I1/Д13: параллакс — смещение отрисовки (draw_off), позиция игры неприкосновенна (`ecb25e882`)
  node.x/y больше не пишет layers.js: это позиция игры, её читают физика,
  геймплей, .pos() и агент. Параллакс живёт в node.draw_off_x/y:
  * нативный src/nodes.c — быстрый проход (x/y + off), hit-test
  (_scr_* = нарисованная точка), Y-sort (key = y + off_y);
  * render.js — nodeTransform (единая точка всех JS-отрисовок), свет/тени/
  бюджет источников, коллектор окклюдеров, _nodeClip, repeat-полоса;
  * layers.js пишет off = (cam − cam_ref) × (1 − f), x/y не трогает;
  cam_ref переезжает при игровом .at()/.moveTo(), поэтому телепорт
  не «съедается».
  Новое публичное $.layers.offset(node) → {x,y}; freeze 3131 → 3133,
  api_docs_sync зелёный (docs/highlevel/layers.md, render.md).
  Замеры (фикстура layers, f=0.5, камера 200): pos 60 (было 160), offset 100,
  …
- devtools_hitch_test: флак полного набора — не предполагать «строка 1 = get(0)» (`979cb71b7`)
  Полный прогон 2026-10-17 (262 теста) дал 1 падение: под нагрузкой между
  чтением строк и кликом по второй строке в кольцо попадал новый захват,
  индексы сдвигались, и проверка `selected == 0` падала (5 проверок). Тест
  проверяет смысл: выбранная строка существует и это НЕ самый свежий захват,
  детали и панель показывают её кадр. 3 прогона подряд — зелёные; полный
  набор с этой правкой — 0 fail.
- task-56: doc.on снова цепочка, демо и игры переведены на $.vfx (`eb48685cf`)
  Полный прогон поймал регресс: возврат `doc.on` стал числом (id слота), из-за
  чего цепочки `doc.on(...).on(...)` падали с TypeError в сценах `rotsprite`,
  `menu`, `spires` (demos_test, game_test, highlevel_rotsprite_test — 3 файла
  тестов красные). Носитель id объявлен в задаче как `engine.ui.on`, поэтому:
  - `doc.on(element, event, fn)` снова возвращает документ (цепочка работает);
  id отдаёт `engine.ui.on(doc, el, event, fn)`; снятие — `doc.off`/engine.ui.off;
  - ui_off_test перестроен на этот контракт (37 проверок, зелёный);
  Миграция игрового кода: 54 вызова `$.fx.*` → `$.vfx.*` в 9 файлах demos/,
  game/, witch_game/ — иначе R2D_FX_DEPRECATED попадал в «ошибки игрового кода»
  и ронял demos_test (4 ошибки shooter_witch) и game_test (menu/spires).
  После правки: demos_test, game_test, highlevel_rotsprite_test — зелёные.
- task-56: смешивание клипов + UI off и возврат слотов слушателей (`4fb4291ad`)
  Анимация: `$.anim.crossfade(target, from, to, ms, opts)` и
  `$.anim.blendInfo(target?)` — t=0 ровно 100 % from, t=ms ровно 100 % to;
  29 покадровых замеров: t монотонен, alpha 0.973→0.227, x 3.333→96.667;
  при --fixed-dt 50 мс ровно 10 кадров; событие to-клипа один раз;
  playClip/stopClip снимают переход. Кадр спрайта дискретен (один draw на
  узел) — ограничение описано и не выдаётся за попиксельный кроссфейд.
  Красных до правки: 24 из 35.
  UI: `engine.ui.on`/`doc.on` возвращают id слота; `engine.ui.off(doc, el,
  event[, fn])`/`doc.off(...)` снимают и JS-обработчик, и слушателя RmlUi,
  возвращают число снятых. Ключ идемпотентности — пара+обработчик: второй
  РАЗНЫЙ обработчик пары работает (было [1,0], стало [1,1]). Слоты пула 256
  возвращаются: 300 циклов подписка→снятие — 0 ошибок (до правки после 256
  …
- task-68: контракт API мира — remove/clear/destroy, collision.of(selector) (`6643c289d`)
  Сначала контракт, потом код (docs/highlevel/world.md §1.2 переписан с «чего
  нет» на факт):
  - `$.world.remove(target)` — цель обязательна (R2D_WORLD_REMOVE_NO_TARGET),
  промах R2D_WORLD_REMOVE_MISS; возвращает число узлов вместе с детьми.
  Замер: remove('#hero') → 1, all 15→14, тел 12→11; remove($('.goblin')) → 3.
  - `$.world.clear({ui})` — игровые узлы; persistent/HUD/стены bounds() живы:
  15 узлов → 7, тел 12 → 6; {ui:true} снимает и UI; повторный clear() → 0.
  - `$.world.destroy()` — полный перезапуск: всё + границы/фон/гравитация
  0/2000/timeScale 1/pause off → {nodes:6, bodies:0, ui:0, persistent:2}.
  - `$.collision.of('#hero')` → 'player' (было null): селектор разворачивается.
  - `$.grid.get` не заводим: канонический геттер `$.grid.at(g,cx,cy,fallback)`,
  count(g,value) уже был; тест фиксирует решение (14 проверок).
  …
- task-66: бюджет/LOD света (I11) и мерцание эмиттера (I12) (`a208d0ff4`)
  I11: `$.gfx.light.budget({max, priority, radiusScale})` — при превышении
  бюджета дальние/слабые источники уходят в LOD, числа видны в
  qualityReport().budget и stats().budget*. Замер: 45 источников при max:32 →
  sources=45, full=32, lod=13, off=0, degraded=13 (совпало с числом узлов),
  треугольники кадра 6480 → 5544 (−14.4 %), кадр 1.57–1.59 → 1.45–1.46 мс.
  I12: `.emissive({flicker:{hz,depth,curve}})` — sine/triangle/random от
  игрового времени, детерминировано при --fixed-dt (max|Δ| = 0). Цена 1000
  эмиттеров с общей кривой — медиана −0.006…0.018 мс (≤0.02), 1000 разных
  частот 0.058 мс. Прежний `.flicker(amount,speed)` у <light> работает
  (регрессия highlevel_light_limits/highlevel_light/screenfx).
  Красные до правки: light_budget 34, emissive_flicker 12 (старый
  build-2d/russiano2d); после — 45 + 20 зелёные.
  …
- task-65: смена сцены — change/state/события/экран загрузки/переходы/cancel (`d9c26eca5`)
  Одна точка входа `$.scene.change(name, opts)`, `load()` — тонкая обёртка:
  одинаковые опции дают одинаковый результат. Рапидные запросы склеиваются:
  ['b','c','b','c','b'] в одном кадре → один переход, enter ['b'], exit ['a'],
  одно scene:before-change (живой прогон, 70 проверок).
  Наблюдаемость: `$.scene.state()` → {from,to,phase,t,ratio,pending,prepared};
  300 мс: phase 'out' t=0 → кадр 5 ratio 0.278 → кадр 19 phase 'in' → кадр 36
  phase null, busy() false. События scene:before-change/progress/after-change/
  error; ошибка лоадера не оставляет пустой мир (сцена и узлы целы, затемнение
  снято, R2D_LOAD_RESOURCE в $.debug.errors()).
  Экран загрузки: прогресс по РЕАЛЬНЫМ шагам (50 единиц), min_loading_ms 200 =
  11 кадров, мир на паузе 11 кадров, звук заглушён 11 кадров, timeout 100 мс →
  R2D_SCENE_LOAD_TIMEOUT и возврат к прежней сцене; свой RML реально
  …
- VFX-план: E — правило «публичное API только high-level в $$, а не запрос на API вне $ (`67a9f6469`)
  Владелец уточнил: API вне $$ делать НЕЛЬЗЯ. Переписал раздел: это ограничение, а не
  хотелка (я неверно понял формулировку и записал её как запрос).
  E1: эффекты создаются и играются только через $.vfx.*; спеки грузятся через
  $.vfx.load/loadAll внутри $$; публичного engine.vfx.* нет — C-уровень остаётся внутренним;
  валидатор и предпросмотр — build-time тулы (не runtime API, в заморозку не входят).
  E2: как проверяется — api_freeze фиксирует только $-поверхность (появление r2dvfx.* или
  engine.vfx.* как публичных имён = нарушение), api_docs_sync требует доку только в $-доке,
  в ревью такие правки отклоняются.
  E3: почему — одна документированная поверхность (3067 имён уже в $$; второй namespace
  удвоил бы поддержку и размыл заморозку), правила $$ (промах цели, дедупликация,
  детерминизм по --seed, ошибки в $.debug.errors) распространяются и на эффекты, игроку
  не нужно знать про C-уровень.
  …

### Добавлено

- Re2D testroom: АК — автоматический огонь (600 в/м), остальные одиночные (`9956f1caf`)
  Пистолетный цикл 0→1→2→3→0 (465 мс) для АК сжат до 100 мс; пока ЛКМ/F
  удерживается, каждый законченный цикл сразу начинает следующий. Пистолет и
  дробовик остались одиночными (только нажатие). В состоянии оружия появились
  auto/rpm, в HUD — «АВТО». Замер: 8 выстрелов за 45 кадров.
  re2d_testroom_test — 40 проверок (режим АК + очередь удержанием).
- Re2D testroom: карта из SDK .re2dmap + $.re2dWorld; SDK world-compile восстановлен (`9f0e6bb04`)
  SDK: в d3a2415 Re2D-слой вырезали, но docs/re2d/RE2D_WORLD_FORMAT.md
  продолжал обещать `r2d-sdk world-compile`. Вернул sdk_world.c из истории,
  добавил в SDK-сборку native world bake (re2d_world*.c, bsp, json) и команды
  world-compile/world-info; .re2dmap получил тип re2d.world и валидатор
  (`r2d-sdk validate testroom.re2dmap` -> errors 0). Проверка: компиляция
  acceptance.re2dmap --renderer даёт JSON, равный закоммиченному
  acceptance.re2dworld (6 cells/28 walls/5 portals/1 stairs/1 slope).
  Демо: карта demos/re2d_testroom/testroom.re2dmap (1600x1200, 12 стен,
  4 света) -> testroom.re2dworld; игра грузит $.re2dWorld.load,
  ходьба через world.support/blocked (глаза +48). Замеры:
  W y 1080 -> 926.7; внутренняя стена y=620; южная y=1183.5; A Δx=-153.3.
  Враги (атлас 5x8, 40 кадров) проецируются камерой мира и идут
  …
- NEXT_SESSION: полный набор с Re2D-комнатой — 263/257/6/0 (`f6c5ddf70`)
  Прогон 2026-10-17: 263 теста, 257 ok, 0 fail, 6 skip (re2d_* вырезаны из SDK),
  726 с. Все 10 гейтов зелёные. В §4 добавлена Re2D-фаза: тестовая комната
  врагов на билбордах (24 проверки), жёсткая камера, yaw в градусах.
- Вишлист движка: docs/ENGINE_GAPS.md + связка с VFX-планом и задачами (`c8aa0e701`)
  Новый рабочий документ docs/ENGINE_GAPS.md (не публикуется на сайте): чего движку не
  хватает, по зонам, с указанием задач. VFX-часть остаётся в docs/VFX_ROADMAP.md (A-F).
  Разделы: (1) мир/сетки/коллизии — $.world.remove/clear, $.grid.get/count,
  $.collision.of подтверждены грепом (0 определений), task-68; (2) анимация — нет смешивания
  клипов (blend/crossfade, 0 определений), события и клипы уже сделаны; (3) UI — off/слоты
  слушателей (пул 256, слоты не возвращаются; второй обработчик молча выбрасывается), I4
  авто-раскладка/resize, H2/H3 RmlUi не подтверждены; (4) сейвы — save/store есть,
  типизированных настроек с версионированием схемы нет; (5) физика — события сенсоров (I8),
  I1 параллакс забирает позицию; (6) инструменты — DevTools 14 вкладок, предпросмотра VFX нет;
  (7) наш долг: нет гейта примеров из доки (шесть расхождений за сессию найдено вручную),
  заморозка не видит методы возвращаемых объектов; (8) платформы/CI — MSVC ICE, linux-aarch64
  по тегу v1.2.2 снова красный, веб-сборку перепроверить, сеть не проверялась;
  …
- VFX-план: раздел F — разделить $.fx на $.sfx (звук) и $.vfx (r2dvfx) (`e61764700`)
  Запрос владельца: «у нас сейчас fx для всего; разделим его на $.sfx — sound.fx и $.vfx —
  r2vfx». Правило: что СЛЫШНО → $.sfx, что ВИДНО → $.vfx. Удар перестаёт быть чёрной
  коробкой: композиция $.vfx.play('hit.spark') + $.sfx.play('hit.metal') либо одна спека
  $.vfx со слоем use:'sfx.play'.
  F1 — таблица переезда: flash/flashLeft/shockwave/lightning/pulse/trail/ribbon/pushRibbon/
  attractor/hitStop/clear/stats → $.vfx.*; impact → $.vfx.impact + звук через $.sfx;
  installHits/$.hits → $.sfx.presets (звук) + $.vfx.impact (картинка), пресет один.
  F2 — миграция без молчаливых поломок: $.vfx/$.sfx — целевые; $.fx — работающий алиас на
  один минор с ОДНИМ дедуплицированным предупреждением; заморозка --write сохраняет старые
  имена до удаления; удаление отдельным коммитом с CHANGELOG и docs/highlevel/migration.md;
  mapping-тест: старый вызов = новый результат (числа/кадр), предупреждение ровно один раз.
  Приёмка: (1) $.vfx/$.sfx с докой; (2) тест по спискам: в $.sfx нет визуальных имён, в
  …
- VFX-план: улучшение переключателя сцен + встроенный прогресс-бар и свой RML на загрузке (`065c22d62`)
  Запрос владельца: «улучшить переключатель сцен; сделать внутри движка простой прогресс-бар
  и давать метод для смены сцены с загрузкой + возможность поставить на сцену загрузки свой rml».
  A0 — улучшение переключателя (одной точкой входа, без новых сущностей):
  A0.1 единая $.scene.change(name, opts) с опциями (transition/loading/audio_fade/
  keep_light/timeout_ms/min_loading_ms), load() остаётся тонкой обёрткой;
  A0.2 склейка рапидных запросов: N вызовов в кадре → один переход, без мигания;
  A0.3 интроспекция $.scene.state() → {from,to,phase,t,ratio,pending,prepared};
  A0.4 события scene:before-change/progress/after-change/error;
  A0.5 ошибка загрузки НЕ оставляет пустой мир: прежняя сцена цела, затемнение снято,
  scene:error и запись в $.debug.errors();
  A0.6 prepare(name)+promote(name): подготовленная сцена переключается мгновенно, без
  экрана загрузки (замер времени против обычного пути).
  …
- VFX: план — чего нет в смене сцены и свете, и спека r2dvfx вместо Effekseer (`891333aa4`)
  Новый рабочий документ docs/VFX_ROADMAP.md (не публикуется на сайте: allow-list сайта —
  только $-дока, CHANGELOG и туториалы).
  A. Смена сцены — чего нет (с критериями приёмки):
  A1 экран загрузки с прогрессом (loadAsync/preload есть, канваса нет);
  A2 переходы кроме fade (wipe/шторка/shader через наш пост-проход, ≤1 мс на кадр);
  A3 автосброс света и затемнения при смене сцены (дефект I14: двойное затемнение,
  «свет прошлой сцены» переезжает);
  A4 отмена перехода на середине (сейчас только «новый load побеждает старый»).
  B. Свет/эмиттеры:
  B1 I12 — мерцание/анимация интенсивности эмиттера (сейчас только статичная);
  B2 I11 — бюджет и LOD света/теней (игра прореживает источники руками; закрепить
  бюджетом, degraded видно в qualityReport);
  …

### Удалено и изменено

- task-69 + task-67: $.fx → $.vfx + $.sfx, r2dvfx M1–M3/M5 (`f714f0c68`)

### Документация

- Все C-тесты переведены на Unity; правило 11 в AGENTS-документации (`bd2c476a9`)
- Д2: гейт примеров из доки — 687 публичных путей проверяются (`7f222c18a`)
- Доки смены: точные числа и найденные блокеры (D5/D6/D9) (`0f0388cf7`)
- Смена 2026-10-17: заморозка 3125, гейты Д1/Д3, сенсоры и bsp, доки к факту (`258dde17c`)
- Передача смены: не хардкодить HEAD в документе (он устаревает на каждом коммите) (`08b612366`)
- Передача смены: единый самодостаточный документ docs/NEXT_SESSION.md (`3d05034c3`)

### Тесты и гейты

- Все проверки зелёные: полный агентский набор + все repo-тесты (`7d00da9de`)
- Тесты: пилот Unity — BSP-тест переписан на TEST_ASSERT_*, C-слой без Python (`da5d2363d`)
- Re2D testroom: враги — пиксельный атлас 5×8 (40 кадров), поворот по камере (`cae81d263`)
- NEXT_SESSION: честные числа после I1 (полный прогон не перегонялся; затронутые тесты зелёные) (`6b4a2992b`)
- Д11/M4: вкладка VFX в DevTools — предпросмотр, перемотка, экспорт (`c7727ac6d`)
- Д10: гейт обёрток снимает и вложенные namespace (35 → 105 методов) (`d83a7bf99`)
- Re2D: тестовая комната врагов на билбордах + луч видимости (`c62d990fc`)
- Re2D: тестовая комната врагов на билбордах (только прогулки, без оружия) (`efa6b5a1f`)
- NEXT_SESSION: Д7 — сеть проверена существующими тестами (числа прогона) (`99032b923`)
- NEXT_SESSION: приёмочные числа смены — 262/256/6/0, заморозка 3125 (`c6b26511b`)
- emissive_flicker_test: замер ≤0.02 мс принимается только на тихой машине (`417a1e15d`)
- VFX-план: раздел E — API вне $ (`010ab48dc`)

### Сборка и версии

- Д6: веб-сборка перепроверена на текущем дереве (emsdk 6.0.11 + SDL3 WebGPU) (`e93a7ea9e`)

### Прочее

- Re2D testroom: камера 76, рост врага 150, урон и смерть врагов (`3e89e30b1`)
- NEXT_SESSION: план Д13 (полный I1 — draw_off в нативном контракте узла) (`0432dc881`)
- task-65: экран загрузки — theme и title/hint честно, а не молча (`8fda66854`)

<!-- release-notes:end -->

### Подробности (написано вручную)

Текст ниже перенесён генератором из разделов «Не выпущено» без изменений (опущен только уровень заголовков).

### Не выпущено — task-65/66/67/68/69, task-56, долги Д1/Д3 (2026-10-17)

### Добавлено

- **task-65 (A0): одна точка входа смены сцены — `$.scene.change(name, opts)`.**
  `load()` стал тонкой обёрткой (те же опции → тот же результат). Рапидные
  запросы склеиваются: `['b','c','b','c','b']` в одном кадре → ровно один
  переход, `enter` ровно `['b']`, `exit` ровно `['a']`, одно
  `scene:before-change` (проверено живым прогоном, `scene_change_test`, 70
  проверок). Наблюдаемость: `$.scene.state()` → `{from,to,phase,t,ratio,pending,
  prepared}` (300 мс: `phase:'out', t:0` → через 5 кадров `ratio 0.278` →
  кадр 19 `phase:'in'` → после 36 кадров `phase:null`, `busy()===false`).
  События `scene:before-change/progress/after-change/error`; ошибка лоадера не
  оставляет пустой мир (прежняя сцена и её узлы целы, затемнение снято, код
  `R2D_LOAD_RESOURCE`/`R2D_SCENE_LOAD` в `$.debug.errors()`).
- **task-65 (A0.6/A4): `$.scene.prepare`/`promote` и `$.scene.cancel`.**
  `prepare()` собирает сцену во временной области, `promote()` публикует её
  без кадра, без экрана загрузки и без повторного `enter` (счётчик enter = 1).
  `cancel()` во время затемнения снимает его за остаток времени (alpha
  непрерывна: 0.278 → 0), лоадер останавливается, мир прежний.
- **task-65 (A1): встроенный экран загрузки с прогрессом и своим RML.**
  `$.scene.loading({rml, theme, min_ms, timeout_ms, style})`; полоса идёт по
  РЕАЛЬНЫМ шагам (единицы работы шагов + байты ресурсов, 50/50, монотонно;
  50 шагов — 50 единиц в `scene:progress`); `min_loading_ms:200` = 11 кадров
  экрана при 60 fps; мир на паузе (11 кадров), звук заглушён (11 кадров);
  `timeout_ms:100` даёт `R2D_SCENE_LOAD_TIMEOUT` и возврат к прежней сцене.
  Свой `.rml` реально показывается (`loading_progress` 460×24 px) и получает
  `loading_bar`/`loading_progress`/`loading_label`; без элементов — одно
  предупреждение в журнал, не тишина. `theme` сам по себе не применяется
  (RmlUi берёт стили из `<link>` внутри `.rml`) — при задании движок один раз
  пишет `R2D_SCENE_LOADING_THEME`; `title/hint/color/barColor` в
  `$.scene.loading()` теперь запоминаются и применяются к встроенному экрану.
- **task-65 (A2): переходы `wipe`, `checker`, `shader`.**
  Шторка (`{dir, soft}`) и шахматка (`{cols, rows}`) рисуются тем же
  спрайтовым батчем (один submit, ≤256 квадов), эталон по скриншоту: при
  `alpha=0.33` левая треть кадра чёрная, правая светлая (0/232); цена перехода
  `0.06` мс против `0.04` мс без перехода на кадр. `shader` идёт нашим
  пост-проходом (wave/distort/chromatic), настройки игры сохраняются и
  возвращаются. Неизвестный тип — `R2D_SCENE_TRANSITION_UNKNOWN` + fallback
  в `fade`.
- **task-65 (A3, дефект I14): смена сцены сбрасывает глобальный свет и
  темноту** (`ambient.off()`, `map({on:false})`, слой источников
  `0xFFFFFFFF`) и VFX-состояние; `{keep_light:true}` сохраняет их. Замер:
  после сцены `lit` (`ambient level 0.85`, lightmap on) → `ambient()===null`,
  `map().on===false`; с `keep_light` — оба остались.
- **task-66 (I11): бюджет/LOD света `$.gfx.light.budget({max,priority,
  radiusScale})`.** 45 источников при `max:32` → `full=32, lod=13,
  degraded=13` (совпадает с числом узлов), треугольники кадра `6480→5544`
  (−14.4 %), кадр `1.57–1.59 → 1.45–1.46` мс. Числа в
  `qualityReport().budget` и `stats().budget*`.
- **task-66 (I12): мерцание эмиттера `.emissive({flicker:{hz,depth,curve}})`.**
  sine/triangle/random от игрового времени, детерминировано при `--fixed-dt`
  (max|Δ| = 0); цена 1000 эмиттеров с общей кривой — медиана −0.006…0.018 мс
  (≤0.02), 1000 разных частот — 0.058 мс; прежний `.flicker(amount,speed)` у
  `<light>` работает (регрессия).
- **task-68: контракт API мира вместо «дока обещает, код не делает».**
  `$.world.remove(target)` — цель обязательна (`R2D_WORLD_REMOVE_NO_TARGET`,
  промах `_MISS`), возвращает число узлов с детьми; `$.world.clear({ui})`
  удаляет игровые узлы, оставляя persistent/HUD/стены `bounds()`
  (15 узлов → 7, тел 12 → 6); `$.world.destroy()` — всё + границы/фон/
  гравитация `0/2000`/`timeScale 1`/pause off → `{nodes:6, bodies:0, …}`.
  `$.collision.of('#hero')` → `'player'` (было `null`); канонический геттер
  сетки — `$.grid.at`, `$.grid.get` не заводится (второй синоним — долг).
- **task-69 (M0): `$.fx` разделён на `$.vfx` (24 метода, r2dvfx) и `$.sfx`
  (5 методов).** `$.fx` остаётся работающим алиасом один минор: одно
  дедуплицированное предупреждение `R2D_FX_DEPRECATED` на СЫРОЕ имя;
  mapping-тест 23 проверки доказывает одинаковый кадр/звук.
- **task-67 (r2dvfx M1–M3, M5): декларативные эффекты.**
  `$.vfx.define/extend/get/list/remove/play/spawn/stats/budget/load/loadAll`
  + хендл `{stop,seek,setRate,query}`; спека `{duration,seed,budget,layers}`;
  16 примитивов `use:`, 22 встроенных эффекта §D3; M5 `clip.<имя>` (кадры с
  двух листов). Валидация: `R2D_VFX_UNKNOWN_PRIMITIVE` со списком допустимых,
  `R2D_VFX_BAD_SPEC`, `R2D_VFX_NOT_DATA` (функции в спеке), `R2D_VFX_UNKNOWN_CLIP`.
  Детерминизм: один `seed` → одинаковые time/progress/hash и кадр. Бюджет
  512 частиц / 16 света: 100 одновременных эффектов при потолке 200 →
  `particles=200`, `degraded>=90`. M4 (предпросмотр в DevTools + экспорт JSON)
  не сделан — записано в `docs/highlevel/vfx.md` §7.
- **task-56 (задача 7): `off` и учёт слотов слушателей UI.**
  `engine.ui.on` возвращает id слота (`doc.on` осознанно остаётся ЦЕПОЧКОЙ —
  возвращает документ: смена на число ломала демо и игры, нашлось полным
  прогоном); `engine.ui.off(doc, el, event
  [, fn])`/`doc.off(...)` снимают и JS-обработчик, и слушателя RmlUi,
  возвращают число снятых; ключ идемпотентности — пара+обработчик (второй
  РАЗНЫЙ обработчик работает: было `[1,0]`, стало `[1,1]`); слоты пула 256
  возвращаются (300 циклов подписка→снятие — 0 ошибок; до правки после 256
  за рантайм всё падало); переполнение — `R2D_UI_LISTENER_LIMIT` с числами;
  `ui_callbacks` показывает живые, `unload` освобождает слот через OnDetach.
- **task-56 (задача 6): смешивание клипов `$.anim.crossfade(target, from, to,
  ms, opts)` + `$.anim.blendInfo(target?)`.** t=0 — 100 % `from`, t=ms —
  100 % `to`; доли монотонны по 29 покадровым замерам, alpha 0.973→0.227,
  x 3.333→96.667; при `--fixed-dt 50 мс` ровно 10 кадров; кадр спрайта
  дискретен (ограничение задокументировано: один draw на узел).
- **Миграция демо и игр на новое имя VFX**: 54 вызова `$.fx.*` в `demos/`,
  `game/`, `witch_game/` переведены на `$.vfx.*` (9 файлов) — иначе
  предупреждение `R2D_FX_DEPRECATED` попадало в «ошибки игрового кода» и
  роняло `demos_test`/`game_test` (нашлось полным прогоном).
- **Д1+Д10: отдельный гейт `tests/api_wrapper_methods_test.py`** — 105
  методов: 35 методов обёрток (`$.ui.doc()`, `$.scene.scope()`) и 70 методов
  ВЛОЖЕННЫХ namespace (`$.gfx.light` 23, `$.gfx.draw` 9, `$.gfx.push` 6,
  `$.world.bsp` 9, `$.sound.bank` 9, `$.debug.draw` 6, `$.debug.profiler` 8).
  Дыра Д1 (`$.ui.doc().layoutRect` прошёл мимо заморозки) и Д10
  (`$.gfx.light.budget` появился мимо снимка) закрыты; список проб явный,
  внутренние `$.ctx.*`/`*._state` не входят.
- **Д3: мусор не уезжает в релиз.** `tools/release.py --check-junk` проверяет
  дерево `dist/`, `SHA256SUMS.txt` и архивы (`.DS_Store`, `__pycache__`,
  `Thumbs.db`); `build_and_push.sh` чистит dist ДО `git add` (раньше чистка
  стояла после) и падает локально при мусоре. На текущем dist проверка нашла
  реальные `dist/.DS_Store` и `dist/macos-arm64/.DS_Store` (2 файла) — удалены,
  повторный прогон: «чисто».
- **Д8-I1/Д13: параллакс больше не забирает позицию узла.** Смещение
  отрисовки вынесено в `draw_off_x/y` (по умолчанию 0): его читают нативный
  проход `src/nodes.c` (быстрый путь, hit-test, Y-sort) и `render.js`
  (`nodeTransform`, свет/тени/бюджет, `_nodeClip`, repeat), а `node.x/y` и
  `.pos()` остаются позицией игры — камера их не меняет. `layers.js` пишет
  `off = (cam − cam_ref) × (1 − f)` и не трогает `x/y`; новое
  `$.layers.offset(node)` отдаёт смещение (freeze 3131 → 3133). Замеры на
  фикстуре `layers`: камера 200 при f=0.5 → `pos` 60 (было 160), `offset`
  100, нарисованное 160; пикинг мышью попадает в нарисованную точку (360,380)
  и НЕ попадает в позицию игры (260,380); `.parallax(null)` — `pos` 260,
  `offset` 0. Тесты переписаны на новый контракт, новый
  `layers_parallax_i1_test` — 11 проверок; `highlevel_layers_test`,
  `layers_parallax_optout_test`, `highlevel_render_parallax_test` (10
  пиксельных) зелёные; `sdk_studios_test` (Parallax Tools) переведён на
  новый контракт: `pos()` стабилен, сдвиг слоёв 300 px проверяется по
  `$.layers.offset` (0.2 → 240, 0.6 → 120). Документация:
  `docs/highlevel/layers.md`, `render.md`, `ENGINE_GAPS.md`.
- **Починен `ReferenceError: ui is not defined` при Escape/back в UI.**
  `tickWidgets` звал `ui.closeTop()`, но `ui` — локальная ссылка `installUiApi`,
  в области видимости `tickWidgets` её нет: при Escape/возврате в меню кадр
  падал. Теперь вызов идёт через module-level `api.ui` с проверкой типа;
  регрессия закреплена в `tests/js/widgets_anchor_test.mjs` (24 проверки),
  `ci_verify` зелёный.
- **АК в Re2D testroom стреляет очередью, а не одиночными.** Раньше все три
  ствола использовали пистолетный одиночный цикл (0→1→2→3→0, 465 мс). Теперь у
  АК режим **AUTO 600 выстр/мин**: цикл сжат до 100 мс, пока ЛКМ/F удерживается,
  каждый законченный цикл сразу начинает следующий; пистолет и дробовик
  остались одиночными. `weapon.auto/rpm` в состоянии, HUD показывает «АВТО»,
  замер: **8 выстрелов за 45 кадров** (~750 мс). `re2d_testroom_test` — 40
  проверок (режим АК + очередь удержанием).
- **Re2D testroom: камера поднята до 76 и врагов можно убивать.** Камера была
  на 48 — билборд 170 «нависал»; теперь глаза на уровне груди (76), рост врага
  150, ближе 180 px он не подходит (не закрывает экран). Появился урон:
  выстрел в прицел снимает hp (пистолет 34, АК 20, дробовик 100 при 100 hp),
  враг падает (строка 6 → строка 7, `DEATH_FALL_MS=350`) и остаётся трупом,
  `weapon.kills` и HUD «убито N» растут; мёртвый выключается из патруля и
  прицеливания. ИИ-атак по-прежнему нет. `re2d_testroom_test` — **38 проверок**
  (прицел, hp, смерть, кадр трупа).
- **Все проверки зелёные: полный агентский набор 265/263/0/2 + repo-тесты.**
  Полный прогон: **265 тестов, 263 ok, 0 fail, 2 skip** (840.3 с;
  `re2d_testroom_test` 34, `sdk_studios_test` 118). Отдельно 27 файлов
  `tests/*_test.py` — 27/27 после трёх настоящих починок:
  * `soundbank.js`: fallback-генератор разброса был `Math.random` — в модулях
    API он запрещён (duplicate_keys); заменён детерминированным LCG, движковый
    `ctx.random` по-прежнему в приоритете;
  * bench coverage: 6 micro-кейсов добавлены (`clip`, `diag`, `hits`,
    `reload`, `sfx`, `vfx`), `real2d`/`rotsprite` явно отнесены к замерам
    `tools/bench.py` (`sprite:1000`, Real2D v4) — `uncovered` пуст, новые
    кейсы реально прогнаны;
  * `site_prune_test`: мок FTP теперь при неудачном DELE отдаёт файл в
    листинге (как настоящий сервер) — тест снова проверяет повтор удаления,
    а не «уже удалено».
  `tools/ci_verify.py` — exit 0 (13 C-Unity-целей/41 кейс + 105 JS + sdk).
- **Все C-тесты переведены на Unity (правило 11).** `r2d_unity`
  (`third_party/unity` v2.6.0) линкуется во все 13 C-целей; ручные
  `check()`/printf-раннеры убраны. Итог: **41 Unity-кейс**, каждая цель —
  `N Tests 0 Failures 0 Ignored` (json 1, crypto 1, payload 4, reverb 1,
  audio_fx 1, profile 1, bsp 5, re2d 14, rotsprite 1, re2d_world 1, exr 1,
  sdk_core 9, audio_spatial 1). `tools/ci_verify.py` с Unity — exit 0 за
  ≈6 с. Правило «новый C-тест — только Unity; Python — только интеграция»
  записано в `docs/AGENT_IMPLEMENTATION_RULES.md` §11 (источник AGENTS.md) и
  [TESTING.md](docs/TESTING.md) §1.2.
- **SDK: возвращены `world-compile`/`world-info` и валидация `.re2dmap`.**
  В коммите «производственной готовности» (2026-10-16) Re2D-слой вырезали из
  SDK, но `docs/re2d/RE2D_WORLD_FORMAT.md` продолжал обещать
  `r2d-sdk world-compile`. Команды восстановлены (`sdk/native/sdk_world.c` из
  истории + native world bake/`bsp`/`json` в SDK-сборке), `.re2dmap` получил
  тип `re2d.world` и валидатор: `r2d-sdk validate testroom.re2dmap` →
  `errors 0`. Проверка компилятора: `world-compile --renderer` на
  `acceptance.re2dmap` даёт JSON, **равный** закоммиченному
  `acceptance.re2dworld` (6 cells, 28 walls, 5 portals, 1 stairs, 1 slope).
- **Re2D testroom переехал на `.re2dmap` + `$.re2dWorld`.** Карта
  `demos/re2d_testroom/testroom.re2dmap` (1600×1200, 12 стен, 4 света)
  компилируется в `testroom.re2dworld`; игра грузит её
  `$.re2dWorld.load(...).backend('gpu')`, а не legacy `$.re2d.room`.
  Ходьба — `world.support/blocked` (глаза +48): W y 1080 → 926.7,
  внутренняя стена y=620, южная y=1183.5, A Δx=−153.3. Враги (атлас 5×8,
  40 кадров) проецируются той же камерой и идут `ui.image`-оверлеем поверх
  мира; стена скрывает целиком по `world.ray` — за внутренней стеной
  `seen=false`, `occluded=2`. Оружие maid_fps_weapons: 3 вида (пистолет/
  дробовик/АК), кадры/тайминги/звуки из `animations.json`, выстрел
  ­0→1→2→3→0 со звуком на кадре 1, R — перезарядка; урона нет
  (`combat: false`). `re2d_testroom_test` — **34 проверки**.
- **Д11/M4: вкладка VFX в DevTools — предпросмотр, перемотка, экспорт.**
  15-я вкладка F1 (`vfx`): список = `$.vfx.list()` (22 встроенных эффекта),
  выбор строки, «Плей» в центре камеры, прогресс/время/seed/hash/degraded из
  `handle.query()`, «−0.1 с»/«+0.1 с», «Стоп» снимает все эффекты; экспорт
  пишет `{effects:{имя:спека}}` (формат сразу читает `$.vfx.load`), отказ
  записи виден в статусе. Публичные `$.devtools.vfx()`, `vfxSelect`,
  `vfxPlay`, `vfxStop`, `vfxSeek`, `vfxExport` — 81 имя, freeze 3125 → 3131.
  Тест `devtools_vfx_test.py` — 24 проверки: список=реестр, плей/прогресс,
  перемотка, экспорт→импорт идентичен (эффект снят из реестра, загружен из
  файла, спеки равны), плюс 13 devtools-тестов зелёные.
- **Д6: веб-сборка перепроверена на текущем дереве.** emsdk 6.0.11 +
  SDL3 с WebGPU (`GPU drivers: openxr webgpu`); сборка дала `russiano2d.wasm`
  57.8 МБ и `.data` 276.8 МБ. Headed-дым в Chrome: `first-frame` →
  `--frames 30` → `shutdown: gpu-idle/script-exit/audio/app/done`, вердикт по
  журналу движка **ok** (2.8 с); кадр не пустой (скриншот). Ограничения
  записаны: пиксельная проверка canvas на WebGPU пустая (`drawImage` не
  читает canvas), headless-дым не дожидается остановки (`--dump-dom`).
  Док-баг: в `docs/WEB_EXPORT.md` не был указан
  `-DFETCHCONTENT_SOURCE_DIR_RMLUI` → конфигурация падала на Freetype;
  исправлено и проверено сборкой.
- **Д2: гейт `tests/doc_examples_test.py` — публичные пути из js-примеров
  доки существуют в живом движке.** 689 уникальных путей `$.a.b.c` из
  `docs/highlevel/*.md`, 687 проверяются (исключение — карта данных
  `$.story.flags.*`), allowlist с причинами, мёртвая строка — провал. Гейт
  поймал бы все шесть ручных находок сессии; уже закрыты: `$.audio.room.define/
  zone/at` (не существуют — `$.audio.room()` функция), `$.inv.value()`
  (метод инвентаря `$.inv.create(...).value()`), `dir.phase()` (свойство-
  геттер), `$.fx.fade` в cutscene (несуществующий метод — шаг молчал).
  Исполнение примеров осталось прототипом (423 запускаются, 53 падения —
  фрагменты/контекст), но нашло SIGSEGV `$.world.bsp.order` до `build()`
  (`bsp_guard_test`) и эти расхождения.
- **Тесты: пилот Unity для C-слоя.** `third_party/unity` — Unity v2.6.0
  (header + `unity.c` + MIT license, без сети/FetchContent). BSP-тест переписан
  на `TEST_ASSERT_*`/`UNITY_BEGIN`/`RUN_TEST`: цель `r2d_bsp_test` даёт
  **5 Tests 0 Failures 0 Ignored, OK** (exit 0), нарочно неверный
  `TEST_ASSERT_EQUAL_INT(2, 3)` печатает `FAIL: Expected 2 Was 3` и возвращает
  1 — CI видит провал без Python. `tools/ci_verify.py` с Unity-целью —
  **5.4 с** (12 C-целей + 105 JS-наборов + sdk batch). План перевода остальных
  C-целей по одной — `docs/TESTING.md` §1.2; сообщения в Unity-тестах ASCII,
  потому что Unity печатает не-ASCII как `\xNN`.
- **Re2D: тестовая комната врагов на билбордах (`demos/re2d_testroom`).**
  Враги — **пиксельный атлас** 5 направлений × 8 состояний (40 кадров,
  198×198): `<enemy>` + `.frames({src,cols:5,rows:8,cw:198,ch:198})` +
  `.size(180,180)` + `.body('kinematic')` + `.kind(Re2D)`, без
  `character.json`/атласа v2. Поворот к камере — выбор колонки по
  `facing − camera.yaw` (0 — лицом, 4 — спиной) + `.flip` для второй стороны;
  ходьба — строки 0..3 по 7.5 кадров/с; строки 4..7 (прицел/выстрел/падение/
  труп) оставлены под бой и не включаются. 6 врагов патрулируют комнату
  1600×1200, замечают игрока ближе 380 px и подходят (298 → 187 px), но не
  атакуют; оружия нет (`weapons: 0`, 0 узлов `weapon`/`bullet`).
  Ходьба: `W` y 1080 → 906.7 без сноса по x, упор во внутреннюю стену y=633,
  южная граница y=1185, `A` Δx=−173.3; камера жёстко на теле (`smooth: 0`).
  Билборд виден по арту (2042 зелёных пикселя при изолированном cat-nw),
  спрятанный враг убирает арт (402); лист = 40 кадров, ходьба реально меняет
  кадры (строки 0..3), поворот даёт col 0 лицом / col 4 спиной и
  переключает зеркало — `re2d_testroom_test` 31 проверка.
  Луч видимости: за внутренней стеной `seen=false`, враг не идёт напролом
  (режим остаётся patrol/idle); в открытую — `seen=true`, дистанция 298 → 187.
  Полировка по ходу: yaw камеры — ГРАДУСЫ (первая версия с `-Math.PI/2` вела
  игрока на восток: x 800 → 973 при y 1080 → 1075), и жёсткое следование
  камеры теперь и в `demos/re2d_world` (было 0.12 «догоняния»).
- **Исправлено попутно (task-65): `dispatchGlobal` падал на `any(null)`** —
  при глобальном событии без подписки на это имя и без wildcard
  (`node === null`) `list.length` у `null` бросал TypeError, и падение съедало
  всё, что шло после dispatch в том же кадре (например, `scene:after-change`).
- **Заморозка API: 3071 → 3125 имён** (+54: `$.vfx` 24, `$.sfx` 5,
  `$.scene.change/state/cancel/loading/promote` 5, `$.anim.crossfade/blendInfo`
  2, `$.fx.pushRibbon`, `$.ctx.vfx/sfx`, `$.world.remove/clear/destroy` и
  русские алиасы `$.мир.*`). `api_docs_sync`: 3125 имён задокументированы
  (2126 буквально + 565 русских алиасов + 376 методов обёрток + 58 приватных).
- **Новые тесты (13 файлов, 419 проверок, все зелёные):**
  `scene_change` 70, `world_api` 63, `grid_read` 14, `collision_of` 16,
  `layers_parallax_optout` 10, `light_budget` 45, `emissive_flicker` 20,
  `anim_blend` 35, `ui_off` 37, `fx_split_mapping` 23, `vfx_registry` 30,
  `vfx_validation` 35, `vfx_determinism` 21; плюс гейт обёрток 5 проверок.
  Красные ДО правки: world_api 45, collision_of 5, layers_parallax 2,
  light_budget 34, emissive_flicker 12, anim_blend 24, ui_off 26,
  fx/vfx 88.
## 1.2.2 — 2026-10-17

<!-- release-notes:begin — генерируется tools/release_notes.py, правьте текст вне маркеров -->

31 коммит в релизе.

### Исправления

- H1 без регрессий: layoutRect() для раскладки, rect() остаётся про видимость (`e19c5fde1`)
  Правка H1 сделала rect() честным (скрытый элемент или предок → null), и это отобрало
  геометрию у тех, кому она нужна ДЛЯ РАСКЛАДКИ, а не для видимости. Три провала одного
  класса в полном наборе: highlevel_reload_test (hud_width() читал rect('hud-line').w и
  получал 0 вместо вычисленной из нового .rcss ширины: 120 → 0), highlevel_animtracks_test
  (rect('fade') is not None проверял «документ загружен», а спрашивал про видимость),
  sdk_shell_test (rect('view-tools').h у СКРЫТОГО экрана → null → TypeError: cannot read
  property 'h' of null).
  РЕШЕНИЕ — два имени, а не флаг: rect() остаётся честным, добавлен
  engine.ui.layoutRect(doc, id) и $.ui.doc().layoutRect(id) — бокс раскладки, работает и
  для скрытого (display:none → нулевой бокс). Флаг {includeHidden:true} отклонён: он
  размывает контракт rect() и возвращает ту самую ложь, из-за которой H1 и появился.
  Правило в ui.md: ВИДИМОСТЬ — rect(), РАЗМЕРЫ ИЗ СТИЛЕЙ — layoutRect().
  …
- task-55 (хвост): копия кадра в render target обеспечивает пайплайн — регрессия ленивого создания (`5fca6afb2`)
  render_target_lifecycle_test падал 3 из 3 после ленивого создания поста.
  Крэш-репорт macOS: r2d__blit_texture → SDL_BindGPUGraphicsPipeline(pass, NULL)
  → METAL_DrawPrimitives → SIGSEGV (KERN_INVALID_ADDRESS at 0xa00). Копирование
  кадра в render target игры идёт ТЕМ ЖЕ пайплайном, что и пост (эффекты
  выключены), поэтому r2d__blit_texture теперь обеспечивает его по требованию:
  показ цели без включённого поста — законный сценарий, а NULL в проходе ронял
  бэкенд. Проверка добавлена и в render_post_lazy_test (цель создаётся,
  показывается, освобождается; счётчик созданий остаётся 1).
  smaa_test: утверждение о цене draw-команд перенесено на 1920x1080 — на 1280x720
  сигнал сравним с шумом (наблюдалось 1.13x при 0.037 → 0.042 мс), числа там
  печатаются. TESTING.md §6.1 и CHANGELOG обновлены.
- Музыка: восстановление после интро (запись трека) — правка, потерянная при переключении ветки (`421291d6f`)
  Правка runtime-assets, которая делает зелёными highlevel_ui_contract (76) и
  highlevel_timeline (39): $.sound.music() получал ЗАПИСЬ трека {path, volume} из
  ctx.state_music (timeline кладёт её в снапшот), а soundId() умел только путь/число —
  load() падал МОЛЧА, и restored.music превращался в "stopped".
  ОДИН путь (согласовано): снапшот хранит запись, разворачивает её $.sound.music() —
  единственная точка, знающая формат. Плюс перестали стирать ctx.state_music при снятии
  звука сцены (иначе снапшот видел track: null и восстановление молча превращалось в
  «остановить музыку»).
  Коммит восстановлен после инцидента: рабочая копия стояла на диагностической ветке
  profiler-core, поэтому часть вечерних коммитов (H1, H5/H11, H6/H8/H9/H10, доковые
  гейты, H7/H12, I13/I5, I3, пакеты dist) ушла не в main. Восстановлено merge-ем ветки
  rescue/bashnya-i (база 8214303 — общий предок, конфликт был только в CHANGELOG,
  …
- task-59: отказ снимка агента слышен (R2D_AGENT_SNAPSHOT_FAILED) + прочёсан класс map(nodeBrief) (`c24e4c475`)
  - cmd_state: при падении провайдера в ответе state.error {code,message}, в журнале
  R2D_ERROR вместо R2D_WARN; JS-провайдер дублирует в $ .debug.errors()
  - $.agent.nodes: .map(nodeBrief) -> явное замыкание (тот же класс, что регресс)
  - agent_entity_state_test: снимок ломается намеренно, проверяются все три канала
  (32 проверки); аудит класса: devtools-колбэки однопараметровые — безопасны
  - docs/AGENT_API: как выглядит помеченный отказ снимка
- task-59 регресс: снимок агента падал на втором UI-узле (nodeBrief получал индекс как fields) (`08507296d`)
  - ui_nodes.map(nodeBrief) передавал индекс вторым аргументом, а nodeBrief
  получил параметр «какие поля просили» -> want.has у числа = TypeError
  - фикс: want instanceof Set + явное замыкание для ui-узлов
  - проверка в agent_entity_state_test.py (22 проверки): снимок с тремя ui-узлами
  и «снимок настоящий, а не аварийный минимум»; на дефекте падает 2 из 22
  - highlevel_timeline_test снова зелёный (39 проверок)
- Одно событие — одно имя: animEnd убран, фикстур переведён на anim:end (`c236ea2ae`)
  Решение лида: два имени для одного события — тот же разнобой, который мы вычищали весь
  день ($.find против $(), mask('#нет-такого'), appendTo('#selector')). Пока это публичный
  API, у него должна быть одна форма, поэтому вместо «прежнее имя, для совместимости»
  прежний эмит удалён.
  - src/highlevel/api.js — эмит animEnd удалён, осталось только anim:end;
  - tests/fixtures/activation/main.js — переведён на 'anim:end' (зона согласована с лидом);
  - docs/highlevel/clip.md — формулировка «прежнее имя» убрана;
  - CHANGELOG — сказано, что animEnd УБРАН и фикстур переведён.
  Проверки: highlevel_activation, highlevel_timeline (39), clip_events — зелёные;
  api_freeze rc=0. Поиском по src/, tests/, docs/ упоминаний animEnd больше нет (осталась
  только переменная animEnds в тесте — это счётчик в $.store, не событие).
  I16 (шум и --seed) записан в CHANGELOG как РЕЗУЛЬТАТ ПРОВЕРКИ «дефекта нет» с числами:
  …
- BASHNYA I10 (частично) + музыка: uid узла пула, снапшот музыки, детерминизм порядка (`dbdc6b68a`)
  I10 — «при равной глубине порядок отрисовки не воспроизводится» НЕ подтвердился в части
  сортировки: ключ layer → depth → uid одинаков в JS и в нативном пути (nodes.c cmp_keys),
  два независимых прогона дали один кадр; appendTo порядок не меняет, detach/hide/show тоже.
  НО внутри пункта нашёлся настоящий дефект: узел ПУЛА сохранял uid ПЕРВОГО создания,
  поэтому свежая выдача вставала ПОД ранее выданными — порядок зависел от истории
  переиспользования. Замер до правки: release(P1) + spawn(P3) → uid 11, сверху жёлтый P2
  (uid 12), тест красный (5 ok / 1 fail); после: uid 15, сверху P3 (255,0,255). Правка:
  refreshUid(node) в core.js + один вызов в выдаче пула (pool.js — вне списка файлов задачи,
  отмечено автором; откат — одна строка). Контракт с числами — render.md §4.5, страж —
  draw_order_test.py (6 проверок). Вокруг зелёные: presentation 42, pool 54, hits_pool 21,
  frame_order 22, save_presentation 11, doc_claims 37.
  I2 и I7 (дубли H10/H6) — ПОДТВЕРЖДЕНЫ замером, не переделывались: .size(96,48) +
  …
- BASHNYA I3: события клипа (`anim:frame`/`anim:end`) — один путь внутри, сахар снаружи (`047dd2800`)
  Сделано по требованию лида «внутри должен быть ОДИН путь»: первичны СОБЫТИЯ УЗЛА,
  `onFrame`/`onEnd` в $.clip.define(...) — тонкая подписка на те же события (два
  независимых механизма «клип доиграл» разъехались бы — этот класс пар мы чинили весь день).
  Повторное .animate({clip}) снимает прежние подписки, иначе «доиграл» стрелял бы дважды
  (проверено тестом).
  РЕШЕНИЕ ПО ПЕТЛЕ (в доке и CHANGELOG): loop:false — одно событие за проигрывание (и ещё
  одно после повторного запуска); loop:true — НА КАЖДОМ ОБОРОТЕ, номер оборота в loops. Так
  слушатель может и «дождаться конца», и считать циклы, не заводя второй механизм.
  ЧИСЛА (tests/agent/clip_events_test.py, 10 проверок): anim:frame несёт {frame,
  frame_in_clip, clip} и срабатывает на СМЕНЕ кадра, а не на каждом тике (onFrame → [0,1,0]);
  anim:end → ровно [1] за проигрывание и снова одно после перезапуска; loop:true при fps=20
  за 30 кадров → 25 событий с номерами 1..25; off() снимает подписку (после снятия — ноль
  …
- BASHNYA H6 + H8 + H9 + H10: обёртки из $.find, зона активации, белый список hits, размер узла (`5609ef46f`)
  H6 (несогласованность) — исправлено: $.find('.goblin') отдавал СЫРОЙ Array из Node, у
  которого .get(0) → undefined (там get — геттер АТРИБУТОВ), а .size — ЧИСЛО. Стало:
  $.find → обёртка, как $() (итерируемая: прежний for (const n of $.find('*')) в
  devtools_physics_test работает без правок), сырой массив — явный $.findNodes(sel).
  Числа после: Wrapper, .length 3, .get(0).tag 'enemy', $.find('#hero').size() = {w:28,h:40},
  $.findNodes('.goblin') → Array.
  H10 (дефект) — исправлено: setSprite() брал размер у спрайта по эвристике
  this.w === 32 || this.w === 0, то есть явный .size(32,32) был неотличим от «не задавали».
  Замер до: .size(32,32) + .frames({cw:128,ch:32}) → 128x32. Стало: флаг size_locked (его
  ставят .size(), поля .w/.h, атрибуты {w,h}), авторазмер из спрайта сохранён для узлов без
  размера: .size(32,32)+cw128 → 32x32, без .size() → 128x32 (совместимость). 11 регрессий
  зелёные (tile_geometry, tilemap x3, litsprites, sprite, rotsprite, emissive,
  …
- BASHNYA H5 + H11 и три бага музыки: pitchRange, $.clip, честный отказ загрузки, симметрия имён (`859529862`)
  H5 (разброс pitch): причина — генератор по умолчанию () => 0 в bankPitch, поэтому
  диапазон ВСЕГДА давал нижнюю границу (12 вызовов playBank → высота 1.000 каждый раз).
  Теперь дефолтный RNG движковый (ctx.random, сид из --seed): банк с pitch:[0.96,1.04] даёт
  12 РАЗНЫХ высот из 12 (0.967-1.032); pitchRange:[0.9,1.1] разбрасывает; pitch:1.25
  остался множителем (1.208-1.285). В CHANGELOG отмечено как ИЗМЕНЕНИЕ ПОВЕДЕНИЯ для игр,
  которые уже объявили pitch:[lo,hi] — звук начнёт варьироваться. $.sound.stemsState()
  теперь публичен и в тесте сверяется с engine.audio.stemsState() один в один.
  H11 (клипы): новое пространство $.clip (define/get/list/remove); frames — спрайты или
  регионы {src,x,y,w,h} С РАЗНЫХ ЛИСТОВ; .animate({clip}) и .animate('walk') берут
  fps/loop/pivot; pivot двигает только точку вращения, размер узла НЕ меняется (граница с
  H10, которую закрыл другой исполнитель). Числа: клип из двух листов (frames:2, skipped:0)
  играет, fps:8/loop:false/pivot:[0.5,1] соблюдаются, размер остаётся 32x48.
  …
- BASHNYA H1: doc.hide(id) скрывает ЭЛЕМЕНТ, rect() не врёт про скрытое (`a94e8e613`)
  Репро BASHNYA: $.ui.doc('ui/menu.rml').hide('petals') скрывал ВЕСЬ документ, а
  rect('petals') продолжал отдавать прежние размеры — из-за этого их автопроверка
  «элемент есть и у него есть размер» была зелёной и ничего не доказывала.
  ДВЕ ЧАСТИ ДЕФЕКТА (вторая нашлась по ходу):
  1. doc.show()/hide() с аргументом вызывали engine.ui.hide(id) ПО ДОКУМЕНТУ, аргумент
  молча игнорировался. Теперь: без аргумента — документ (обратная совместимость), с
  аргументом — ЭЛЕМЕНТ.
  2. r2d_gui_get_rect() отдавал бокс скрытого элемента. Теперь ходит по ПРЕДКАМ до корня
  и возвращает «невидим», если скрыт сам элемент или любой предок (иначе rect()
  продолжал бы врать ровно в сценарии, ради которого всё и делается).
  3. ПОПУТНО: show(element) не возвращал элемент, потому что
  engine.ui.setProperty(doc, el, 'display', '') ставил ПУСТОЕ значение вместо снятия
  …
- dist: обновлённые macOS-пакеты для передачи BASHNYA (дока + фиксы после 1.2.1) (`98bb8029d`)
  Пересобрано перед выдачей движка в чужой проект: в пакеты вошли правки, сделанные
  ПОСЛЕ релизного тега v1.2.1 — F2 (кадр сценки экранным оверлеем), F4 (cast без арта не
  рисует слот), G1 (смена сцены снимает звук уходящей сцены), E10 (shader(false)),
  F3 ($.gfx.stats() со счётчиками текстур) — и обновлённая дока внутри поставки
  (render.md, resource.md, UI_RMLUI_LAW.md и др.).
  Выдано в /Volumes/SSD NVME/p2game/bashnya/engine/macos-arm64 (старый комплект сохранён
  как macos-arm64.bak-1.2.0): бинарник md5 b071bc906b11c6c5f6287387b01b04d8, размер
  16 575 808 байт, sha256 b85f296bfea92b8d4089d03650f33a19069dc76a1fd066706ad8a24a7a3a722e,
  252 файла прошли shasum -c.
  Версия в пакете остаётся 1.2.1 (следующий выпуск — 1.2.2 со всем накопленным: тег v1.2.1
  уже не отражает содержимое main).
- Закон UI: исключение для панели реплик сценок + условие его снятия (`bfbe3bc6b`)
  Продолжение F1 (BASHNYA): закон требует RmlUi для нового интерфейса, а панель реплик
  $.story собрана на legacy <ui.*>. Решение лида: (б) сейчас — зафиксировать исключение,
  (а1) отдельной задачей в 1.2.2.
  В §3 добавлен абзац: что именно исключается (__story_box/__story_who/__story_line и
  кнопки выбора — СУЩЕСТВУЮЩИЙ код, а закон запрещает <ui.*> именно для нового, §5.2
  «существующие игры не ломаем»); что легальный путь уже есть и работает ($.timeline +
  dialogView {kind:'rml'}, demos/ui/vn-dialog.rml — вступление BASHNYA сделано так и
  правок движка не потребовало); числа оценки (а1) — 84-120 строк JS, 90-110 разметки,
  80-120 тестов, ~20 доки, итого ~270-380 строк и 4-6 часов с визуальной проверкой (у
  таймлайна на тему кнопок и подъём оверлея ушли отдельные итерации); почему (а2)
  отклонён (400-600 изменённых строк, риск регрессий по 144 проверкам story/dialog/
  timeline/cutscene); условие снятия — абзац удаляется, когда у $.story появится
  …
- BASHNYA F2 + F4: кадр сценки — экранный оверлей; cast без арта не рисует слот (`9c8e64b24`)
  F2 — воспроизвелось, причина оказалась ДВОЙНОЙ (у BASHNYA выглядело как два
  симптома): (1) затемнение сценки __story_fade создавалось НЕПРОЗРАЧНЫМ (alpha 1) и
  рисовалось поверх кадра — при старте из enter() кадр был закрыт им же (замер: скрыть
  затемнение — яркость 240.0, с ним — 0.0); (2) весь оверлей (кадр, полосы, окно
  реплики) был МИР-узлами в мировых координатах — уезжал с камерой и проигрывал по
  глубине любому мир-узлу.
  Замер (белый кадр на весь экран, яркость центра):
  | случай                        | до  | после |
  | старт сценки из enter()       | 0.0 | 255.0 |
  | камера уехала в (5000, 5000)  | 0.0 | 255.0 |
  | мир-узел depth: 100           | 0.0 | 255.0 |
  | fade out → fade in            | 0.0 → 255.0 | 0.0 → 255.0 (инвариант) |
  …

### Добавлено

- task-63 (I17): $.physics.shapeEnabled/shapeCount — выключить коллайдер, оставив тело (`63cd2f1c3`)
  - $.physics.shapeEnabled(what, index = 0, on?) — геттер/сеттер формы тела,
  обёртка над engine.setShapeEnabled/shapeEnabled 1:1;
  - $.physics.shapeCount(what) — сколько форм у тела;
  - замер: форма выключена → bodyEnabled остаётся true, герой проваливается
  (390 → 658), включение возвращает опору; индекс вне диапазона → false;
  - body.disable() намеренно НЕ добавлен: 'выключить тело' уже есть —
  processing({physics:false}) (§44), третий синоним не нужен;
  - sensor(true)/mask(0) — другие инструменты: тело продолжает падать
  (390 → 569 / 390 → 596), это измерено и записано в physics.md;
  - docs/highlevel/physics.md: таблица «что нужно → чем» + искомые слова
  (body.disable, выключить тело/коллайдер, отключить физику узла);
  - тест tests/agent/physics_shape_enabled_test.py: на старом коде 10 провалов.
  …
- BASHNYA I13 + I5: NaN в шейдерах больше не молчит; предзагрузка текстур по пути (`691c7a0ae`)
  I13 (дефект) — воспроизведён на старом коде: .shader('wave', {amplitude: NaN,
  frequency: 30}) → {amplitude: null, frequency: 30}, то есть NaN проходил и в fxSpec
  молча подменялся значением по умолчанию («эффект не работает», причины не видно);
  опечатка {amplitud: 0.5} принималась молча; .shaderParam('frequency','abc') записывал
  строку. Сделано: таблица допустимых параметров по эффектам (ровно те имена, что читает
  fxSpec: flash amount/color; dissolve threshold/scale/color; chroma offset/color; wave
  amplitude/amount/frequency/phase/time/color) + проверка типа в обоих входах; неизвестное
  имя и нечисло ОТКЛОНЯЮТСЯ со структурной ошибкой R2D_SHADER_PARAM_INVALID (subsystem
  'shader', recoverable, в сообщении имя параметра и СПИСОК допустимых).
  Числа после: {amplitude: NaN, frequency: 30} → применён только frequency; {amplitud:0.5}
  отклонён; 'abc' не затёр прежнее значение 30; эффект на узле остался wave. Тест
  shader_param_validate_test: старый код rc=1, новый rc=0 (10 проверок).
  …

### Документация

- task-64 (хвост): smaa_test — сигнал цены берётся лучшим из минимума и медианы окон (`432c03b34`)
- task-62 (I17): $.version() и capabilities — что умеет этот билд (`d766278e2`)
- Доковые гейты зелёные: страница $.clip, приватный ctx._clip, документированный $.audio.musicStop (`32da6d611`)
- BASHNYA G1: смена сцены снимает звук уходящей сцены (код приведён к доке) (`821430358`)
- Перепакованы macOS-пакеты 1.2.1: дока внутри поставки актуальна (`692ca4c6b`)

### Тесты и гейты

- task-64: blend_golden_test больше не флакует под нагрузкой — журнал движка читается с ожиданием (`fae974c3e`)
- debug-55: уникальная группа concurrency + сценарий E (гейт краснеет на подделанном эталоне) (`fd03fdc17`)
- task-59 H7+H12: $.fn.expose и наблюдаемое состояние сущности, $.agent.has, тесты агентского режима (`9bbddfbfb`)
- debug-55: диагностический пайплайн для падений CI 1.2.1 (ASan/UBSan, aarch64+x86_64) (`533e3a935`)

### Сборка и версии

- Убран диагностический workflow debug-55 (задача решена) (`311e592dc`)
- task-55: пайплайн пост-обработки создаётся лениво — движок больше не падает на старте на программном Vulkan (`6d6020436`)
- debug-55: ref/sanitize входные параметры, сборка без LeakSanitizer и с узкими целями (`e127329b8`)

### Прочее

- gui.h: объявление layoutRect (продолжение правки H1) (`001707626`)
- debug-55: сценарий D — агентский старт без xvfb (offscreen/dummy) (`395fb656b`)
- debug-55: checkout с полной историей и локальным переключением на ref (SHA-фетч GitHub не отдаёт) (`4866825ff`)

<!-- release-notes:end -->

### Подробности (написано вручную)

Текст ниже перенесён генератором из разделов «Не выпущено» без изменений (опущен только уровень заголовков).

### Не выпущено — флаки под нагрузкой: три теста класса «плывёт под нагрузкой» (task-50, task-64, 2026-10-17)

Полный набор на нагруженной машине красил релиз трижды, при том что по отдельности
каждый тест был зелёным: `smaa_test` (1 из 4 при load 4.9-6.9), `net_delay_test`
(шум пакета) и `blend_golden_test` (2 из 5 при load 3.6-4.0).

- **`blend_golden_test`** — плыло не сравнение пикселей, а чтение **асинхронного
  журнала**: список режимов берётся из сообщения движка «доступны: …», и тест
  читал `stderr` **один раз** сразу после `eval` — на нагруженной машине строки
  ещё нет («движок сам назвал доступные режимы: сообщения нет»). Теперь ожидание
  **с пределом** (25 шагов по кадру) и диагностика хвостом журнала. 6 прогонов
  под нагрузкой — зелёные (было 2 провала из 5). Допуски не менялись; негативные
  контроли: сломанная формула альфы → 2 провала, чужой эталон → 6, отсутствие
  строки журнала → 1 с хвостом.
- **`smaa_test`** — цена прохода сравнивалась по одному окну, а на 1280x720 сам
  эффект (~0.015 мс) меньше шума. Теперь медиана нескольких окон и допуск из
  измеренного разброса. Остаточную слабость нашли на 1920x1080: **1.15x по
  минимуму окон против 1.55x по медианам** (0.0408 → 0.0467 против 0.0413 →
  0.0642 мс) — сигнал берётся лучшим из двух устойчивых статистик
  (`max(min_ratio, median_ratio) > 1.2`), выключенный SMAA даёт ~1.0x по обеим.
- **`net_delay_test`** — реальное время и порт: свободный порт у системы вместо
  константы, ожидание по `time.monotonic()`, «ещё не дошёл» = «не дошёл **или**
  сам кадр был длиннее задержки».
- **Правило записано** в `docs/TESTING.md` §6.1 («Рецепт: флак под нагрузкой»):
  не читать асинхронный источник один раз; числовые сравнения — по нескольким
  окнам с допуском из разброса; утверждение там, где сигнал выше шума; время и
  порты — из системных источников; обязательный негативный контроль, иначе
  дефлак равен отключению проверки.


### Не выпущено — H1 без регрессий: `rect()` честный, `layoutRect()` для раскладки (task-56, 2026-10-17)

После честного `rect()` (скрытый элемент → `null`) упали три проверки, которые
читали геометрию скрытого элемента: `highlevel_animtracks_test`,
`highlevel_reload_test` («ширина 120 → 0»), `sdk_shell_test`
(`TypeError: cannot read property 'h' of null`). Разбор: это не «тесты сломались»,
а **нехватка второго доступа** — видимость и раскладка это разные вопросы.

- `engine.ui.layoutRect(doc, id)` и `$.ui.doc().layoutRect(id)` — бокс раскладки,
  работает и для скрытого элемента (`display:none` → нулевой бокс). Новые
  публичные имена; заморозка API не изменилась (проверено `api_freeze_test`).
- Вызывающие переведены на правильный вопрос: `tests/fixtures/reload/main.js`
  (`hud_width()` — это вычисленная из `.rcss` ширина), `highlevel_animtracks_test`
  («документ загружен и элемент разложен»), `sdk_shell_test` (скрытый экран:
  `rect()` → `null` **и** `layoutRect().h` = 0 — проверяются оба факта),
  `sdk/lib/studio_host.js`, `sdk/tools/animation-studio.js`.
- Числа: три падавшие проверки — «Все проверки пройдены» после правки;
  `highlevel_animtracks_test`, `highlevel_reload_test`, `sdk_shell_test` зелёные.
- Документация: `docs/highlevel/ui.md` — «`rect()` и `layoutRect()`: видимость
  против раскладки» с правилом выбора.


### Не выпущено — движок не падает на старте на программном Vulkan (task-55, 2026-10-17)

На Linux-раннерах с программным Vulkan (Mesa lavapipe) движок **не запускался
вообще**: SIGSEGV внутри `vkCreateGraphicsPipelines` на создании пайплайна
пост-обработки — до первого кадра, в агентском режиме и в `r2d-sdk run`
(стек и разбор: `docs/TESTING.md` §6.1). Это не регрессия конкретного коммита:
на заведомо зелёном коммите и на `v0.1.35` поведение то же.

- **Сделано**: пайплайн пост-обработки создаётся **лениво** — при первом запросе
  эффектов (или SMAA), а не на старте движка. Игре, которой пост не нужен, GPU
  за него платить нечем: кадр идёт прямо в swapchain, как и раньше при
  выключенном посте. Повторные включения второй пайплайн не создают.
- **Без тишины**: если пост запросили, а пайплайн не создался, это видно игре —
  `renderInfo().post_error` с причиной от драйвера и строка `R2D_ERROR` в
  журнале; режим честно выключается, а не «эффект просто не работает».
- **Новое поле статистики**: `engine.renderInfo().post_pipeline_creates` — сколько
  раз пайплайн реально создавался (0 — пост не просили).
- **Копия кадра в render target игры** идёт тем же пайплайном (все эффекты
  выключены), поэтому он вызывается по требованию и там: без этого в проход
  уходил NULL и бэкенд падал на показе цели — регрессия ловится тестом
  жизненного цикла render target'а и отдельной проверкой в новом тесте.
- **Тест**: `tests/agent/render_post_lazy_test.py` (21 проверка) — падал до
  правки, проверяет свойство, а не «драйвер не упал»: ленивое создание, ровно
  одно создание, переиспользование при выключении и для SMAA,
  `postSupported()` — про возможность, а не про факт, и показ render target'а без
  включённого поста (сценарий регрессии).


### Не выпущено — BASHNYA I17: коллайдер можно выключить, тело при этом живёт (task-63, 2026-10-16)

**Добавлено: `$.physics.shapeEnabled(what, index = 0, on?)` и
`$.physics.shapeCount(what)`.** Пара повторяет C-биндинги 1:1
(`engine.setShapeEnabled` / `shapeEnabled` / `shapeCount`), новых смыслов не
вводит; `what` — узел, обёртка или селектор, без `on` — геттер. Закрывает
реальный пробел из I17: «выключить коллайдер, оставив тело» жило только на
C-уровне, и им пользовался один `$.anim`. Замер на живом движке (герой 28×40 на
статичной платформе, покой `y = 390`): `shapeEnabled('#hero', 0, false)` → форма
выключена, **`engine.bodyEnabled()` остаётся `true`**, герой проваливается сквозь
платформу (`y 390 → 658`); `..., true` возвращает опору; индекс вне диапазона —
`false`.

**`body.disable()` намеренно НЕ добавлен** (решение lead, зафиксировано здесь,
чтобы не предлагали снова): «выключить ТЕЛО» в движке уже есть — это
`$('#x').processing({ physics: false })` (§44, внутри `engine.setBodyEnabled`),
и `body.disable()` стал бы третьим именем для той же операции. Замер: в падении
тело замирает (`y 117.1 → 120.6` и дальше не меняется), `bodyEnabled = false`,
луч и столкновения его не видят. Отдельно выяснено, что `sensor(true)` и
`mask(0)` — **другие** инструменты: тело продолжает жить и падать
(`y 390 → 569` и `y 390 → 596`), поэтому заменой выключению они не являются.
Discoverability закрыта докой: в `physics.md` раздел «Выключить тело / коллайдер
/ сенсор» с таблицей «что нужно → чем» и явными искомыми словами
(«body.disable», «выключить тело», «выключить коллайдер», «отключить физику
узла»).

Числа: тест `tests/agent/physics_shape_enabled_test.py` на старом коде —
**ПРОВАЛЕНО 10**, на новом — зелёный. Заморозка обновлена осознанно (+2 имени).


### Не выпущено — BASHNYA I17: `$.version()` и `capabilities` — что умеет этот билд (task-62, 2026-10-16)

- **Было (замер):** `$.version` — `undefined`, `$.platform` — `undefined`,
  `$.web` — `undefined`; известно было только `engine.version` (свойство низкого
  уровня) и точечный `$.agent.has(...)`. Игра обходила это **16 пробами**
  «есть ли метод» (`player.js:310,346`, `bootstrap.js:198,303,561,619,676,773`,
  `lighting.js:180,199,248,267,296,299,463`, `lighting_props.js:545-550`,
  `level1.js:737`, `fx/shaders.js:61`) — и каждая врёт по-своему, когда метод
  переименовали.
- **Добавлено:** `$.version()` (версия одной функцией) и команда `capabilities`
  (+ `$.agent.capabilities()` из JS): версия, платформа, драйвер GPU, режим
  агента и наличие подсистем — `audio`/`channels`/`hrtf`/`net`/`physics`/
  `timeline`/`ui`/`web`. Платформу и GPU подставляет C (`SDL_GetPlatform`,
  `SDL_GetGPUDeviceDriver`) — в JS их взять негде.
- **Числа (замер):** ответ `capabilities` — **306 Б** (в нём же поле
  `probe:"has"`, чтобы клиент не догадывался, чем спрашивать имена), ответ `has`
  на одно имя — **51 Б**; 16 проб игры давали ≈**816 Б** и разъезжались с
  реальностью. Полного списка имён (3000+, ≈**60 КБ**) нет ни там, ни там —
  это уже раздувало снимок до 168 КБ (A8).
- `systems.hrtf` — **фактический** бэкенд (`'steam'` | `'synthetic'` | `false`),
  а не «собран ли Steam Audio»: проверяется согласованность с `$.audio.hrtf()`.
- Доки: `docs/AGENT_API.md` §3 (строка команды) и новый §7.5 (форма, пример,
  таблица «какой вопрос чем спрашивать» с числами). Заморозка: +2 имени (3069).
  Тест: `tests/agent/agent_capabilities_test.py` (20 проверок, падает до правки).


### Не выпущено — порядок отрисовки при равной глубине: контракт и страж (task-60, I10)

Пункт I10 второго прохода BASHNYA («при равной глубине порядок отрисовки не
воспроизводится между прогонами»).

- **Не воспроизвелось как дефект — воспроизвелось как недописанный контракт.**
  Замеры на живом движке: два узла на одной глубине (`layer` 0, `depth` 0, `y`
  300) дают один и тот же кадр в двух независимых прогонах — сверху тот, кто
  создан позже (`uid` 9 против 8: 0,0,255 против 255,0,0); оба пути сортировки
  (JS и нативный `engine.nodes.sortWorld`) используют один компаратор
  `layer → depth|y → uid` (src/nodes.c: `cmp_keys`).
- **Что реально меняет картинку** (замерено): повторный `appendTo()` — **нет**
  (цвет в точке не изменился), `.detach()/.hide()/.show()` — нет; а вот
  **пересоздание** узла даёт новый `uid` и уводит его наверх (0,0,255 → 255,0,0).
  Узел, переиспользованный пулом после `release()`, получает новый `uid`
  (8/9 → 10) и тоже рисуется поверх. Отдельного `bringToFront()`/`zIndex` внутри
  одной глубины нет — порядок внутри глубины и есть порядок создания.
- **Найден и исправлен один настоящий дефект внутри этого же пункта**: узел,
  живущий между выдачами (пул), сохранял `uid` ПЕРВОГО создания, поэтому свежая
  выдача вставала НИЖЕ ранее выданных, а порядок зависел от истории
  переиспользования — между прогонами он не воспроизводился. Замер до правки:
  после `release(P1)` + `spawn(P3)` узел получил `uid 11` и остался под `P2`
  (`uid 12`), сверху — жёлтый `P2`; после правки `uid 15` и сверху `P3`
  (255,0,255). Правка: `refreshUid(node)` в `core.js` + один вызов в выдаче
  пула (`pool.js`) — **файл вне списка задачи, поэтому отмечаю отдельно**.
- **Сделано**: контракт описан в `docs/highlevel/render.md` §4.5 (с числами) и
  закреплён стражем `tests/agent/draw_order_test.py` (6 проверок; проверка пула
  была красной до правки: `5 ok / 1 fail`). Прогоны вокруг: presentation 42,
  pool 54, hits_pool 21, frame_order 22, save_presentation 11 — зелёные.


### Не выпущено — BASHNYA I3: события клипа (task-61, 2026-10-16)

У покадровой анимации не было ни события «клип доиграл», ни событий кадров —
игра не могла узнать, что анимация закончилась (`animEnd` существовал, но не был
документирован и не нёс номера кадра).

- **События узла** (один путь, без второго механизма): `anim:frame` — кадр
  сменился, несёт `{frame, frame_in_clip, clip}`; `anim:end` — клип доиграл,
  несёт `{clip, loops}`. `onFrame`/`onEnd` в `$.clip.define(...)` — сахар,
  подписывающийся на те же события; повторное `.animate({clip})` снимает прежние
  подписки (обработчик не сработает дважды). Прежнее имя `animEnd` УБРАНО:
  одно событие — одно имя (фикстур `tests/fixtures/activation` переведён на
  `anim:end`).
- **Решение по петле** (описано в доке): при `loop: false` событие одно за
  проигрывание (и ещё одно при повторном запуске), при `loop: true` — на КАЖДОМ
  обороте, с номером оборота в `loops`.
- **I16 (шум и `--seed`) — проверено на 1.2.x: дефекта нет.** `--seed 111` даёт
  шум `[0.345884, 0.487957, 0.545027]`, `--seed 222` — `[0.577027, 0.503532,
  0.454973]`; тот же сид воспроизводит те же значения, поток `$.random.next()`
  тоже различается по сиду (0.990114 против 0.217838). Наследование `--seed`
  шумом и потоком работает (правка C1); пункт закрыт проверкой, кода не требует.
- **Числа** (`tests/agent/clip_events_test.py`): `onFrame` → [0, 1, …] с номерами
  кадров; `anim:end` ровно один раз за проигрывание и ещё раз после повторного
  запуска; при fps=20 и `loop: true` за 30 кадров — 25 событий (по одному на
  оборот); `off()` снимает подписку, после удаления узла события не идут; цена —
  40 узлов × 50 кадров: 415 мс без подписок и 415 мс с подписками (разница ниже
  шума измерения).


### Не выпущено — BASHNYA I13 + I5: параметры эффекта и прогрев текстур (task-61, 2026-10-16)

- **I13 (дефект, закрыт)**: `.shader('wave', { amplitude: NaN })` и опечатка
  `{ amplitud: 0.5 }` проходили МОЛЧА — параметр подменялся значением по
  умолчанию, эффект «не работал». Теперь у каждого эффекта таблица допустимых
  параметров (ровно те имена, что читает `fxSpec`), проверка типа в `.shader()` и
  `.shaderParam()`, отказ уходит структурной ошибкой `R2D_SHADER_PARAM_INVALID`
  (`subsystem: 'shader'`) со списком допустимых. Числа: `{amplitude: NaN,
  frequency: 30}` → применён только `frequency`; `{amplitud: 0.5}` → отклонён;
  `.shaderParam('frequency','abc')` → прежнее значение сохранено. Тест
  `tests/agent/shader_param_validate_test.py` (падает до правки).
- **I5 (расширение)**: `$.resource.preloadTexture(path | [paths])` →
  `{loaded, failed, failedPaths, mb}` — прогрев текстур **по пути без узлов**
  (раньше игра «грела» их выбрасываемыми спрайтами) и
  `$.resource.textureStats()` → `{count, mb, users}` для полоски прогресса.
  Числа: `preload` по пути давал `{loaded: 0, failed: 1}` и текстур 2 → 2;
  `preloadTexture` двух файлов — `{loaded: 2, mb: 8}`, текстур 2 → 4 (0.25 → 8.25 МБ),
  несуществующий путь попадает в `failedPaths`, прогретую текстуру можно
  освободить (`busy: false`, вернулось 4 МБ). Тест
  `tests/agent/texture_preload_test.py` (падает до правки). Заморозка API
  обновлена осознанно: два новых имени.
- **I3/I15/I16** — следующим заходом (форма I3 согласуется отдельно).


### Не выпущено — BASHNYA H7 + H12: наблюдаемое состояние сущности и агентский режим (task-59, 2026-10-16)

- **H7. У сущности не было объявляемого наблюдаемого состояния.** Добавлено
  `$.fn.expose`: `expose()` — копия объявленного, `expose({clip:'walk',alert:2})`
  — слияние, `expose('clip')` / `expose('alert', 3)` — один ключ,
  `expose('alert', undefined)` — снять. Имя `expose`, а не `state`, потому что
  `$.fn.state()` — геттер машины анимации (`anim.js:611`), публичный метод
  перегружать нельзя. В снимке агента — только по запросу:
  `{"cmd":"state","entities":{"fields":["id","exposed"]}}`; состояние FSM видно
  и без объявления — `fields:["id","state","state_time"]` (это закрывает
  исходный пример H7 с `attrs.clip` без нового API). Лимиты: только примитивы,
  ≤32 ключа, строки ≤64 символов, вложенное → `null`.
  **Замер размера снимка на 200 узлах:** по умолчанию 37 519 Б и **те же
  37 519 Б** после того, как состояние объявили все узлы; `fields:["id"]` —
  4 029 Б, `fields:["id","exposed"]` — 30 221 Б (в тесте каждый узел объявил
  строку в 64 символа — верхняя граница), `fields:["id","state","state_time"]` —
  10 452 Б. Тест `tests/agent/agent_entity_state_test.py` (22 проверки).
  Публичная поверхность: +1 имя (`api_freeze` 3065).
- **Регресс, поймал `highlevel_timeline_test`:** `ui_nodes.map(nodeBrief)`
  передаёт вторым аргументом ИНДЕКС, а `nodeBrief` получил второй параметр
  «какие поля просили» — на втором UI-узле (индекс 1) снимок падал с
  `TypeError: not a function` (у числа нет `.has`). Заметно это было только там,
  где есть ≥2 UI-узла: агентский `state` при этом молча отдавал аварийный
  минимум (без `entities`/`ui`), а прямой `$.agent.snapshot()` из JS — падал.
  Исправлено: набор полей распознаётся по типу (`want instanceof Set`), а UI-узлы
  получают поля явным замыканием. Проверка в
  `agent_entity_state_test.py` (снимок с тремя UI-узлами + «снимок настоящий, а
  не аварийный минимум»); на возвращённом дефекте падает 2 проверки из 22.
- **Тишина вместо ошибки убрана.** Когда провайдер снимка падал, команда `state`
  молча отдавала аварийный минимум — клиент видел правдоподобный неполный ответ.
  Теперь отказ слышен в трёх местах: в ответе `state.error = {code:
  "R2D_AGENT_SNAPSHOT_FAILED", message}`, в журнале (`R2D_ERROR`, было `R2D_WARN`)
  и в машинной диагностике `$.debug.errors()`. Тест ломает снимок намеренно и
  проверяет все три (всего в `agent_entity_state_test.py` 32 проверки). Заодно
  прочёсан весь класс «функция вторым аргументом получает индекс»: в моих файлах
  нашлось второе место (`$.agent.nodes` → `.map(nodeBrief)`) — закрыто явным
  замыканием; в `devtools.js` такие колбэки (`isNum`, `hitchRowText`, `physRowText`,
  `traceEntryText`) однопараметровые, индекс они игнорируют — безопасно.

Раздел H отчёта BASHNYA по агентскому режиму (H12): из трёх пунктов два
оказались «уже работает, но не закреплено», один — реальная дыра. Всё проверено
замером сырого протокола.

- **Корреляция протокола** (в отчёте: «нет корреляции») — работает и теперь
  закреплена: `id` повторяется и в успехе, и в **ошибке**
  (`{"ok":false,"id":7,"error":…}`), нежданные сообщения несут `event`
  (`{"event":"ready",…}`), строк протокола без `id`/`event` — **0** (кроме
  ответов на запросы без `id`, движок чужой `id` не выдумывает). Дефект был в
  клиенте игры. Гарантия: `tests/agent/agent_h12_observability_test.py`,
  правило — `docs/AGENT_API.md` §2 («сравнивайте `id`»).
- **Аудио** (в отчёте: «нет аудио») — инициализируется и наблюдаем даже с
  `SDL_AUDIODRIVER=dummy` (его подставляет агентский клиент): микшер 128
  каналов, `$.sound.busy()` `{active:0}` → `{active:1}` после
  `$.sound.play('assets/audio/sfx/pickup_01.ogg')`, захват микса в тишине
  `peak = 0`, сразу после звука `peak = 0.287`, `mean = 0.159`. Значит звук
  проверяем в CI без аудиоустройства; рецепт — `docs/AGENT_API.md` §7.1, тест —
  тот же файл.
- **Интроспекция API** (в отчёте: «нет интроспекции») — было верно, добавлено:
  `$.agent.has(path|paths)` и команда `has`
  (`{"cmd":"has","names":[…]}` → `{"ok":true,"has":{…}}`). Полного списка имён
  нет намеренно: 3000+ имён ≈ 60 КБ на ответ (урок A8: снимок раздувался до
  168 КБ). Ответ на одно имя — **43 байта**. Публичная поверхность: +1 имя в
  `api_freeze_baseline.txt` (3059 имён), документация — `docs/AGENT_API.md`
  §3 и §7.3.


### Не выпущено — разведка inspector-backend: три бага в звуке (task-57, 2026-10-16)

- **ЗАКРЫТО (приоритет 1): молчаливый отказ загрузки.** `$.sound.music('нет/такого.ogg')`
  возвращал объект, похожий на успех, музыка не играла, и в журнале была одна
  строка. Теперь — структурная ошибка `R2D_SOUND_LOAD_FAILED` в `$.debug.errors()`
  (`subsystem: 'sound'`, `recoverable: true`, путь в сообщении). Воспроизведение:
  в фикстуре `ui_contract` музыка идёт из `assets/audio/music/action.ogg`, а
  незагружаемый путь раньше не отличался от рабочего ничем, кроме строки лога.
- **Симметрия имён.** `$.audio.musicPlaying()` не существовало (было только
  `$.sound.musicPlaying`), `$.sound.musicStop()` тоже: остановить музыку можно было
  лишь `stopMusic`. Добавлены `$.sound.musicStop(ms)` (алиас `stopMusic`) и
  `$.audio.music/musicPlaying/musicStop` (делегаты в `$.sound`). Прежние имена
  сохранены.
- **Побочно найдено и исправлено (по провалу `highlevel_ui_contract_test`)**: мой
  же сброс звука при смене сцены (task-54) обнулял запись «какой трек просили»
  (`ctx.state_music`), из-за чего timeline восстанавливал музыку как «остановить».
  Теперь запись не стирается, а `$.sound.music()` принимает и саму запись
  `{ path, volume }` — timeline передаёт именно её (`timeline.js:800`), и раньше
  `load()` молча падал на объекте. Соседний тест снова зелёный.
- Замеры: `$.audio.music()` → `musicPlaying()` true через оба пространства имён;
  `musicStop(0)` и `$.audio.musicStop(0)` останавливают; на незагружаемом пути
  ровно одна запись `R2D_SOUND_LOAD_FAILED`.
- Заморозка API обновлена осознанно: `$.sound.musicStop`, `$.audio.music`,
  `$.audio.musicPlaying`, `$.audio.musicStop` (+ ранее в этой задаче `$.clip.*` и
  `$.sound.stemsState`).


### Не выпущено — BASHNYA H6/H8/H9/H10: единый тип коллекции, зона активации, подмножество пресета, размер узла (task-58, 2026-10-16)

Все четыре пункта раздела H закрыты: H6 и H10 — исправления (тест падает до
правки 10 проверок), H8 и H9 — согласованные расширения (5 проверок).

**H6 (несогласованность API) — исправлено.** `$.find(sel)` отдавал СЫРОЙ массив
узлов, а `$(sel)` — обёртку. У сырого узла `get` — геттер атрибутов, поэтому
`$.find('.x')[0].get(0)` читал атрибут «0» (`undefined`), тогда как
`$('.x').get(0)` отдавал узел; `.size` у сырого узла — ЧИСЛО (поле), а не метод.
Теперь тип один: `$.find(sel)` → обёртка, как `$()` (итерируемая — прежний обход
`for (const n of $.find('*'))` работает), сырой массив остался явным
`$.findNodes(sel)`. Замер: `$.find('.goblin')` → `Wrapper`, `.length 3`,
`.get(0).tag 'enemy'`, `$.find('#hero').size() = {w:28,h:40}`;
`$.findNodes('.goblin')` → `Array`. Новое имя — `$.findNodes` (заморозка
обновлена осознанно).

**H10 (дефект) — исправлено.** `Node.setSprite()` брал размер у спрайта по
эвристике `this.w === 32 || this.w === 0`, поэтому ЯВНЫЙ `.size(32, 32)` был
неотличим от «размер не задавали», и смена листа переписывала габариты узла
размером кадра: замер до — `.size(32,32)` + `.frames({cw:128,ch:32})` → **128×32**
(и через `.sprite({cols,rows,cw,ch})` тоже). Введён флаг `size_locked`, который
ставят все явные пути размера (`.size()`, поля `.w`/`.h`, атрибуты `{w,h}`);
авторазмер из спрайта сохранён для узлов без размера. Замер после:
`.size(32,32)` + `cw:128` → **32×32**, без `.size()` → 128×32 (совместимость).
Проверены регрессии `highlevel_tile_geometry`, `highlevel_tilemap`,
`highlevel_tilemap_ysort`, `tilemap_*`, `litsprites`, `highlevel_sprite`,
`highlevel_rotsprite`, `emissive_sprites`, `devtools_physics` — зелёные.

Числа: тест `tests/agent/api_find_frames_size_test.py` на старом коде —
**ПРОВАЛЕНО 10**, на новом — зелёный.

**H8 (расширение API) — сделано, 3 пункта.** (1) `region` в `auto()` — «зона
пробуждения» — уже работал, но об этом не было написано: замер (герой в
`(3000,300)`, камера в `(0,0)`) — `auto('#enemy')` даёт
`{update:false, fixed:false, timers:false, physics:false}`, а
`auto('#enemy', { region: {x:3000,y:300,w:4000,h:4000} })` — всё `true`;
добавлен раздел в `triggers.md` с этими числами. (2) `isOnScreen(what, opts)`
принимает ПРЯМОУГОЛЬНИК зоны `{w,h,dx,dy}` (или `{x,y,w,h}` — абсолютный центр),
число осталось запасом в пикселях: до правки объект **молча игнорировался**
(`isOnScreen(node, {w:8000,h:8000})` отвечал как без него), теперь `true` для
большой зоны, `false` для малой и учитывается `dx`. (3) `wakeForever: true` у
`watch`/`auto` — после первого входа выход игнорируется (узел не глохнет на
полпути); по умолчанию поведение прежнее (контроль в тесте: без флага узел
усыпляется при выходе из зоны).

**H9 (расширение API) — сделано.** `only: ['particles','flash']` в `$.hits.play`
раньше принимался и МОЛЧА игнорировался (пресет применялся целиком). Теперь это
белый список: поля вне списка нейтральны (`particles`/`flash`/`screen` → `null`,
`shake`/`hitStop`/`slow`/`knockback`/`squash` → `0`, `sound` → `''`), явные поля
`opts` главнее. Замер: пресет `crit` целиком — `particles, flash, screen, shake 7,
hitStop 110, squash 0.35`; он же с `only: ['particles','flash']` — частицы и
вспышка на месте, `shake 0, hitStop 0, squash 0, knockback 0, screen null,
sound ''`. Про «лимит эмиттеров выше 8»: он уже есть — `$.hits.pool(n)`,
по умолчанию 8, потолок 64 (почему — дописано в `hits.md`).

Числа: тест `tests/agent/activation_wake_hits_only_test.py` на старом коде —
**ПРОВАЛЕНО 5**, на новом — зелёный.


### Не выпущено — BASHNYA H1: `doc.hide(id)` скрывал весь документ, `rect()` врал про скрытое (task-56, 2026-10-16)

- `src/highlevel/ui.js`: `doc.hide()/show()` без аргумента работают с документом,
  с аргументом — с **элементом** (раньше аргумент игнорировался, и `hide('petals')`
  скрывал всё; это и был костыль H1). Скрытие — инлайн-стиль `display:none`,
  показ — снятие свойства.
- `src/gui.cpp`: `r2d_gui_get_rect()` возвращает «невидим» (в JS — `null`), если
  элемент скрыт сам **или его предок** (обход до корня). Раньше отдавались
  прежние размеры, из-за чего автопроверка «элемент есть и у него есть размер»
  оставалась зелёной. Плюс `set_property` с пустым значением теперь **снимает**
  свойство (иначе `show(element)` не возвращал элемент).
- Числа: `rect(элемента)` до/после скрытия — бокс → **null**; `rect(ребёнка)` при
  скрытом родителе — бокс → **null**; после показа — бокс снова. Проверка:
  `tests/agent/ui_hide_test.py` (все проверки пройдены), `windowed`-непричастно.
- Документация: `docs/highlevel/ui.md` — раздел «Скрытие элементов и что умеет
  RmlUi в поставке»: H3 (`background-image` — не свойство RmlUi, градиенты через
  `decorator:`, пример ещё не подтверждён живым прогоном), H4 (шейдеров на
  элементах нет — обход узлом под документом), H2 (анимации в вендоре собраны,
  причина «движения нет» выясняется).


### Не выпущено — BASHNYA H5 + H11: разброс высоты банка и ресурс «клип» (task-57, 2026-10-16)

**H5, разброс высоты.** Причина: в `bankPitch()` генератор по умолчанию был
константой `() => 0`, поэтому диапазон всегда давал нижнюю границу (замер: 12
вызовов `playBank` → одна и та же высота), а `opts.pitch` со диапазоном молча
превращался в `NaN` (это множитель).

- **ИЗМЕНЕНИЕ ПОВЕДЕНИЯ**: генератор банка по умолчанию — движковый
  (`ctx.random`, сид из `--seed`). Игры, которые уже объявили `pitch: [lo, hi]`
  и получали ровно нижнюю границу, теперь слышат разброс. Это исправление
  заявленного поведения, `{ rng }` продолжает перебивать генератор.
- `playBank(name, { pitchRange })` — разброс поверх множителя `pitch`: `0.05` =
  ±5 %, `[0.9, 1.1]` = диапазон. `pitch` остаётся множителем (совместимость).
- `$.sound.stemsState()` — публичная обёртка над `engine.audio.stemsState()`
  (поля сверяются в тесте один в один).
- Числа: банк с `pitch: [0.96, 1.04]` → **12 разных высот из 12** в диапазоне
  0.967–1.032; `pitch: 1.25` → 1.208–1.285 (множитель сохранён).

**H11, клипы.** Новое пространство имён `$.clip` — ресурс с жизненным циклом:
`$.clip.define/get/list/remove`. Кадры клипа — спрайты или регионы
`{src,x,y,w,h}`, в том числе **с разных листов**; `.animate({clip:'walk'})` и
`.animate('walk')` берут `fps`, `loop` и `pivot`. `pivot` двигает только точку
вращения — **размер узла клип не меняет** (граница с H10, `fit` не делаем).
Числа: клип из двух листов (`frames: 2`, `skipped: 0`) играет, `fps: 8`/`loop:
false`/`pivot: [0.5, 1]` соблюдаются, размер узла остаётся 32×48.
`.animate({from,to,speed,loop})` без `clip` — как раньше.
Заморозка API обновлена осознанно: `$.clip.define`, `$.clip.get`, `$.clip.list`,
`$.clip.remove`, `$.sound.stemsState`.


### Не выпущено — BASHNYA G1: смена сцены глушит звук уходящей сцены (task-54, 2026-10-16)

Дока `sound.md` обещала «музыка — часть сцены», а код владел звуком только по
области §5 и комнате: музыка меню играла поверх следующей сцены (живой замер
BASHNYA: через 2 с в новой сцене `musicPlaying()` → true).

- **Сделано**: `$.scene.load()` снимает всё, что запустила уходящая сцена —
  музыку, `play`, `playAt` — с затуханием **250 мс** (`{ audio_fade }` меняет,
  `0` — мгновенно). Владелец по сцене; `{ keep: true }` / `scope.keep(channel)`
  переход переживают. Снятие идёт ДО `exit()` уходящей сцены: звук из `exit()`
  принадлежит новой сцене.
- **Числа** (`tests/agent/scene_audio_ownership_test.py`): `musicPlaying()` до
  смены — true, после — **false** без единой строки кода игры; по захвату микса
  RMS падает **0.0419 → 0.0006** (0–50 мс → 250–350 мс), то есть затухание, а не
  обрыв; `{ keep: true }` музыку и звук сохраняет; быстрый повторный переход
  (меню → вступление → уровень) хвостов не оставляет; со входом в комнату
  поведение то же.
- Тест падает на старом коде (проверено откатом `sound.js`/`scene.js` до HEAD).
- Доки: `sound.md` (формулировка приведена к факту), `scene.md` (новый раздел
  «Что происходит со звуком при смене сцены»).


### Не выпущено — таймлайн: слот без арта больше не белый прямоугольник (task-52, F4)

Пункт F4 отчёта BASHNYA (PHASE 2).

- **Воспроизведено числами**: `cast: { hero: { name: 'Героиня' } }` (без
  `poses`) поверх кадра вступления давал **белый прямоугольник 368×657 px —
  241 776 белых пикселей** (узел `#__tl_hero_hero` с `sprite: -1`). Поза
  объявлена, а файла нет — то же самое (112 542 белых пикселя в замере).
- **Исправлено**: узел слота без арта не создаётся (существующий убирается), в
  журнал уходит одна строка на имя —
  `cast: у персонажа "hero" нет poses/арта — слот не рисуется (нужен только
  говорящий — задайте speaker у бита say)`; для незагрузившейся позы —
  `cast: у персонажа "hero" поза не загрузилась (нет файла?) — слот не
  рисуется`. Без арта персонаж остаётся в `cast`: имя говорящего и `who`
  работают как раньше.
- **После правки**: 0 белых пикселей в обоих случаях; с `poses` слот рисуется
  как раньше (129 234 зелёных пикселя в замере, `sprite >= 0`).
  `tests/agent/highlevel_timeline_test.py`: 39 ok / 0 fail (до правки 35 ok /
  **4 fail**). Правило записано в `docs/highlevel/timeline.md` §3.2.


### Не выпущено — сценки: кадр и затемнение стали экранным оверлеем (task-52, 2026-10-16)

Пункт F2 отчёта BASHNYA (PHASE 2). Кадр `$.story image` был **мир-спрайтом** в
мировых координатах, а затемнение сценки создавалось **непрозрачным** и
рисовалось поверх кадра.

- **Воспроизведено числами** (белый кадр во весь экран, яркость центра):
  запуск сценки из `enter()` сцены — **0.0** (кадр не виден), камера уехала —
  **0.0**, мир-узел `#menu_bg` с `depth: 10` — **0.0**. Механизм: затемнение
  `__story_fade` стартовало с `alpha 1` и рисовалось поверх кадра (замер:
  скрыть затемнение — 240.0), а сам кадр жил в мире и проигрывал по глубине.
- **Исправлено**: весь оверлей сценки переведён на экранные узлы —
  `<ui.image>` для кадра, `<ui.panel>` для полос, окна реплики и затемнения,
  `<ui.label>` для имени и реплики. Камера и `depth` мир-узлов на них не влияют,
  затемнение стартует прозрачным и создаётся последним (порядок отрисовки
  фиксирован), поэтому `fade out`/`fade in` продолжают работать.
- **После правки**: яркость центра **255.0** во всех трёх случаях выше,
  `fade out` → **0.0**, `fade in` → **255.0**. Тест
  `tests/agent/highlevel_story_test.py`: 28 ok / 0 fail (до правки 25 ok /
  **3 fail** — те самые три проверки F2).
- Тест ждёт конца перехода сцены перед замером (`$.scene.busy()` + предел с
  диагностикой): у `$.scene.load` своё затемнение ~300 мс, и без ожидания замер
  ловит переход, а не оверлей (замер: `transitionAlpha 0.11` при яркости 227).
## Не выпущено — BASHNYA E10 + F3: снятие шейдера и счётчики текстур (task-51, 2026-10-16)

- **E10, починено**: `shader(null)`/`shader(false)` (а также `0`, `''`, `'none'`)
  возвращают узел к обычной отрисовке. Раньше `false` уходил в ветку «неизвестный
  эффект»: строка в журнал — и **шейдер оставался на узле**, то есть выключить
  искажение из игры было нельзя, только пересоздать узел. Обратная сторона
  проверена: `shader('имя')` после сброса снова включает. Вызов на пустой выборке
  больше не молчит — пишет, что узел не найден.
- **F3, счётчики**: `$.gfx.stats()` теперь отдаёт `textures`, `textures_max`,
  `texture_bytes`, `texture_mb` — по реестру текстур, то есть включая загруженные
  **спрайтами по пути**. Раньше этих полей не было вовсе, и игру нельзя было
  продiagnostировать по памяти, кроме строк журнала.
- **F3, поток кадров (числа)**: 17 кадров 1920×1080 — это **134.5 МБ**, если
  держать все; окно «текущий + следующий» даёт **16.08 МБ**, выгрузка 15 кадров
  возвращает **118.7 МБ**. Рецепт и таблица — в `docs/highlevel/resource.md`.
- Тест `tests/agent/shader_stats_stream_test.py` (E10 + F3 + поток) падает на
  старом коде (проверено откатом `api.js`/`render.js` до HEAD) и проходит после.

## 1.2.1 — 2026-10-16

<!-- release-notes:begin — генерируется tools/release_notes.py, правьте текст вне маркеров -->

10 коммитов в релизе.

### Исправления

- smaa_test: дефлак под нагрузкой (task-50, промежуточное состояние) (`22ecedcca`)
  Полный прогон ветки 1.2.1 дал 223 ok / 2 fail: net_delay_test и smaa_test. По
  отдельности net_delay_test стабилен (3/3), а smaa_test флакует: 1 провал из 3 при
  load average 4.79/5.05/4.62 — то есть эталонный замер SMAA зависит от того, успел ли
  полноэкранный пост-проход при конкуренции за GPU/CPU.
  Правка profiler-core (58 добавлено, 7 удалено): проверка 3/3 зелёная под текущей
  нагрузкой. Оформлено отдельной задачей task-50 с требованием доказать, что проверка
  по-прежнему ловит регресс SMAA (намеренно выключенное сглаживание → красный) и N
  прогонов под искусственной нагрузкой → зелёные. Коммичу сейчас, потому что выпуск
  1.2.1 не должен тащить полуправку в релизный коммит.
- Правило промаха цели доведено до $.sound, $.ui и $.tilemap (30 мест из аудита) (`532a7733e`)
  Закрытие task-49: последние подсистемы с ТИХИМ промахом цели. Тест падает до правки
  24 проверки. Ключ дедупликации — СЫРАЯ цель, сброс после успешного разрешения.
  - $.sound (1 место): playAt → toPoint на промах отдавал (0,0) молча, в журнале было
  только «не удалось загрузить звук». Теперь «селектор #… ни к чему не подошёл —
  беру точку (0,0)» один раз; возвраты -1/расстояние прежние.
  - $.ui (8 методов: show/hide/bar/label/aria/ariaOf/persist/transient): были тихие
  no-op — query(sel).forEach(...) без проверки результата. Теперь сообщение один раз;
  возвраты ($.ui для цепочки, null у ariaOf) сохранены как документированные.
  - $.tilemap (19 методов через resolveTm, включая visualOf/visualTable/debug):
  умолчания возвращались молча. Теперь «карта #… не найдена — возвращаю умолчание
  (false/0/null)», плюс отдельное различение «узел #hero — не карта (<player>),
  данных нет».
  …
- Правило промаха цели в combat/net/prefab + дедупликация; аудит sound/ui/tilemap (`4641efc8c`)
  Продолжение единого правила (после task-46/47): $.combat, $.net, $.prefab писали
  громко, но БЕЗ дедупликации — вызов в кадре заливал журнал; часть мест молчала вовсе.
  Тест падает до правки 14 проверок.
  БЫЛО/СТАЛО (ключ дедупликации — СЫРАЯ цель, сброс после успешного разрешения):
  - $.combat.attach: сообщение на КАЖДЫЙ вызов → один раз на пару «место+цель»;
  - $.combat.health/detach/hit: молчание → сообщение один раз (null/false сохранены;
  «узел найден, но без модели здоровья» по-прежнему молчит — это законный ответ, а
  не промах);
  - $.net.replicate/unreplicate/ownerOf/idOf/owns/rewind: часть молчала, часть писала на
  каждый вызов → один раз; возвраты 0/false/null сохранены;
  - $.net: селекторы теперь не только #id (byId первым, query вторым);
  - $.prefab.resolveParent (load/instantiate): промах селектора молча давал null, и
  …
- Единое правило промаха цели: alive/bsp/camera + дедупликация сообщений (`7664157ea`)
  Продолжение задачи про селекторы-цели (после appendTo и класса): то же правило
  доведено до $.alive, $.world.bsp и $.camera. Тест падает до правки 14 проверок.
  ЧТО СТАЛО (все возвраты сохранены — иначе сломали бы чужой код, обоснование по
  каждому месту в CHANGELOG):
  - $.alive.of/attach('#…'): промах → null молча → «узел #… не найден — верну null»
  (null — законный ответ «психики нет», код проверяет if (!mind)); плюс селектор
  теперь принимает не только #id: byId первым шагом, query() вторым (прежнее
  поведение id сохранено);
  - $.world.bsp.order/indices('#…'): промах → точка (0,0) молча → сообщение; возврат
  оставлен, потому что методы документированы как «возвращают массив»;
  - $.world.bsp.segment(index): индекс вне диапазона → null молча → «индекс 99999 вне
  0..3 — верну null»;
  …
- Селектор как цель работает; промах слышен вместо тишины (appendTo и весь класс) (`b1c4c1ed5`)
  Наша дока (HIGH_LEVEL_API.md:656) показывала `$('<sprite>').appendTo('#hero')`, а
  строковая форма МОЛЧА ничего не делала: resolveContainer принимал только узел/обёртку
  и для строки возвращал null. Числа: детей у #hero 0, parent().nodes.length 0; с
  обёрткой — 1. Худший класс дефекта: не ошибка, а тишина.
  ЧТО СТАЛО (src/highlevel/api.js, {parent} — core.js):
  - appendTo/prependTo: селектор разрешается как $(sel); промах сообщает
  «$.appendTo: селектор #… ни к чему не подошёл — узел не прикреплён», узел
  остаётся у мира (не «уезжает в мир» — иначе промах выглядел бы успехом); пустая
  обёртка — тоже сообщение; неоднозначный селектор (.goblin → 3 узла) берёт первый
  и говорит об этом;
  - append/prepend: принимают узел/обёртку/селектор; не-цель (append(42)) сообщает,
  что получено (раньше молча игнорировалось);
  …
- BASHNYA E1/E2/E3: автоцвет эмиттера (use-after-free + alpha) и lightMask (`d50f4886c`)
  Пункты E1, E2, E3 отчёта BASHNYA на 1.2.0. E9 НЕ воспроизвелся (см. ниже).
  E1 — автоцвет `color:'auto'` не работал, свет всегда белый [255,255,255,255],
  auto_color_known:false. Причина оказалась ДВОЙНОЙ:
  1. ЧТЕНИЕ ОСВОБОЖДЁННОЙ ПАМЯТИ: средний цвет текстуры считался в render.c ПОСЛЕ
  SDL_DestroySurface(rgba) — has_avg оставался false, engine.textureAverageColor()
  возвращал null (замер на бинарнике до правки). Исправлено: цвет и миниатюра
  снимаются ДО освобождения поверхности.
  2. ALPHA автоцвета: packColor([r,g,b,255], 1) — массив ожидает alpha 0..1, поэтому
  Math.round(255*255) & 0xff = 1, и в записи эмиттера было [52,46,34,1] вместо
  [52,46,34,255].
  После: независимый подсчёт пикселей PNG [52.00, 46.00, 34.00] против движка
  [52.00, 46.00, 34.00] — замер из доки воспроизводится; запись эмиттера
  …

### Добавлено

- Автоцвет кадра листа: точный ленивый расчёт по региону + E9 в реестре решений (`7d8fee85b`)
  Добито по решению лида после E1: средний цвет кадра листа считался по миниатюре
  блоков и не совпадал с подсчётом пикселей кадра (процедурный лист [230,200,60] против
  [52,46,34]).
  Теперь считается по ТОЧНОМУ пиксельному прямоугольнику спрайта (px,py,pw,ph пишутся
  при создании спрайта, а не восстанавливаются из UV — из UV выходила полупиксельная
  погрешность), ЛЕНИВО, с кешем на кадр:
  - регион 20,4,16,12 атласа 80x20: Python [37.5, 84.38, 206.25] = движок [37.5, 84.38,
  206.25]; регионы 0,0,20,20 и 60,0,20,20 — тоже точное совпадение;
  - первое обращение к типовому атласу 0-1 мс, повторное 0 мс;
  - лист 6144x3073 (19 Мп) НЕ декодируется вовсе: потолок 16 МБ на текстуру, ответ
  0 мс приближением по миниатюре (иначе копия 75 МБ и ~143 мс — один раз на
  текстуру, но всё равно не платим);
  …
- BASHNYA E4/E5/E7/E8: fit/scale у visual, solidAt без слоя, порядок декора, видимость слоёв (`d5ecfca6d`)
  Пункты E4, E5, E7, E8 отчёта BASHNYA на 1.2.0. Каждый воспроизведён своим прогоном;
  E5 и E8 починены, E4 добавлен, E7 закрыт документацией с проверенным рецептом.
  E8 (настоящий баг) — два смысла видимости слоя: $.layers.hide('bg') (глубокий) гасил
  слой с потомками, а $.layers.get('bg').show() (обёртка) ставил visible только узлу
  слоя. Числа: флаг слоя true, но $('#star0').visible = false и пиксель звезды — фон
  (16, 24, 32); после правки (43, 74, 122). Решение: одна точка applyLayerVisibility +
  аксессор visible на самом узле-слое, поэтому .hide()/.show()/.visible(flag) и
  $.layers.hide/show(name) идут одним путём; смесь безопасна В ОБЕ стороны, дети,
  добавленные после hide(), при show() видны, isVisible() согласован, у ОБЫЧНОГО узла
  .hide() по-прежнему не трогает детей. Тест падает на старом коде 8 проверок.
  Отброшен вариант с патчем Wrapper.prototype.visible: подсистемы ставятся раньше, чем
  ядро объявляет метод, и заморозка поймала подмену ($.fn.visible «пропал»).
  …
- BASHNYA E6: освобождение текстур, загруженных спрайтами ПО ПУТИ (16 МБ возвращаются) (`e75600721`)
  Пункт E6 из отчёта BASHNYA на 1.2.0: $.resource.free(path) не освобождал текстуру,
  загруженную спрайтом по пути — у них анимация меню из 64 полноэкранных оверлеев
  копилa 402 МБ в GPU (32 кадра за 12 с = 32 живые текстуры).
  КОРЕНЬ (найден бисекцией пробы, как и подсказал лид): engine.textureSprites не был
  зарегистрирован — строка r2d__set_fn не легла в script.c (та же болезнь была с
  textureList), поэтому freeTextureByPath уходил в ветку «движок не даёт список» и
  всегда отвечал busy:true. Вторая причина — держателей считали по слотам спрайтов,
  а не по живым узлам: спрайты из JS-кэша (sprite_cache) держали текстуру вечно.
  СДЕЛАНО:
  - r2d_texture_users()/liveSprites() считают держателей по ФАКТУ обходом реестра
  узлов (и кадров атласа) — кэш JS больше не мешает выгрузке;
  - $.resource.textures() → [{id, path, w, h, users, mb}]; $.resource.freeTexture(path)
  …

### Документация

- R2D_TEST_FREE_POISON: UB «освободил и прочитал» теперь ловится тестом + доковый долг по тестам (`c16ef7d23`)

<!-- release-notes:end -->

### Подробности (написано вручную)

Текст ниже перенесён генератором из разделов «Не выпущено» без изменений (опущен только уровень заголовков).

### Не выпущено — промахи цели в sound/ui/tilemap: 30 мест стали слышны (task-49, 2026-10-16)

Завершение правила task-46 → 47 → 48: закрыты три подсистемы, где промах
цели-селектора был ТИХИМ (аудит с живыми замерами — в task-48). Ключ
дедупликации — СЫРАЯ цель, сброс после успешного разрешения.

**`$.sound` (1 место).** `toPoint()` в `playAt(what, where)` на промах отдавал
`(0, 0)` без слова. Теперь: `$.sound.playAt: селектор "#…" ни к чему не подошёл —
беру точку (0, 0)`, один раз. **Возврат сохранён** (`-1` при отсутствии файла и
дальнейшая логика расстояния) — «это ответ, а не ошибка вызова».

**`$.ui` (8 методов: `show`, `hide`, `bar`, `label`, `aria`, `ariaOf`,
`persist`, `transient`).** Были тихие no-op: `query(sel).forEach(...)` без
проверки результата. Теперь промах слышен ровно один раз — это критично, методы
зовутся в UI-цикле. **Возвраты сохранены** (`$.ui` для цепочки, `null` у
`ariaOf`) — «цепочка и null — документированный контракт».
Решение по множественным совпадениям (требование задачи):
* ОДИНОЧНЫЙ селектор, подошедший к нескольким узлам, назван вслух —
  `подошёл к 3 узлам — применяю ко всем` (применение ко всем сохранено, это
  прежнее поведение);
* геттеры `aria(sel)` без `props` и `ariaOf(sel)` вернуть могут одно значение —
  `беру первый`, и об этом сказано;
* селектор-**список** (`'#hud, #hud_hp, #hud_bar'` — форма из `ui.md:120`)
  множественность заявляет сам, поэтому сообщения нет: иначе штатный пример из
  доки шумел бы в журнале.

**`$.tilemap` (19 методов через `resolveTm`).** Промах по карте молча давал
умолчания. Теперь `$.tilemap.<метод>: карта "#…" не найдена — возвращаю умолчание
(false/0/null)`, один раз на пару «место + цель» — `solidAt`/`layer`/
`visibleTiles` зовутся в игровом цикле, поэтому дедупликация обязательна.
Отдельно назван случай «узел найден, но это не карта»:
`узел "#hero" — не карта (<player>), данных нет` (раньше выглядело как «пустая
карта»). **Возвраты сохранены** — `false`/`0`/`null`/пустой массив по контракту
`solidAt` (§10 tilemap.md).

Числа: тест `tests/agent/target_miss_ui_sound_tilemap_test.py` — на старом коде
**ПРОВАЛЕНО 24**, на новом зелёный. Дедупликация в кадрах: 5 кадров × `$.ui.hide`
+ `$.ui.label` → **2 сообщения** (по одному на метод, а не 10); 5 кадров ×
`$.tilemap.solidAt` → **1 сообщение**. Примеры доков прогнаны кодом:
`sound.md` (10, 24), `ui.md` (72–74, 120–121), `tilemap.md` (199, 310, 858) —
все выполняются, расхождений «дока vs код» не нашлось.

Файлы: `src/highlevel/{sound,ui,tilemap}.js`, `docs/highlevel/{sound,ui,tilemap}.md`,
`tests/agent/target_miss_ui_sound_tilemap_test.py`. Заморозка API не менялась.


### Не выпущено — промахи цели в combat/net/prefab: слышно и без заливки журнала (task-48, 2026-10-16)

Завершение правила task-46/47. Здесь промах уже был ГРОМКИМ, но писался на
КАЖДЫЙ вызов: `$.combat.attach` в кадре или `$.net.replicate` в тике заливали
журнал (та же болезнь, что была у `$.task`). Теперь ключ дедупликации — СЫРАЯ
цель, после успешного разрешения серия начинается заново.

**combat.** `attach` писал на каждый вызов; `health`/`detach`/`hit` молчали
вовсе. Все четыре пишут один раз на пару «место + цель»; возвраты сохранены
(обоснование — «это ответ, а не ошибка вызова»): `attach` → `null`,
`health` → `null` (узел найден, модели нет — по-прежнему молча: это законный
ответ), `detach` → `false`, `hit` → `null`.

**net.** `replicate` писал на каждый вызов; `unreplicate`, `ownerOf`, `idOf`,
`owns`, `rewind` молчали. Селектор теперь полный (`'.goblin'` тоже, раньше
только `#id`); возвраты сохранены: `replicate`/`unreplicate`/`ownerOf`/`idOf`
→ `0`, `owns` → `false`, `rewind` → `null`.

**prefab.** `resolveParent` для промаха селектора молча возвращал `null`, то
есть узел тихо уезжал В МИР — теперь это сказано:
`$.prefab: instantiate: селектор "#…" ни к чему не подошёл — беру мир`.
`save`/`savePrefab` писали на каждый вызов — пишут один раз; возвраты прежние
(`save` → `null`, `savePrefab` → сама обёртка).

Числа: тест `tests/agent/target_miss_combat_net_prefab_test.py` — на старом коде
**ПРОВАЛЕНО 14**, на новом зелёный. Дедупликация проверена кадрами: 5 вызовов
`$.combat.health('#нет-в-кадре')` в разных кадрах → **1 сообщение** (было 0 —
молчание; а `attach`/`replicate`/`save` давали по сообщению на вызов). Примеры
доков прогнаны кодом: `combat.md` (21, 22, 25, 53, 76, 111), `net.md` (15,
через настоящий `$.net.host` → `replicate('#hero', …) = 1`), `prefab.md`
(65, 66, 139) — все выполняются.

Файлы: `src/highlevel/{combat,net,prefab}.js`, `docs/highlevel/{combat,net,prefab}.md`,
`tests/agent/target_miss_combat_net_prefab_test.py`. Заморозка API не менялась.


### Не выпущено — единое правило промаха селектора: alive/bsp/camera (task-47, 2026-10-16)

Продолжение task-46: правило «цель-селектор либо разрешается, либо промах
СЛЫШЕН» доведено до трёх подсистем, которые селектор принимали, а промах
глушили. Возвраты сохранены — совместимость важнее единообразия ради:

* `$.alive.of(...)` / `$.alive.attach(...)` — селектор теперь полный
  (`'.goblin'`, `'player'`), а не только `#id`; промах пишет
  `$.alive.of: узел "#…" не найден — верну null`. **Возврат `null` оставлен
  осознанно**: пустой результат — законный ответ на вопрос «есть ли психика у
  узла», и чужой код проверяет `if (!mind)`.
* `$.world.bsp.order(...)` / `indices(...)` — промах пишет
  `… селектор "#…" ни к чему не подошёл — беру точку (0, 0)`; **запасная точка
  `(0, 0)` оставлена**: методы документированы как «возвращают массив», и
  менять их результат на `null` значило бы ломать обход без причины.
* `$.world.bsp.segment(index)` — индекс вне `0..count()-1` пишет
  `индекс 5 вне 0..3 — верну null`; **`null` оставлен** (это документированный
  ответ «отрезка нет»), но раньше про опечатку в индексе не было слышно вовсе.
* `$.camera.worldToScreen` / `screenToWorld` / `isOnScreen` — промах пишет
  `… ни к чему не подошёл — беру (0, 0)`; **точка `(0, 0)` оставлена** по той же
  причине: методы возвращают координаты, а не «есть/нет».
* `$.camera.follow('#…')` — цель резолвится КАЖДЫЙ кадр и может появиться
  позже (осознанная ленивость), поэтому формулировка мягче:
  `$.camera.follow: цель "#…" пока не найдена — жду появления узла`.
  **Поведение не изменилось** — камера по-прежнему ждёт узел и не телепортится.

**Журнал не заливается**: сообщение пишется один раз на пару «место + цель», а
после успешного разрешения селектора серия начинается заново (ключ — сырая цель,
не текст сообщения). Проверено кадрами: `follow('#нет-такого')` за 6 кадров —
**1 сообщение** (без дедупликации их было бы 6+).

Тем же правилом закрыты ещё два «тихих» промаха в этих файлах:

* `$.alive.typeBias(id)` — неизвестный психотип пишет
  `тип "…" неизвестен — верну null`; **возврат `null` оставлен** — это ответ
  «такого типа нет», а не ошибка вызова;
* `$.camera.zone(name)` — неизвестное имя зоны пишет
  `зона "…" не найдена — верну null`; **`null` оставлен** по той же причине.

Попутно исправлена дока: `docs/highlevel/bsp.md` показывала
`$.world.bsp.build($.world.bsp.fromLines(walls))`, а `fromLines` в API нет —
пример заменён на `build(walls)` (та же ошибка была в комментарии `bsp.js`).

Числа: тест `tests/agent/selector_miss_uniform_test.py` на старом коде падает
**14 проверок**, на новом — зелёный (проверяются все пять мест, дедупликация и
возвраты). Файлы: `src/highlevel/alive.js`, `src/highlevel/bsp.js`,
`src/highlevel/camera.js`, `docs/highlevel/alive.md`, `bsp.md`, `camera.md`.
Заморозка API не менялась — новых публичных имён нет.


### Не выпущено — цель-селектор работает, промах слышен (task-46, 2026-10-16)

Найдено при `task-44`: `$('<sprite>').appendTo('#hero')` — ровно эта форма стоит
в `docs/HIGH_LEVEL_API.md:656` — **молча** ни к чему не прикреплял узел:
`resolveContainer()` принимал только узел/обёртку, строку превращал в `null`,
ошибки не было, узел оставался без родителя (`$('#hero').children().length` — 0).

**Исправлено.** Строка-селектор у целей разрешается тем же путём, что
`$(selector)`; промах — сообщение в журнал, а не тишина:

* `appendTo`/`prependTo` — селектор или обёртка; промах:
  `$.appendTo: селектор "#…" ни к чему не подошёл — узел не прикреплён`
  (важно: узел НЕ уезжает «в мир», иначе промах выглядел бы как успех);
* `append`/`prepend` — узел, обёртка или селектор; не-цель (`append(42)`) тоже
  сообщает, что именно получено;
* `lookAt`, `moveTo`/`moveTowards`, `distanceTo`, `directionTo`, `angleTo`,
  `rayTo`, `sweepTo`, `$.pick`, `$.pickAll` — промах селектора виден в журнале
  (запасная точка `(0, 0)` сохранена ради совместимости);
* `collidesWith`, `mask`, `layerBits` — промах НЕ обнуляет маску: было
  `mask('#нет-такого')` → `0` бит (узел молча переставал сталкиваться со всем),
  стало — маска не меняется плюс сообщение;
* атрибут `{ parent: '#hero' }` шёл через `this.appendTo(...)` на узле, у
  которого нет обёртки, и падал с `TypeError: not a function` — теперь привязка
  идёт общей дорогой сразу после применения остальных атрибутов.

Числа (тест `tests/agent/api_selector_targets_test.py`, фикстура `hello`):
`appendTo('#hero')` — детей `0 → 1`, `parent()` `0 → 1`; `appendTo('.goblin')` —
3 совпадения, берётся первое + сообщение; `mask('#нет-такого')` — маска
`4294967295 → 4294967295` (было `→ 0`); `appendTo('#нет-такого')` — узел остаётся
у мира, в журнале одна строка. Штатные формы (`appendTo($('#hero'))`,
`appendTo($.ui)`, `appendTo($.world)`) отвечают как раньше. Всего на старом коде
тест падает **17 проверок**, на новом — зелёный; примеры
`docs/HIGH_LEVEL_API.md` с селекторами (строки 21, 246–263, 417–438, 656, 1456)
прогнаны кодом в том же тесте — находят узел и возвращают обещанное.

Файлы: `src/highlevel/api.js`, `src/highlevel/core.js`,
`docs/HIGH_LEVEL_API.md` (§13, «Цель — узел, обёртка или селектор»),
`tests/agent/api_selector_targets_test.py`. Заморозка API не менялась — новых
публичных имён нет.


### Не выпущено — тайлмап и слои: E4/E5/E7/E8 отчёта BASHNYA (task-44, 2026-10-16)

Четыре пункта раздела E (проверка 1.2.0) — тайлмап и видимость слоёв. Публичная
поверхность имён не расширялась: `fit`/`scale` — поля описания `visual`, поэтому
заморозка API держится без `--write`.

**Исправлено: `layer.show()` не возвращал детей после `hide()` (E8).**
Было два разных смысла видимости: `$.layers.hide/show(name)` гасили и
показывали слой вместе с потомками, а `.hide()/.show()/.visible()` у узла-слоя
трогали только сам узел. Смесь «глубоко спрятали — поверхностно показали»
оставляла слой нарисованным ПУСТЫМ. Замер (фикстура `layers`): после
`$.layers.hide('bg')` → `$.layers.get('bg').show()` флаг слоя `true`,
`$('#star0').visible = false`, пиксель звезды — фон `(16, 24, 32)`; после правки
— `(43, 74, 122)`. Теперь видимость узла-слоя идёт тем же путём
(`applyLayerVisibility`): смешанные вызовы безопасны в обе стороны, дети,
добавленные после `hide()`, при `show()` видны, вложенные узлы и `isVisible()`
согласованы; у обычного (не слоя) узла `.hide()` по-прежнему не трогает детей.
Файлы: `src/highlevel/layers.js`, `docs/highlevel/layers.md`,
`tests/agent/layers_visibility_test.py` — на старом коде падает 8 проверок.

**Добавлено: масштаб `visual` (E4 = их A9).** `visual.fit: 'cell'` растягивает
регион в клетку (`tile × tile`), `visual.scale: k` — множитель размера региона;
умолчание прежнее (регион 1:1 в мировых пикселях), при обоих полях главнее
`fit`. Замер на живом движке (регион 16×16, клетка 64, ширина пятна в кадре):
умолчание `16 px`, `fit:'cell'` `64 px`, `scale: 2` `32 px`; `visibleTiles()`
отдаёт те же `16`/`64`. HD-лист 256×256 на клетке 64 теперь ложится без
уменьшения арта. Пропорции: `fit` тянет регион в квадрат клетки; фильтр общий
для текстур (`$.gfx.filter`), per-visual фильтра нет — при сжатии 256 → 64
линейный даёт мягкую кромку, nearest — ступеньки. Файлы:
`src/highlevel/tilemap.js` (`normalizeVisual`, `visualDrawSize`, отрисовка,
`collectVisibleTiles`, `visualOf`/`visualTable`), `docs/highlevel/tilemap.md`
§13; `tests/agent/tilemap_visual_fit_test.py` — на старом коде падает 6 проверок.

**Изменено: `solidAt` без слоя = «занято любым слоем коллизий» (E5).** Раньше
без номера слоя он отвечал только за АКТИВНЫЙ слой, а активным мог оказаться фон
(`solid: false`) — «просто `solidAt`» давал карту, где свободно ВСЁ, что хуже
чтения одного слоя. Тот же контракт уже был у `fitsAt()`. Изменены
`$.tilemap.solidAt`, метод узла `.solidAt()` и `$.tilemap.cellQuery` без слоя;
явный слой и однослойные карты отвечают как раньше. Замер: карта «фон +
коллизии», активен фон — было `solidAt(tx, ty) = false`, стало `true` (при
`solidAt(tx, ty, 1) = true`). Файлы: `src/highlevel/tilemap.js`,
`docs/highlevel/tilemap.md` (§10, контракт `solidAt`);
`tests/agent/tilemap_layers_test.py` — на старом коде падает 3 проверки.

**Задокументировано: порядок декора и слоёв карты (E7).** Карта — ОДИН узел
мира, её слои сортируются внутри узла, поэтому узел с отрицательным `depth`
уходит за ВСЮ карту. Замер: декор `depth: -5` под картой со слоями `-10`/`+10`
не виден (пиксель `(86, 196, 110)` — тайл карты). Новый §5.1 в `tilemap.md` со
схемой и проверенным рецептом «две карты + декор между ними» (`-20` / декор `0`
/ `+20` → пиксель `(0, 0, 255)`); API не менялся — вклиниваться внутрь чужого
узла дороже двух узлов. Проверка: `tests/agent/tilemap_layers_test.py`.


### Не выпущено — свет: честный автоцвет, `lightMask(0)` и карта (task-43, 2026-10-16)

Раздел E отчёта BASHNYA (проверка 1.2.0 на живом бинарнике). Каждый пункт
воспроизведён своим прогоном; числа — до/после.

- **E1 (`color:'auto'` светил белым) — исправлено, два независимых дефекта.**
  (а) средний цвет текстуры считался УЖЕ ПОСЛЕ `SDL_DestroySurface`, то есть
  читал освобождённую память: `has_avg` оставался `false`,
  `textureAverageColor()` возвращал `null`, `auto_color_known` — `false`, свет
  белый `[255,255,255,255]`. Теперь цвет и миниатюра снимаются до освобождения
  поверхности. (б) alpha автоцвета упаковывалась как 0..1, а приходила 0..255:
  `Math.round(255*255) & 0xff = 1` — запись эмиттера `[52,46,34,1]` вместо
  `[52,46,34,255]`. Замер после правки: независимый подсчёт пикселей PNG
  `[52, 46, 34]` против движка **`[52, 46, 34]`** (было `null`/белый), свет
  `'auto'` 20.8 против белого 120.5 в той же точке.
  **Кадр листа — точный ленивый подсчёт.** Цвет кадра считается по ТОЧНОМУ
  прямоугольнику региона, лениво: первое обращение к кадру декодирует лист и
  кладёт копию пикселей под бюджет (16 МБ на текстуру, 64 МБ суммарно),
  дальше — кеш на спрайте (36 байт). Сверка с независимым подсчётом по PNG
  совпала на трёх регионах бит в бит: `[37.5, 84.38, 206.25]`,
  `[113.5, 107.1, 59.25]`, `[109.35, 113.4, 166.05]`. Цена: маленький лист
  0–1 мс на первое обращение, кеш 0 мс; лист 19 Мп (копия 75 МБ, ~143 мс) не
  декодируется вовсе — для него работает документированное приближение по
  миниатюре (0 мс).
- **E3 (`.lightMask(0)` не резал вклад карты) — исправлено.** Карта света —
  один полноэкранный композит и per-node маску не знает, поэтому узел с нулём
  бит теперь уходит в неосвещённый проход (как `.lit(false)`), а смена маски
  помечает реестр (иначе кэш скана оставлял кадр прежним). Замер: патч под
  источником **129.8 → 0.0** при `lightMask(0)` (было 129.8 → 129.8), без маски
  свет снова работает (129.8) — прежнее поведение не изменилось.
- **E2 (свет протекает на дальний слой) — задокументировано с рабочим
  способом.** Карта одна на кадр и слоёв не различает; partial-маски работают
  только в прямом световом проходе. Чтобы фон оставался тёмным, у его узлов
  нужен `lightMask(0)` или `.lit(false)` — проверено: исключённый узел 0.0
  против 129.8 у освещённого соседа.
- **E9 (`emissive(false)` не гасит) — не воспроизвелось.** Проверено замером:
  после `emissive(false)` список эмиттеров пуст (0 записей), окружение
  возвращается к фону (157.2 → 14.0). Оставлено стражем в
  `tests/agent/light_report_e_test.py`; «свет идёт» у BASHNYA — это, скорее
  всего, собственные пиксели узла (он виден и без emissive).
- Тесты: новый `tests/agent/light_report_e_test.py` (12 проверок), правки в
  `emissive_sprites_test.py` (проверка «auto не белый» + открытый пункт числом).
- **Тестовая ловля UB «освободил и прочитал»:** CMake-опция
  `R2D_TEST_FREE_POISON` (по умолчанию OFF, в релизном пути нулевая цена) —
  в пути загрузки картинки пиксели затираются перед `SDL_DestroySurface`,
  поэтому дефект E1 проявляется детерминированно, а не «иногда работает на
  освобождённой памяти». Прогоны: poison ON + старый порядок — **3 провала**
  `light_report_e_test` (`движок None` против `[52.00, 46.00, 34.00]`),
  poison ON + исправленный порядок — 12 ok, poison OFF — 12 ok. Тестовая
  сборка печатает о себе строку в лог. Документация: `docs/TESTING.md` §6.1
  (там же — почему `R2D_BINARY` не изолирует набор и правило «у ожиданий должен
  быть предел с диагностикой»).


### Не выпущено — освобождение текстур, загруженных спрайтами по пути (BASHNYA E6, task-45, 2026-10-16)

Пункт E6 отчёта BASHNYA (1.2.0): `$.resource.free(path)` работал только с
ИМЕНОВАННЫМИ ресурсами, а узлы грузят текстуры по пути напрямую. Потоковая
анимация меню (64 полноэкранных оверлея 1672×941) давала **402 МБ** в GPU, и
`free` по пути отвечал «такого ресурса нет».

- **Новое**: `$.resource.freeTexture(path)` → `{ok, busy, users, mb, freed, error}`
  и `$.resource.textures()` → `[{id, path, w, h, users, mb}]`; `$.resource.free(path)`
  для пути идёт тем же путём (возвращает 0 при успехе, −1 при отказе — прежний
  контракт не сломан). Служебные биндинги: `engine.textureUsers/textureList/textureSprites`.
- **Используемое не выгружается — это проверка, а не надежда**: текстуру, на
  которую ссылается живой узел (или кадр атласа), вызов не трогает и отвечает
  `busy: true` с числом `users`. Причина: `r2d_texture_free` гасит спрайты,
  ссылающиеся на текстуру, — узел молча остался бы без картинки. Спрайты,
  оставшиеся только в кэше JS (узел удалён), выгрузке не мешают — иначе потоковая
  анимация не освободила бы память никогда.
- **Числа** (`tests/agent/resource_free_test.py`, 4 оверлея 1024×1024):
  до загрузки 2 текстуры / **0.3 МБ** → загружено спрайтами по пути 6 текстур /
  **16.3 МБ** (+16.0); `freeTexture` при живом узле — отказ (`busy`, `users: 1`),
  память не меняется; после удаления узлов — по **4.0 МБ** на текстуру, итого
  возвращено **16.0 МБ**, снова 2 текстуры / 0.3 МБ. Повторная загрузка того же
  пути работает (кэш путей и спрайтов чистится при выгрузке), несуществующий путь
  отвечает причиной «текстуры с таким путём нет».
- **Тест падает до правки**: откат `src/render.c`, `src/render.h`, `src/script.c`,
  `src/highlevel/resource.js` до HEAD → сборка `build-2d` → **rc=1** (ни
  `freeTexture`, ни `textures()` в старом коде нет).
- **Границы**: правки в `src/render.c`/`src/render.h` (в задаче стояло `src/gfx*`,
  но реестр текстур живёт в render.c — согласовано с лидом). Заморозка API
  обновлена осознанно: **3042 → 3047**.
## Не выпущено — эталонное меню настроек: демо и туториал (2026-10-16)

Ответ на вопрос «можно ли на нашем движке сделать полноценное меню настроек» —
рабочий образец, а не обещание: `demos/settings` (четыре вкладки: графика, звук,
управление, язык) и публичный `docs/tutorial-settings.md` с кодом и числами.

- Всё применяется **на лету**: полный экран и разрешение (`$.window.displayModes()`
  + `fullscreen({mode,width,height,refresh})`), масштаб `$.ui.scale()`, SMAA
  `$.gfx.smaa()`, громкости `$.sound.volume/sfxVolume/musicVolume/mute`, язык
  `$.i18n.lang()` — без перезапуска игры.
- Сохранение через `$.store` в отдельный `settings.json` (718 Б на 15 значений),
  настройки переживают перезапуск движка (проверено автотестом), сброс возвращает
  дефолты; запись отложенная — `$.time.after(250)`, потому что `setTimeout` в
  QuickJS нет.
- Переназначение клавиш — штатным `$.input.waitForInput()` (отдельный
  `$.input.capture` не понадобился), конфликты — `$.input.conflicts()`, сброс
  к эталону — `markDefaults()`/`resetDefaults()`.
- Интерфейс — документ RmlUi (`demos/settings/settings.rml` + `.rcss`), как требует
  закон UI; кольцо выбора ведёт JS и обслуживает клавиатуру, геймпад и мышь одним
  кодом. Честное ограничение записано в туториале: `$.ui.gamepadNavigation` ведёт
  слой `$`-виджетов, но не документы RmlUi — геймпад в образце работает через
  привязки контекста ввода и чтение стика.
- Числа: открытие экрана 10.5 мс (повторные hide/show — 23 мкс), зона
  «интерфейс (RmlUi)» 0.080 мс с открытым меню против 0.023 мс с закрытым
  (≈ 0.06 мс на кадр, 0.35 % бюджета 60 FPS), применение настройки от 0.3 мкс
  (привязка клавиши) до 1.76 мс (полный экран), смена языка 0.28 мс, сброс 0.61 мс,
  запись файла 0.36 мс. Разметки 360 строк (170 RML + 190 RCSS), логики 757 строк JS.
- Проверка: `tests/agent/settings_menu_test.py` — открытие, изменение каждой
  настройки (числа до/после в API подсистем), сохранение через перезапуск,
  сброс, навигация клавиатурой/геймпадом/мышью, захват клавиши.

## Не выпущено — 1.2.1

### Фуллскрин: честный отчёт и починенный хоткей

Обе правки выросли из находок проверяющего на финальной связке 1.2.0.

1. **`--headless` больше не рапортует успех, которого нет.** Раньше
   `fullscreen({mode:'exclusive'})` при скрытом окне возвращал `{ok:true}`, а
   drawable не менялся (1280×720 → 1280×720), при этом `state()` сообщал
   `fullscreen_mode:'exclusive'`. Теперь движок после входа в эксклюзив сверяет
   ФАКТИЧЕСКИЙ drawable с выбранным режимом и при несовпадении откатывает всё
   (снимает фуллскрин и режим дисплея, возвращает сохранённую геометрию) и
   возвращает `false` с текстом вида: `режим 1920x1080 не применён: окно скрыто
   (headless), drawable 1280x720`. `state().fullscreen_mode` остаётся `windowed`.
   Отказ — это вариант (б): скрытое окно на macOS эксклюзив применяет ПО-НАСТОЯЩЕМУ,
   и глухой отказ был бы враньём в другую сторону; на X11-поде CI тот же вызов
   drawable не меняет — там сработает отказ.
2. **`state()` получил `drawable_changed` и `last_mode_error`.** `drawable_changed`
   вычисляется ЛЕНИВО: SDL применяет смену режима не в том же вызове, и
   синхронное сравнение врало `false` при изменившемся drawable. Уточнение: у
   режима `desktop` разрешение не меняется по определению, поэтому
   `drawable_changed:false` там — норма, правило касается эксклюзива.
3. **F11 больше не отключается навсегда после первой смены режима.** Настоящая
   причина (не «транзиент», как мы думали): снимок состояния `last` обнулялся в
   `$.window.fullscreen()` («состояние прочитаем заново»), а `tickWindow()` начинался
   с `if (!last) return` — то есть после первой же смены режима опрос хоткея
   умирал (`frames` замирал на 10), и клавиша не читалась вовсе. Исправлено: опрос
   идёт первым и без гейта по снимку; выдержка 6 кадров после любой смены режима
   (нажатие копится в защёлке); до 2 повторов, если режим не сменился (одно
   нажатие = один `toggles`); защёлка снимается при отпускании, иначе одно нажатие
   могло сработать дважды; `toggleFullscreen()` и `fullscreen(true|false)` идут
   через общий учёт.

Числа: чистое окно — нажатие обработано за 5 кадров (`toggles 0→1`,
`windowed→desktop`); сразу после 5 циклов `desktop↔exclusive↔windowed` — за 6
кадров; три нажатия подряд — три переключения с чередованием режимов;
`hotkey(false)` — режим и `toggles` не меняются; `frames` растёт непрерывно
(150 против замерших 10 до правки). Тест `window_fullscreen_test`:
38 ok / 2 fail → **40 ok / 0 fail**, формулировка «ограничение среды» заменена
фактом. Не воспроизводится локально только ветка ОТКАЗА (на macOS с дисплеем
эксклюзив применяется даже скрытым окном) — она покрыта кодом и инвариантом теста
(«либо отказ без смены режима, либо успех с `drawable_changed:true`») и сработает
на X11-поде CI.


## 1.2.0 — 2026-10-16

<!-- release-notes:begin — генерируется tools/release_notes.py, правьте текст вне маркеров -->

49 коммитов в релизе.

### Исправления

- 1.2.1: честный headless-отчёт фуллскрина и починенный хоткей F11 (`4fc74241d`)
  Обе правки — из находок проверяющего на финальной связке 1.2.0.
  1. headless больше не рапортует успех, которого нет: после входа в эксклюзив
  движок сверяет ФАКТИЧЕСКИЙ drawable с выбранным режимом, при несовпадении
  откатывает всё (снять фуллскрин, снять режим дисплея, вернуть геометрию) и
  возвращает false с текстом «режим 1920x1080 не применён: окно скрыто
  (headless), drawable 1280x720»; state().fullscreen_mode остаётся windowed.
  Выбран вариант «проверка по drawable», а не «скрытое окно → всегда отказ»:
  на macOS скрытое окно эксклюзив применяет ПО-НАСТОЯЩЕМУ (1280x720 → 1920x1080),
  и глухой отказ был бы враньём в другую сторону, а на X11-поде CI тот же вызов
  drawable не меняет — там отказ сработает.
  2. state() получил drawable_changed (ЛЕНИВЫЙ: SDL применяет смену не в том же
  вызове, синхронное сравнение врало false при изменившемся drawable) и
  …
- Нативный фуллскрин на лету: режимы дисплея, эксклюзив, F11, инвариант двух полей (`522c138fd`)
  Пользователь: «ну что мы за движок без нормального фуллскрина лол» + «еще чтоб на
  лету менялся». Было только безрамочное полноэкранное (SDL_SetWindowFullscreen):
  разрешение десктопное, видеорежим не переключался, герцовку выбрать нельзя.
  Сделано:
  - $.window.displayModes() — список режимов дисплея (57 на этой машине, максимум
  1920x1080 @ 100 Гц, герцовки {50, 60, 75, 100});
  - $.window.fullscreen({mode:'desktop'|'exclusive'|false, width, height, refresh}) —
  эксклюзив через SDL_SetWindowFullscreenMode; неизвестная опция ОТКЛОНЯЕТСЯ с
  именем (\{error:'неизвестная опция', option:'mod'\}, режим не переключается),
  неизвестный режим — тоже;
  - $.window.fullscreen(true) работает как раньше (безрамочный) — обратная
  совместимость подтверждена тестом;
  …
- Регрессия A1 закрыта + найден и починен дедлок новеллы (story/task/timeline) (`8ecefd9a5`)
  A1 сделал обёртку узла нерасширяемой (правильно: опечатка должна падать), но
  story.js ПРИСВАИВАЛ свойства обёртке: u.who.text = ... → TypeError, который $.task
  ловил и молчал, а $.story не смотрел на aborted. Сценка выглядела доигранной:
  last_line null, флаги частично применены, stderr чист. Поэтому красными были
  highlevel_story_test (5 FAIL) и highlevel_timeline_test (16 FAIL).
  Правки:
  - story.js: 2 места → u.who.text(...) и u.line.text(...) (весь файл прочекан: других
  присваиваний обёрткам нет); done(aborted) больше не молчит — пишет «сценка
  прервана (задача упала)» с текстом исключения;
  - task.js: проглоченное исключение видно — одна строка «$.task: задача «label»
  ПРЕРВАНА исключением: текст» на задачу (флаг reported_abort, чтобы не залить
  журнал), плюс task.aborted теперь отражает и исключение планировщика (раньше для
  …
- devtools_audio_test: проверка живыми каналами (41 проверка) вместо пустой сцены (`30812be92`)
  Регрессия с обрывом буфера закрыта теперь не по форме, а на реальных данных:
  - 3 занятых канала реальным hit.wav (play вернул id 0,1,2, active=3 из 128), при
  этом числа панели сверяются с API (громкость канала = заданной 0.50), а не
  «строка непустая»;
  - граница компактности: занято 12 → строк ровно 8, итог «занято 12 из 128
  (показаны первые 8)» — панель не врёт, когда занятых больше, чем показываем;
  - 100+: заняты все 128 → блок 718 символов при буфере 8192, итог «занято 128 из
  128», строк ≤ 8.
  Именно последний пункт и закрывает КЛАСС бага: раньше 128 каналов давали 11 025
  символов и строка рвалась на 5290 из-за char buf[8192] в engine.ui.getText.
  Факт для протокола: отдельного $.sound.load нет — soundId() сам зовёт
  engine.audio.load при первом обращении.
  …
- Вкладка AUDIO: компактный блок каналов (регрессия 1ec155f) (`295216dbb`)
  Панель печатала строку на каждый из 128 каналов — payload 11 025 символов, а
  engine.ui.getText копирует в char buf[8192] (script.c:2813); с кириллицей это
  ~5290 символов, и строка обрывалась посреди текста. До 128 каналов влезало,
  поэтому тест devtools_audio_test и покраснел.
  Теперь блок каналов показывает только ЗАНЯТЫЕ (не больше 8 строк, константа
  AUDIO_BUSY_ROWS) и итог первой строкой «занято N из M» — числа берутся из тех же
  данных, что busy(), то есть факт, а не пересказ. Payload: было 11 025 символов,
  стало 15 при пустой сцене и ~700 при 8 занятых — с запасом к буферу. Буфер
  getText не трогали (это правка общего API, на финише выпуска не нужна).
  Тест переписан осознанно, а не подогнан: для info и шин осталось полное
  совпадение панели с audio(), для каналов — «показанное = данным» (первая строка
  начинается с «занято N из M», построчных строк ровно min(занятых, 8), слова
  …
- Релизные заметки: группы по смыслу темы, а не по телу коммита (`8e18f925a`)
  Правка по замечанию к первому варианту: «Комплект шумов» уезжал в «Исправления»
  (в теле было «попутно исправлена строка»), «Версия: линия 1.x» — в «Добавлено»
  (в теле «новые»), «Удалено из публичной поверхности» — тоже в «Добавлено».
  Что изменилось:
  - сопоставление идёт ТОЛЬКО по subject, тело — фолбэк, если тема не совпала ни с
  одним правилом;
  - ключевое слово ищется с начала слова: «нов» больше не ловит «обновлять», «ci» не
  поймало бы «precision»;
  - новая группа «Удалено и изменено» — удаление публичного имени при замороженном
  API (§63) это событие для читателя, а не строка в «Исправлениях»;
  - сигналы создания («комплект», «реализ», «появил») в «Добавлено», слова «пайплайн»,
  «workflow», «упаков», «архив» — в «Сборку и версии».
  …
- Владение указателем VFS: контракт в заголовке + сторож против повторения P0 (`78c648acf`)
  После P0 (free() по указателю внутрь груза → SIGABRT) закрываем возможность
  повторения двумя дешёвыми средствами, а не обещанием «помнить»:
  1. src/payload.h — прямо над объявлением r2d_vfs_read стоит контракт: владелец
  возвращённого указателя — ГРУЗ, освобождать ТОЛЬКО r2d_vfs_free(); прямой
  free()/SDL_free() — это P0 (malloc: pointer being freed was not allocated),
  названы оба реальных места (real2d4.c, font.c) и тест-сторож. Человек, взявший
  функцию, видит это до чтения реализации.
  2. Сторож в tests/agent/real2d_payload_crash_test.py (раздел 0, идёт первым):
  R1 — если в одной функции перед free(v)/SDL_free(v) ближайшее присваивание в v
  это r2d_vfs_read, это нарушение; R2 — указатель утёк через return v и
  освобождается вызывающим. Законные ветки (malloc/своя память) сторож понимает
  сам, число таких веток печатает (сейчас 3), чтобы они не росли молча.
  …
- P0: standalone-сборка падала SIGABRT на грузе (.r2d4 и шрифт) (`5ffafce11`)
  r2d_vfs_read() для собранной игры возвращает указатель ВНУТРЬ буфера груза
  (владелец — груз, освобождать только r2d_vfs_free), а код звал free():
  - src/real2d4.c js_load (загрузка контейнера .r2d4 из груза) — 4 места; стек
  lldb: malloc «pointer being freed was not allocated» ← js_load + 776 ←
  js_call_c_function ← r2d_script_call_update (поток main);
  - src/font.c — тот же класс: после loadFont() из груза ЛЮБОЙ выход давал -6
  (r2d_font_shutdown), а перезагрузка шрифта падала сразу. Это, по-видимому, и
  есть та самая «иногда SIGABRT на выходе» из отчёта BASHNYA.
  Исправлено: free(...) → r2d_vfs_free(...) (для груза no-op, для буфера с диска
  SDL_free) — 4 места в real2d4.c и 4 в font.c. Ветку чтения с диска не удалял.
  Числа: demos/real2d standalone до фикса падал 3 из 3 (код -6/134), после — 0 из 3
  (код 0); шрифт из груза → выход: было -6, стало 0. Проверено временным откатом
  …
- devtools_hitch_test: убрана зависимость от нагрузки на машину (`8edcc1a5a`)
  Тест ассертил «ровно 1 / ровно 2 захвата» при пороге 50 мс. Под load average ~8
  в окно честно попадал чужой долгий кадр, и детектор ловил ЕГО — то есть тест
  падал на верном поведении движка (проявилось при полном прогоне, где параллельно
  работали другие агенты).
  Теперь: перед каждым arm() кольцо захватов очищается (engine.hitch.clear() +
  $.devtools.hitchClear()), проверяется «есть захват И он наш спайк» (count >= 1
  плюс |frame_ms - SPIKE_MS| <= 2 мс у свежего захвата), а «ровно 2» заменено на
  «минимум 2» с повтором спайка, если кольцо оказалось короче.
  Прогнан трижды подряд на нагруженной машине — «Все проверки пройдены» x3. Для
  полного прогона это значит: если тест упадёт, сообщение будет «пойманный захват —
  наш спайк», а не ложная регрессия по числу захватов.
- THIRD_PARTY_NOTICES: дописаны пять компонентов, которых не было в декларации (`a5d241e04`)
  В таблице не хватало реально используемых зависимостей: Steam Audio (вендорен,
  Apache-2.0 — а Apache требует сохранять уведомления), tinyexr (BSD-3, вендорен),
  ufbx (MIT или public domain, вендорен), stb_truetype (public domain/MIT, тянется
  FetchContent) и SDL_net (zlib). Пробел в декларации — это комплаенс, а не
  косметика: для Apache-2.0 и BSD обязательны уведомления в поставке.
  Копия этого файла идёт в пакет (tools/release.py, DOC_FILES), так что
  исправление доедет до следующих сборок автоматически.
- Раздел C: шум слушает --seed, независимые потоки, настраиваемый пул искр (`ddc7cf531`)
  C1 (дефект, а не мелочь): функции шума игнорировали --seed — у них был свой
  дефолт 0, поэтому noise2D(1.5,2.5) давал 0.6002521668560803 и при --seed 1, и при
  --seed 999, хотя next() различался. Игра выглядела детерминированной, но смена
  зерна не меняла мир. Теперь шум по умолчанию берёт зерно СВОЕГО генератора
  (у $.random — зерно сессии, у потока — зерно потока), явно переданное зерно
  побеждает всегда; экспортируемые чистые функции сохранили дефолт 0, поэтому
  эталоны алгоритма v1 (simplex_noise_test) не поехали, а legacy-эталон
  value-noise в highlevel_random_test теперь зовётся с явным зерном 0 (это эталон
  АЛГОРИТМА, а не дефолта). Проверено: все 6 входов шума различаются между --seed
  1 и --seed 999, при одном зерне карта побитово одинакова, 40 вызовов шума не
  сдвигают next(). Тест падал на старом коде (13 FAIL).
  C2: $.random.stream(name, { independent: true }) — поток получает зерно один раз и
  …

### Добавлено

- Меню настроек: эталонное демо + туториал (движок не понадобилось менять) (`a06e8f2bd`)
  Пользователь: «на нашем движке можно сделать полноценное меню настроек?» — ответ
  теперь не словами, а рабочим образцом. demos/settings: вкладки Графика (полный
  экран окно/desktop/exclusive, разрешение из displayModes(), $.ui.scale,
  $.gfx.smaa, FPS), Звук (мастер/эффекты/музыка, тишина, проверка, busy()/channels()),
  Управление (ребинд с захватом клавиши, сброс, геймпад), Язык ($.i18n на лету) +
  сброс всех настроек. Интерфейс — документ RmlUi (settings.rml + settings.rcss), как
  требует закон UI, а не узлы <ui.*>.
  ЧИСЛА (живая сборка, headless, шаг 1/60):
  - открытие экрана 10.4 мс, повторные hide/show 23 мкс;
  - кадр, зона «интерфейс (RmlUi)»: открыто 0.080 мс против 0.023 мкс закрыто, то
  есть меню стоит ~0.06 мс на кадр = 0.35% бюджета 60 FPS;
  - применение: полный экран 1.76 мс (самая дорогая настройка), смена языка 0.28 мс,
  …
- highlevel_timeline_test: предел ожидания и диагностика вместо 82 секунд тишины (`835defb68`)
  Было: play() крутил 600 итераций по step(8) без предела и без сообщений — при
  вставшей новелле это 82 секунды молчания (и до таймаута харнесcа в худшем случае),
  а в логе только «новелла не дошла до конца маршрута».
  Стало: play(a, picks, limit=600, stall_limit=40) отслеживает ПРОГРЕСС по отпечатку
  состояния (бит, реплики, развилки, локация, ожидание, открыт ли диалог, концовка).
  40 итераций без изменений — прогон признаётся вставшим, печатается разбор и
  возвращается False; то же при исчерпании limit. Состояние снимается ОДНИМ eval на
  итерацию вместо трёх — ожидание стало ещё и дешевле.
  Замер: 82.0 с → 19.8 с. Вместо тишины:
  -- новелла не дошла до конца: прогресса нет 40 итераций подряд
  -- ждали: waiting=None, диалог закрыт (страница -1 из 0, печать False), выборов 0
  -- бит 23, ticks 672, локация 'room', концовка нет
  …
- Журнал решений: абзац про точность шума переписан без дублирования (`37554f443`)
  Скриптовая правка дала корявую фразу (дважды упомянут reference.cpp, плюс устаревшее
  «число пока не закреплено — автор добавляет проверку»). Теперь абзац читается как
  одно предложение: допуск контракта 1e-6 (TOL в тесте), измеренный максимум 4.99e-10
  против reference.cpp (пин 785f37a), проверяется в noise_set_test.py:173-187 порогом
  MAX_DEV = 1e-9, печатается худшая точка; отдельно — 4.86e-06 от опубликованной
  таблицы апстрима и почему это не наша неточность.
- Шум: максимальное отклонение от эталона теперь проверяется машиной (4.99e-10) (`81f748a0d`)
  Число перестало жить в переписке. В tests/agent/noise_set_test.py добавлено:
  - MAX_DEV = 1e-9 с провенансом эталона (reference.cpp собирается с непатченным
  FastNoiseLite.h, пин 785f37a; строки 81-90) — порог в 1000 раз строже
  контрактного TOL = 1e-6, поэтому деградация точности падает на конкретном числе,
  а не проходит как «почти совпало»;
  - REFERENCE_DEVIATIONS + compare_reference(): все 21 сверка (6 источников, 3D,
  3 фрактала, 4 метрики cellular, 7 типов возврата, повтор fbm) копят |наше − эталон|;
  - блок, который считает максимум, ПЕЧАТАЕТ его и проверяет порогом.
  Фактическая строка вывода:
  -- максимум отклонения от эталона reference.cpp: 4.99e-10 (худшая точка:
  cellularReturn/distance2Add), точек 21, порог 1e-09
  Автор честно поправил свой прежний отчёт: «≤4e-10» было по распечаткам отдельных
  …
- Журнал решений по зависимостям: что взяли, что нет и почему — с числами (`bbe12faf5`)
  docs/internal/DEPENDENCY_DECISIONS.md (новый, внутренний — в поставку не поедет):
  сводная таблица «компонент → решение → лицензия → пин/место → доказательство» и
  раздел на каждый компонент «решение → причина → числа → дата → доказательство».
  В шапке закреплено правило: решение без числа и ссылки на доказательство решением
  не считается; нет числа — пишем «не измерено» и что для этого нужно.
  Ключевое:
  - Effekseer — НЕ встраиваем: ядро 187 файлов / 46 033 строки (MIT), 61/61 объектов
  собрались без CMake апстрима и 8 подмодулей, 53 виртуальных метода в 8
  интерфейсах, симуляция 1000 инстансов 0.225-0.233 мс/кадр (2000 частиц) и 0.433 мс
  (3992 частицы), удельно ~0.11 мкс на частицу; путь «родной бэкенд с шарингом
  девайса» закрыт — в SDL_gpu.h 3.4.0 нет свойств с нативным хендлом (проверено
  grep'ом); свет только у моделей (EffectNodeModel.cpp:123-127), спрайты/ленты не
  …
- GitVerse: зафиксированы платформы (только Linux + MinGW) и таймауты джобов (`7263f8bd6`)
  По документации GitVerse (https://gitverse.ru/docs/cicd/docs/runners/cloud-hosted/)
  облачный раннер там ОДИН — ubuntu-latest: Linux-контейнер, docker.sock нет (есть
  kaniko), macOS/Windows-раннеров в облаке не существует. Наш workflow этому уже
  соответствовал (все пять джобов runs-on: ubuntu-latest, контексты gitverse.*,
  Windows собирается кросс-компиляцией MinGW на Linux, macOS только копируется из
  dist/), но это нигде не было записано — теперь записано комментарием в шапке со
  ссылкой на документацию, чтобы никто не пытался добавить сюда macOS-джоб.
  Плюс явные timeout-minutes у всех джобов (static 30, сборки 120, macos-artifacts
  15, release 20): у платформы есть лимит на время джоба, и лучше упасть самим с
  понятным сообщением, чем быть убитыми платформой без диагностики.
  Гейты: release_ownership, portability, repository_hygiene — зелёные.
- Комплект шумов: $.noise на FastNoiseLite (OpenSimplex2, Perlin, Cellular, фракталы) (`c35277a29`)
  Запрос пользователя: «Еще добавьте комплект шумов открытых OpenSimplex и тд».
  Взяли FastNoiseLite (MIT, один заголовок) — вендорен в third_party/fastnoise_lite
  БЕЗ правок (коммит 785f37a, SHA-256 зафиксирован), рядом LICENSE, README с пином и
  reference.cpp — программа, которой снят эталон, чтобы проверку можно было
  воспроизвести.
  Тонкий C-фасад (src/noise.h/.cpp, свой cmake/Noise.cmake): конфигурация,
  get2/get3, warp2/warp3, field2/field3/fieldRGBA. $.noise — 28 имён в
  src/highlevel/random.js (новый модуль не заводили: зерно сессии — состояние этого
  модуля, меньше точек конфликта).
  ЭТАЛОН (главное в этой задаче): значения сняты с НЕПАТЧЕННОГО заголовка и
  заморожены в тесте, совпадение <=4e-10 (float32->double): simplex2 0.274064004,
  simplex2S 0.154386789, perlin 0.0545770712, value 0.375854313, cubic 0.175246984,
  …
- Emission-спрайты в 2D: спрайт светит на окружение и кормит bloom (`4bc79bc3d`)
  Спрайт (и rect, и nine-slice) может быть ИЗЛУЧАТЕЛЕМ: свет идёт тем же путём, что
  у <light> — слой lightmap + pushGlow, общий бюджет источников, общая деградация.
  Второго пути света не появилось.
  Измерено на живом кадре (скриншоты + PNG-ридер, демо demos/litsprites):
  - карта света ВКЛ, радиус 256: 255.0 → 208.7 → 157.5 → 79.0 на 0/32/64/128 px при
  фоне 14.0, падение монотонное; треугольников +1092 — ровно столько же даёт
  настоящий <light> с теми же параметрами;
  - карта света ВЫКЛ: 146.7 против фона 14.0, RGB [243, 98, 98] — цветной пересвет
  подтверждён ПО КАНАЛАМ (R отдельно от G/B), а не по общей яркости;
  - shadows: true + препятствие: 128.2 → 24.7;
  - бюджет общий: 45 эмиттеров при лимите 32 → светят 32, деградировали 13, записи
  degraded: true, предупреждение один раз; поля emitters/emitterLights/
  …
- Геймпады: навигация интерфейса, снимок состояния и сброс слота (task-24) (`d72b2b44e`)
  Разведка показала, что база уже была (gamepad(slot) с down/pressed/axis/
  connected/rumble, привязки gamepad.a, мёртвая зона, gamepadOn/gamepadOff, 4 слота,
  инъекция pad) — поэтому работа не «сделать с нуля», а закрыть дыры. Проверено
  фактом, и вот что нашлось:
  - залипания кнопок при отключении НЕТ (C обнуляет cur/prev/axes, JS сбрасывает
  удержания, есть resetHeld/stuck) — проверено эквивалентом отключения;
  - pressed() — фронт, down() — удержание (кадр 1 даёт оба, кадр 2 только down);
  - мёртвая зона ровно на пороге включительна (0.2 → 0.2000), deadzone(0.5) гасит 0.2;
  - курки 0..1 (leftTrigger 0.75 → 0.750), а не -1..1;
  - круглый стик: vec(1,1) даёт длину ровно 1.000000, сырые axis() остаются сырыми
  (нормирует vec — это записано честно);
  - 4 слота независимы, одна кнопка на двух падах даёт два разных фронта;
  …
- SMAA: пост-антиалиасинг для 2D (выключен по умолчанию) (`4f8c39255`)
  Пользователь: «SMAA можно попробовать». Врезан в существующий пост-проход:
  $ .gfx.smaa(on|{mode, pixelArt}) + smaa_steps, пресеты low/medium/high = 2/4/8 шагов.
  Числа (живой движок, headless Metal, окно 120 кадров):
  - «лестничные» пиксели на наклонной кромке 775 → 620;
  - выключенный AA побитово равен прежнему кадру (эталонный хеш 3f983ce4c2bba538
  снят ДО правок и вшит в тест), SPIR-V/MSL варианта без SMAA совпадают с прежними
  побайтово;
  - цена: 1280x720 GPU 0.84 → 0.96-1.12 мс, 1920x1080 0.77 → 1.28 мс (разброс ±0.15);
  - порядок проходов «сцена → SMAA → UI»: контраст кромки глифа в панели RmlUi
  0.803 → 0.803 (UI не мылится), тогда как тонкий штрих В СЦЕНЕ получает
  237 → 399 промежуточных пикселей — ровно поэтому UI оставлен после AA;
  - pixelArt: true честно выключает AA (противоречит целочисленному скейлу и снапу);
  …
- ХРТФ: гибрид ITD (steam + наша задержка) и метрика фронт/тыл LSD (`fb53ba0c9`)
  Пункт 1: у канала появился режим 2 — только ITD: к готовому стерео Steam
  применяется дробная задержка дальнего уха, спектр библиотеки не трогается.
  Порядок в cooked-колбэке: Steam → наша задержка → (для синтетики) полная модель.
  Опция itd: 'auto'|'model'|'off', по умолчанию 'auto'. Молча гибрид не включается:
  геттер отдаёт itd_source ('model'/'none'), а в доке отдельный раздел о том, что
  именно звучит в steam-режиме.
  Измерено (шум +90°, 44.1 кГц, кросс-корреляция): steam+auto → 0.658 мс
  (itd_source 'model'), steam+off → 0.000 мс (чистый библиотечный выход),
  синтетика → 0.658 мс (задержка внутри модели). Константа
  STEAM_BACKEND_HAS_ITD = false помечена как измеренный факт: если библиотека
  начнёт задерживать сама, её надо перемерить, иначе получим двойной ITD.
  Пункт 2: метрика фронт/тыл заменена на лог-спектральное расстояние (RMS разницы
  …
- RmlUi: зафиксировано решение не обновлять (6.3 — последний тег) (`e66868e54`)
  Пользователь решил RmlUi не трогать. Пин остаётся ba95ffe (6.3), но разведка
  апстрима сохранена сноской в THIRD_PARTY_NOTICES.md, чтобы следующий человек не
  ходил туда заново:
  - 6.3 (ba95ffe, 2026-08-22) — последний тег, ветки 6.3.x нет;
  - master = объявленный 6.4-dev (e74ad4ed): box shadows, относительные пути в
  @font-face, выбор скролл-контейнера, удаление SDL_renderer-бэкенда,
  Vulkan/MoltenVK, operator[] вместо неявного указателя у Colour/Vector (#1018);
  - ОСОЗНАННО НЕ ОБНОВЛЯЕМ: нерелизная версия; откат — одна строка;
  - патч rmlui-webgpu.patch проверен на master: RmlUi_Renderer_SDL_GPU.cpp там
  байт-в-байт как в 6.3, WGSL апстрим так и не принял, значит патч остаётся
  нужным и перебазировать его не требуется.
  Правки пина в cmake/Dependencies.cmake откачены полностью (диф пуст), новая
  …
- Доки и $ API под новые функции: HRTF, захват выхода, новые имена в заморозке (`e7e514406`)
  Пользователь напомнил: новые функции без документации и без отражения в $ API —
  не сделанная работа. Закрываю разъезд, который уже был:
  - docs/AGENT_API.md: новый раздел «Звук: бинауральный режим и захват выхода» —
  $.audio.hrtf() с перечислением полей геттера, $.audio.captureStart/captured/
  captureClear, и измеренные факты вместо обещаний (ITD модели 0.658 мс, ILD на
  4 кГц против 200 Гц, отсутствие своей ITD у настоящей HRTF, отсутствие высоты
  в 2D). Раньше эти функции были описаны только в highlevel/audiobus.md — в
  агентском справочнике их не было вовсе;
  - CHANGELOG.md: раздел про HRTF, захват, $.sound.channels (16 → 128) и
  $.hits.pool(n) — с числами и с честной пометкой про гибридный ITD;
  - tests/api_freeze_baseline.txt: снимок обновлён осознанно (2994 имени) — новые
  публичные имена $.audio.hrtf/captureStart/captured/captureClear внесены.
  …
- ХРТФ в 2D: настоящая HRTF (Steam Audio) + модель как фолбэк, с измерением на живом выходе (`3f990eac5`)
  В движке уже была настоящая HRTF — Steam Audio вендорен, audio_spatial.c делает
  iplHRTFCreate + iplBinauralEffectCreate, и это использовали RE2D-миры. К 2D-слою
  $.audio не было подключено. Теперь два пути:
  - backend:'steam' — позиционные звуки идут через существующий
  r2d_audio_world_channel(..., hrtf=true) (добавлены биндинги
  engine.audio.worldChannel/hrtfAvailable); направление считает acoustics.js,
  второй формулы азимута не появилось;
  - backend:'synthetic' — модель в audio.c: ITD дробной задержкой по Вудворту,
  ILD-полка выше 1.2 кГц, однополюсная тень 20→2 кГц, полка +4 дБ сзади, мёртвая
  зона у фронта; живёт в cooked-колбэке канала и стирает состояние при
  освобождении канала.
  $.audio.hrtf() всегда называет ФАКТИЧЕСКИЙ backend и причину, если бэкенд
  …

### Удалено и изменено

- Удалено из публичной поверхности: $.net.host_ (`ae21bb466`)

### Документация

- Сайт: возвращены три документа входа (первая игра, сборка в один файл, демо) (`74183cc12`)
- Поставка и сайт: внутренние доки больше не публикуются (`47a446d64`)
- Справочник внутренних биндингов дополнен: allowlist стал пустым (`ab6bd259c`)
- Долг по докам: закрыто 90 имён геймплея (world, inv/items, dialog, cels, nav, grid, combat, quest, story) (`8c1f3234e`)
- Долг по докам: закрыто ещё 54 имени (графика/UI/звук и $ .raid/$ .real2d) (`e4eea5fad`)
- Релизные заметки: компактный формат для витрины, подробный для CHANGELOG (`6f69b76c1`)
- Релизные заметки: CHANGELOG собирается из коммитов релиза (`9acbaa50a`)
- zstd для груза, константы в заморозке API и правило отрицаний в гейте доков (`a04c55f3c`)
- Долг по докам: закрыто 128 имён (ядро, состояние, данные, $.input) (`df4a8ca97`)
- Tracy (R2D_TRACY, OFF по умолчанию) и рендер-биндинги в доках (`fd89e906f`)
- Гейт «у публичного имени есть документация» + закрыт долг $ .ctx/$ .math/$ .fn (`a05413fed`)

### Тесты и гейты

- window.md: честно про headless и транзиент F11 (находки проверяющего) (`0945bc14c`)
- repository_hygiene: гейт объясняет, как починить находку, а не только что она есть (`e75c26fec`)
- Раздел C: 128 звуковых каналов, честный remove, обновлённая заморозка API (`1ec155f55`)

### Сборка и версии

- Перепакованы macOS-архивы 1.2.0: чистые манифесты без .DS_Store (`a00b17ce0`)
- P0 упаковки: манифест SHA256SUMS считался без фильтра мусора (`2d228840f`)
- audio_stub: заглушка для r2d_audio_itd_channel (сборка без звука) (`7656406a6`)
- Mos.Hub: пайплайн больше не запускается на коммиты (egress у раннера закрыт) (`28b204838`)
- Версия: линия 1.x, 1.2.0 — поверхность заморожена (`a2619f36a`)
- Перепакованы macOS-архивы 0.1.35: без мусора и с последними правками (`aebea0968`)
- Упаковщик не тащит системный мусор в архив (`e82047229`)

### Прочее

- Лаунчер: карточка «Настройки» для эталонного меню (`602c17f2e`)
- Russiano2D 1.2.0 (`e13ffea90`)

<!-- release-notes:end -->

### Подробности (написано вручную)

Текст ниже перенесён генератором из разделов «Не выпущено» без изменений (опущен только уровень заголовков).

### Не выпущено — нативный фуллскрин «на лету» (task-40, 2026-10-16)

Требование: «ну что мы за движок без нормального фуллскрина лол» + «еще чтоб на лету
менялся». Было только булево `fullscreen(on)` → безрамочный режим; теперь есть
режимы дисплея, эксклюзив с выбором разрешения и герцовки, возврат геометрии и F11.

- **Числа (эта машина)**: режимов дисплея **57**, максимальный **1920×1080 @ 100 Гц**,
  герцовки **50/60/75/100**; вход в эксклюзив **1.6–6.4 мс**; drawable реально
  меняется (pixelSize и viewport 1280×720 → **1920×1080**), а не только флаги;
  возврат в окно восстанавливает геометрию (1280×720 @ (320,195)); 5 циклов
  окно↔desktop↔эксклюзив не растят `renderInfo` (3 текстуры, 67137 px до и после).
- **API**: `$.window.displayModes()`, `$.window.fullscreen({mode, width, height, refresh})`
  (`true` по-прежнему = desktop — совместимость), `state().fullscreen_mode`
  (`'windowed'|'desktop'|'exclusive'`), `$.window.hotkey(клавиша|false)` — по умолчанию
  **F11**, Alt+Enter не вешаем (его может обрабатывать ОС/WM → двойное переключение).
  Инвариант: `fullscreen === (fullscreen_mode !== 'windowed')` — держится во всех
  четырёх состояниях.
- **Неизвестные опции отклоняются**: `fullscreen({mod:'exclusive'})` →
  `{error:'неизвестная опция', option:'mod'}`, режим НЕ меняется (раньше объект молча
  принимался за «включить» — нашёл проверяющий).
- **Исправлено по ходу (найдено запуском, оба — мои же ошибки)**:
  1. при входе в эксклюзив режим дисплея применялся, а **drawable не менялся** (окно
     оставалось 1280×720) — «флаги сменились, а кадр нет»; лечится явным
     `SDL_SetWindowSize` + `SDL_SyncWindow` после смены режима;
  2. возврат геометрии не работал, потому что блок восстановления был под
     `!app->headless`, а агентский прогон идёт со скрытым окном (`visible:false`) —
     восстановление просто не выполнялось. Снял условие: скрытое окно тоже
     возвращается в свой размер, и `state()` остаётся согласованным.
- **События дисплея**: `SDL_EVENT_DISPLAY_CURRENT_MODE_CHANGED/ADDED/REMOVED/ORIENTATION`
  приводят окно и состояние в согласованность — обновляют фактические размеры и
  герцовку, а в оконном режиме возвращают сохранённую геометрию (дожим ограничен
  40 попытками и запускается событием, а не счётчиком кадров).
- **Ограничение среды (наблюдение 2026-10-16), а не провал**: в агентском прогоне
  виртуальная клавиша протокола не видна ВНУТРИ кадра — опрос хоткея исполняется
  каждый кадр (`frames: 17`), читает `$.input.down('f11')` и всегда получает `false`,
  тогда как чтение через `eval` даёт `true`; в изоляции на фикстуре `hello` тот же
  хоткей срабатывает (`toggles: 1`, режим → desktop). Что проверяется жёстко:
  нажатие **не съедается** (`input.down === true`) и опрос **исполняется каждый кадр**;
  что оформлено ограничением с причиной и числами в тесте и в `window.md` — само
  переключение по F11 в агентском прогоне. Фронт нажатия при этом копится по уровню
  (защёлка), как у геймпада, чтобы переживать пропущенный кадр.
- **Самоопровержения** (чтобы в архитектуру не попал ложный факт): гипотеза «платформа
  не даёт вернуть размер окна» — **неверна**, виноват был мой guard `!app->headless`;
  догадка «в агентском режиме кадры идут мимо `r2d_app_begin_frame`» — **неверна**,
  `main.c:212` зовёт её и в агентском режиме (молчал отладочный лог из-за того же
  guard'а).
- **Отдельный факт для разбирательства**: `r2d_app_begin_frame` — не единственная
  точка «начало кадра» для агентского режима: отложенный по кадрам код, поставленный
  туда, в агентском прогоне не исполнялся. Проверка показала, что причина в другом
  (мой guard по headless), но само расхождение путей кадра стоит проверить отдельно.


### Не выпущено — долг по документации, часть 6: `$.sound` и `$.tilemap` (task-36, 2026-10-16)

Задокументированы полными именами **27 имён** (14 в `$.sound`, 13 в `$.tilemap`),
строки `$.sound.*` и `$.tilemap.*` сняты из `tests/api_docs_allowlist.txt`: в
файле больше **не осталось ни одной строки `debt`** (остались 10 строк, все
`internal` — биндинги C-уровня из чужой доли). «Задокументировано буквально»
1846 → **2044**. Гейты `api_docs_sync_test` (5 ok), `doc_claims_test` (37 ok) и
`doc_coverage_test` (4 ok) зелёные; факты — вызовами на живом движке.

Подтверждены известные числа: `$.sound.channels()` = **128**,
`$.sound.busy()` → `{ active, free, total }`, вытеснение по `priority`, `-1` при
полном пуле (129-й звук с `priority: 1` при пуле из `priority: 100` → `-1`;
тот же звук с `priority: 999` → вытесняет и получает канал 0).

**Расхождения доки и кода, найденные вызовом (не пересказ названий):**

* `$.sound.stop(channel, fadeMs)` **без канала останавливает канал 0**, а не всё:
  проверено — после `stop()` `playing(0)` = `false`, `playing(1)` = `true`.
  «Остановить всё» — это `$.sound.stopAll(fadeMs)`. Затухание — в миллисекундах.
* `$.sound.playing(channel)` и `$.sound.priorityOf(channel)` принимают **номер
  канала**, а не имя звука: `playing('hit.wav')` молча смотрит канал 0; вызов без
  аргумента — тоже канал 0 (при играющем канале 1 `playing()` = `false`).
* `$.sound.sfxVolume(value)` и `$.sound.pauseMusic(paused)` — **только сеттеры**:
  без аргумента ничего не читают и возвращают `$.sound`; геттер есть у `mute()`.
* `$.sound.duration(what)`: секунды для известного звука (WAV 0.5 с → `0.5`),
  **`-1`** для неизвестного (не `0`).
* `$.sound.linearToDb(0)`, отрицательное значение и вызов без аргумента дают
  **`-Infinity`** (в JSON выглядит как `null`), а не `NaN`; `linearToDb(0.5)` =
  `-6.020599913279624`.
* `$.tilemap.numbers()` — **число живых карт**, а не «числа» данных: проверено
  `0 → 1 → 2` при создании двух карт.
* `$.tilemap.applyPadding(norm, pad, padTile)`: `pad` — **уже нормализованный**
  массив (`normalizePad`), число даёт `TypeError: value is not iterable`;
  `norm.data` обязан быть типизированным массивом — обычный JS-массив даёт
  `TypeError: not a function` (внутри `.subarray`).
* `$.tilemap.visibleRange(layer, geom, cam)` читает размеры **слоя**
  (`layer.tile/w/h`), а не `geom.cols/rows`; слой без `w`/`h` возвращает
  `x1/y1 = NaN` (в JSON `null`), а не пустой диапазон.
* `$.tilemap.mergeTilesByY(lists)` **не сортирует**: на неотсортированном входе
  порядок сохраняется как есть (`[[{ty:1}],[{ty:0}]]` → `[1,2]`).


### Не выпущено — долг по докам, часть 5: геймплей и остальные `engine.*` (task-31, 2026-10-16)

Публичная поверхность не менялась — только документация; заморозка API держится.

- **Закрыто 90 имён** в 18 неймспейсах — полные перечни с фактами с живого
  движка: `$.world` 11, `$.inv` 11, `$.dialog` 8, `$.items` 8, `$.cels` 9,
  `$.nav` 6, `$.barks` 5, `$.grid` 5, `$.combat` 4, `$.quest` 4, `$.i18n` 3,
  `$.story` 3, `$.anim` 3, `$.activation` 2, `$.agent` 2, `$.collision` 2,
  `$.loading` 2, `$.random` 2. Ещё 16 имён (`$.raid`, `$.real2d`) переданы
  profiler-core и закрыты им. Строк `debt` по task-31 в allowlist не осталось.
- **`$.world` — абзац «чего нет и почему»**: `$.world.remove`, `$.world.clear`,
  `$.world.destroy` не существуют (проверено: `typeof` = undefined). Удаление
  делается от узла: `.remove()` уничтожает тело (`bodyCount` 8 → 7), снимает
  узел из `$.world.all()` (10 → 9) и прячет от селекторов (3 → 2), а `.hide()` и
  `.detach()` физику и селекторы **не** трогают.
- **Найденные расхождения доки и кода** (исправлены в доке):
  * `$.barks.define('имя', [строки])` создаёт ситуации `'0'`, `'1'`, а не
    `'имя'`: второй аргумент — карта «ситуация → строки», пример в доке был неверен;
  * `$.collision.of()` принимает узел/обёртку, но не селектор-строку
    (`of('#hero')` → `null`, хотя `apply('#hero', …)` работает) — кандидат на
    починку после выпуска;
  * `$.grid.count(g)` без значения всегда `0`: сравнение идёт с `undefined`, а не
    с нулём — значение нужно передавать явно;
  * `$.loading.watch(null)` возвращает `$.loading` (не ошибка), `watched()` → `null`.
- **`engine.*` (10 имён)**: причина `internal` подтверждена — из игрового кода
  не вызываются (в `src/highlevel/*.js` вхождений нет, кроме внутренних вызовов
  JS-слоя движка). Все десять описаны в справочнике `docs/internal/NATIVE.md`:
  четыре — в таблице «Что ещё есть в `engine`», шесть (`bodyGeneration`,
  `clearPhysicsErrors`, `contactStay`, `physicsErrors`, `setContactStay`,
  `setSnap`) — в новом подразделе «Контакты, ошибки физики и снаппинг вершин»
  (что пишет C, как видно из `$`, чем проверено на живом движке). Строки
  исключений для всех десяти сняты: имя, описанное в справочнике, гейт считает
  задокументированным — `tests/api_docs_allowlist.txt` остался без единой строки
  долга/исключения (только история закрытого).
- Команды: `python3 tests/api_docs_sync_test.py` → «Все проверки пройдены
  (3040 имён: документация или осознанное исключение)», мёртвых строк нет;
  `doc_coverage_test.py`, `doc_claims_test.py`, `api_freeze_test.py` — зелёные.


### Не выпущено — долг по докам, часть 4б: `$.gfx`, `$.ui`, `$.screen`, `$.curve`, `$.layers`, `$.physics` и хвосты (task-30, 2026-10-16)

Закрыто **38 имён** в 15 строках allowlist (долг `debt` в моей части — ноль):
`$.gfx.clipReset/registerNodeRenderer/registerUINodeRenderer/white`, `$.ui.show/hide/fps/scaleValue/iconCount/iconNames`,
`$.screen.list/current/focusedNode/prev/off/remove`, `$.curve.sample/clear/normalizePoints/colorToBytes/packColorBytes`,
`$.easing`, `$.layers.hide/toggle/sendToBack/repeatInfo/repeatOff`, `$.physics.errors/report/clear`,
`$.audio.getMasterVolume/volumeOf`, `$.window.cursors/off`, `$.atlas.clearErrors`, `$.hits.pool`,
`$.rotSprite.info/dispose`.

Каждое имя описано **фактом вызова** на живом движке (раздел «Проверено вызовом на живом движке
(task-30)» на странице своего неймспейса). Найденные при этом расхождения «имя ≠ поведение»:

- `$.easing('outQuad', 0.5)` возвращает **`null`** (как и на неверном имени), `$.easing.list` — не функция;
- `$.screen.add` **не существует** (`TypeError`), хотя `list/off/remove/current/prev/focusedNode` есть;
- `$.ui.show` возвращает **обёртку узла** (цепочку), а не `true/false`; `hide` ставит `node.visible = false`;
- `$.rotSprite.info(node)` на узел `<rotSprite>` даёт `null` — ожидается хендл загруженного спрайта (как у `engine.rotSprite*`);
- `$.gfx.white` — **число `0`**, а не цвет;
- `$.hits.pool(n)`: диапазон 1..64, `pool()` → `8`, `pool(16)` → `true`, `pool(99)` → `false`;
- `$.window.cursors()` — ровно 6 курсоров: normal, hidden, crosshair, hand, text, wait;
- `$.ui.iconCount() === $.ui.iconNames().length` (2235) — проверено равенством.

`tests/api_docs_allowlist.txt`: было 87 строк (301 имя), стало 17 строк (60 имён) — из них 50 `debt`
в зонах других задач (`$.sound`, `$.tilemap` и прочее) и 10 `internal` с доказательствами.
Гейты: `api_docs_sync_test` и `doc_claims_test` зелёные (3040 имён).


### Не выпущено — линия 1.x: версия 1.2.0 (2026-10-16)

Версия движка переходит с 0.1.x на **1.2.0**. Причина не косметическая: с этого
дерева публичная поверхность `$` **заморожена** и охраняется гейтом
(`tests/api_freeze_test.py`, 3012 имён, включая публичные константы со значениями,
плюс `tests/api_docs_sync_test.py` — «у каждого имени есть документация»). Пока ни
того, ни другого не было, 0.x честно означал «поверхность ездит»; теперь она
зафиксирована, и 1.x — это заявление, что ломать её можно только осознанно, с
обновлением снимка и записью здесь.

Что вошло в линию (всё проверено запуском на живом движке, числа — в разделах ниже):
- закрыты все восемь дефектов A1–A8 из отчёта внешней команды BASHNYA и раздел B
  (док расходился с бинарником), раздел C разобран по существу;
- звук: **128 каналов** вместо 16, `$.sound.channels()`, `$.hits.pool(n)`, шум
  больше не игнорирует `--seed`, честный `$.fs.remove()`;
- **ХРТФ в 2D**: настоящая HRTF (Steam Audio) + встроенная модель как фолбэк,
  гибрид ITD с честным указанием источника в геттере;
- графика: SMAA (выключен по умолчанию), emission-спрайты (спрайт светит на
  окружение и кормит bloom), комплект шумов OpenSimplex2/Perlin/Cellular;
- инструменты: Tracy (`R2D_TRACY=OFF`), zstd для груза (формат v2, читается и v1),
  геймпады с навигацией интерфейса, `docs/api_docs_sync` — гейт документации;
- документация: закрыт долг по 612 именам (документация или доказанное исключение).

**Как выпускать эту линию.** Номер поднимается через `tools/release.py --bump`,
который теперь понимает `patch|minor|major` и явную версию (`--bump=1.3.0`).
`build_and_push.sh` принимает то же в `BUMP`: `BUMP=0` — выпустить версию как есть
(так выпускается 1.2.0), `BUMP=1.2.0` — задать номер явно, `BUMP=patch` — обычный
инкремент. Скрипт отказывается бампать по умолчанию, если текущая версия ещё не
помечена тегом: иначе в истории появляются пропущенные номера (0.1.35 не
выпускалась, а 0.1.36 уже была бы выпущена).


### Не выпущено — комплект шумов: `$.noise` на FastNoiseLite (task-32, 2026-10-16)

Запрос пользователя: «Еще добавьте комплект шумов открытых OpenSimplex и тд».
В `$.random` был только «наш» замороженный simplex/value v1 — для генерации
миров, текстур и тайлмапов этого мало.

**Что добавилось.** Новое пространство имён `$.noise` поверх вендоренного
FastNoiseLite (MIT, `785f37a`, SHA-256 в `third_party/fastnoise_lite/README.md`):
источники `simplex2`, `simplex2S`, `perlin`, `value`, `cubic`, `cellular`;
фракталы `fbm`/`ridged`/`pingpong` поверх любого источника; domain warp
(`domainWarp`, `warped`, 3D-варианты, фрактальный warp); 2D и 3D; массовые
`field()`/`field3()`/`fieldRGBA()` — сетка считается в C одним вызовом и сразу
годится в `engine.textureFromPixels`. Списки значений и умолчания доступны из
рантайма (`$.noise.sources()`, `$.noise.defaults()`). Подробности —
[docs/highlevel/noise.md](docs/highlevel/noise.md), для агентов —
[docs/AGENT_API.md](docs/AGENT_API.md) §7.2.

**Честность — тремя проверками, а не обещаниями:**

* **Эталон апстрима.** Значения в `tests/agent/noise_set_test.py` сняты с
  *непатченного* заголовка программой
  `third_party/fastnoise_lite/reference.cpp` (она в репозитории, чтобы это
  можно было перепроверить) и совпадают с точностью до float32 (≤4e-10).
  Таблица 4×4 и domain warp дополнительно сверены с опубликованным тестом
  апстрима. Кривой порт или правка заголовка теперь падают на числах.
* **Зерно сессии.** Без явного `seed` шум берёт зерно сессии (`--seed`,
  `$.random.seed(n)`); `--seed 1` и `--seed 999` дают разные поля, одно зерно —
  побитово одинаковые, явный `seed` побеждает. Второй шум не разошёлся с
  исправлением C1 отчёта BASHNYA.
* **Массовый путь не врёт.** `field()` побитово совпадает с поштучными
  `get2()` тех же координат (проверка на 1536 точках). Цена: поле 256×256 —
  simplex2 0.5 мс, fbm (5 октав) 2.8 мс, cellular 0.7 мс; те же 65 536 точек
  поштучно — 22.7 мс (×48, macOS arm64, RelWithDebInfo).

**Не изменилось:** `$.random.noise1D/noise2D/simplex2D/noise` и их эталоны v1
(`tests/js/simplex_noise_test.mjs`) — они остаются как были.

**Чего нет:** 4D-шума (у FastNoiseLite его нет), GPU-генерации (поля считаются на
CPU), отдельного «OpenSimplex от Курта Спенсера» (взят OpenSimplex2/2S из
FastNoiseLite).


### Не выпущено — P0: standalone-сборка падала SIGABRT на грузе (`.r2d4` и шрифт) (task-33, 2026-10-16)

Найдено при приёмке zstd-груза: собранная игра с ассетами падала на старте
`SIGABRT` (`malloc: pointer being freed was not allocated`, код 134). Стек (lldb):

```
#0 ___BUG_IN_CLIENT_OF_LIBMALLOC_POINTER_BEING_FREED_WAS_NOT_ALLOCATED
#1 js_load + 776         (src/real2d4.c — $.real2d.load контейнера .r2d4)
#2 js_call_c_function → JS_CallInternal … → r2d_script_call_update → r2d__run_frame
```

Причина: `r2d_vfs_read()` для собранной игры возвращает указатель **внутрь буфера
груза** (владелец — груз, освобождать нельзя), а код звал `free()`. Второе место
того же класса — шрифты: после `engine.loadFont()` из груза **любой выход** движка
давал SIGABRT (`r2d_font_shutdown` освобождал указатель из груза), а повторная
загрузка шрифта с тем же именем падала сразу.

Исправлено: `src/real2d4.c` (`js_load`, 4 места) и `src/font.c` (загрузка,
перезагрузка, `r2d_font_shutdown`) — `free(...)` → `r2d_vfs_free(...)`: для
указателя из груза это no-op, для буфера с диска — `SDL_free`.

**Это НЕ регрессия дня.** `real2d4.c` приехал целиком коммитом `01e8e13`
(11 октября) — баг жил пять дней и был замаскирован тем, что демо спотыкалось
раньше («TypeError: not a function») и до `free` не доходило. В шрифтах то же
самое списывали на «иногда SIGABRT на выходе».

Числа: демо `demos/real2d` (57 МБ груза, 98 файлов) — было **3 падения из 3**
прогонов, стало **0 из 3**; шрифт из груза — выход с кодом **-6**, стал **0**.
Регрессия закреплена `tests/agent/real2d_payload_crash_test.py` (на старом коде
падает: 3 из 3; на новом проходит). Полный аудит владения указателями VFS —
в отчёте задачи: корректны все прочие потребители (`r2d_vfs_free`), звук берёт
груз через `MIX_LoadAudioNoCopy(..., free_when_done=false)`.

**Вероятная причина ранее наблюдавшегося однократного SIGABRT на выходе**
(внешний отчёт: один раз на ~500 прогонов, стек `main → SDL_Quit →
SDL_QuitFilesystem`): падало не «редко», а всякий раз, когда процесс доходил до
`r2d_font_shutdown`, а шрифт был загружен из груза — то есть зависело от того,
успел ли запуск дойти до выхода, а не от случайности. Контракт владения записан
в `src/payload.h` рядом с объявлением `r2d_vfs_read` и проверяется сторожем в
`tests/agent/real2d_payload_crash_test.py`.


### Не выпущено — долг по документации, часть 3: ядро, состояние, данные, input (task-29, 2026-10-16)

Закрыто **103 имени** из `tests/api_docs_allowlist.txt`, которые были исключены
«по долгу»: теперь у каждого есть документация с полным именем, а строки
исключений сняты. Гейт `tests/api_docs_sync_test.py` зелёный, «задокументировано
буквально» 1718 → 1846, долг allowlist 297 имён / 87 строк → 180 / 52 (остаток —
чужие задачи).

- Новые страницы: `docs/highlevel/console.md`, `docs/highlevel/test.md`,
  `docs/highlevel/processing.md`, `docs/highlevel/room.md`; дополнены
  `docs/highlevel/{input,store,save,state,scene,steps,time,timeline,signal,reload,pool,resource,prefab,debug,sdk}.md`.
- Каждое утверждение проверено запуском на живом движке (1.2.0), а не выведено
  из названия. Найденные расхождения доки/кода (подробности — в разделах):
  `$.scene.inScope` — не проверка владения, а запуск функции внутри области;
  `$.time.freezeLeft()` считает **миллисекунды** при секундах в остальном
  `$.time`; `$.time.cancelAll()` снимает только повторяющиеся таймеры;
  `$.time.timers()` — счётчики, а не список; `$.store.autoSave()` — не геттер,
  а запуск таймера (возвращает id); `$.input.waiters()` возвращает число, а
  `$.input.axisActions()` — карту; `$.prefab.clear()` возвращает строку и не
  встраивается в цепочку; `$.state.clear()` возвращает `$`, а не `$.state`;
  `$.room.remove()` возвращает `true` и для несуществующей комнаты;
  `$.signal.event()` нормализует `'#hero'` в `'hero'` (id без `#`).


### Не выпущено — долг по докам, часть 4: рендер-биндинги `engine.*` (task-30, 2026-10-16)

Закрыто **14 имён** из allowlist-долга: `engine.rotSpriteChanged/Dispose/FileStamp/Info/Pose/Rig/Style`,
`engine.depth`, `engine.lightMaskPasses`, `engine.markUnlit`, `engine.postSupported`,
`engine.spriteFilter`, `engine.setSpriteFilter`, `engine.cursorVisible`.

- Все они описаны в `docs/internal/NATIVE.md` (новый раздел «Рендер-биндинги, которые зовёт ТОЛЬКО наш
  JS-слой») — таблица «биндинг → что читает/пишет C → чем проверено».
- Каждое утверждение проверено вызовом на живом движке: `spriteFilter()` → `false`, после
  `setSpriteFilter('nearest')` → `true`; `depth(0.5)` → `true`; `lightMaskPasses()` → `0`;
  `postSupported()`/`cursorVisible()` → `true`; `rotSprite*` принимают **C-хендл** и на селектор
  отвечают `TypeError: RotSprite object expected`; `rotSpriteFileStamp(path)` на не-хендл → `null`.
- Причина `internal:` теперь с доказательством, а не «чтобы позеленело»: поиск вызовов показывает,
  что эти биндинги зовут только `src/highlevel/rotsprite.js`, `render.js`, `debug.js`, `input.js`,
  и ни одного вызова в `demos/`, `games/`, `game/`, `sdk/`.
- `tests/api_docs_allowlist.txt`: 14 строк `internal:` снято (было 24 → стало 10), долг `debt`
  в моей части (графика/UI/звук: `$.gfx`, `$.layers`, `$.screen`, `$.window`, `$.ui`, `$.tilemap`,
  `$.rotSprite`, `$.curve`, `$.easing`, `$.sound`, `$.audio`, `$.hits`, `$.atlas`, `$.physics` —
  ~64 имени) остаётся на следующий заход и назван в отчёте задачи.
- `python3 tests/api_docs_sync_test.py` → зелёный (2999 имён: документация или осознанное исключение).


### Не выпущено — долг документации: 119 имён пяти неймспейсов (task-26, 2026-10-16)

Публичная поверхность не менялась — только документация; заморозка API
(`tests/api_freeze_test.py`) держится на прежнем снимке.

- **Что было**: 119 имён жили в коде, но не упоминались в `docs/**` полным
  именем: `$.devtools` — 54, `$.alive` — 17, `$.weapons` — 16, `$.cutscene` —
  14, `$.camera` — 13 (плюс сами неймспейсы). Например, `$.camera.viewport` был
  описан как `viewport(w, h)`, а `$.weapons.clear` «находился» только как
  `clear` в чужом разделе.
- **Что сделано**: в `docs/highlevel/devtools.md`, `alive.md`, `weapons.md`,
  `cutscene.md`, `camera.md` добавлены таблицы поверхности с ПОЛНЫМИ именами и
  фактами, снятыми с живого движка: сигнатура, значения по умолчанию, возврат,
  единицы. Теперь все 199 имён этих пяти неймспейсов находятся в доке по
  полному имени (проверено сравнением снимка `tests/api_freeze_baseline.txt` с
  текстом `docs/**`).
- **Найденные расхождения доки и кода — исправлены в доке** (факты с живого
  движка, фикстура `tests/fixtures/hello`):
  * `$.camera.viewport()` не принимает аргументов и отдаёт прямоугольник МИРА
    (в старой таблице стояло `viewport(w, h)`);
  * `$.camera.panTo`, `$.camera.zoomTo`, `$.camera.rotateTo`, `$.camera.shake`
    считают время в **миллисекундах**, а не в секундах: `panTo(300, 0, 300)` на
    150-й мс даёт ровно 150 px, `zoomTo(2, 100)` доходит за ~100 мс,
    `shake()` по умолчанию — 4 px / 250 мс;
  * `$.weapons.combineStats` применяет добавки только к `pellets` и
    `penetration`: `add: { ammo: 10 }` и `add: { spread: -0.4 }` молча
    игнорируются (магазин остался 30);
  * `$.alive.director()` отдаёт `enabled`/`phase`/`time`/`hunts`/`knobs`/
    `assignments` **геттерами**, а не методами.
- **Остаток**: 0 имён без документации в этих неймспейсах; исключений в
  `tests/api_docs_allowlist.txt` не потребовалось — внутренние
  `$.camera._tick` и `$.camera._state` описаны в доке как внутренние, а не
  вынесены в исключения.
- **Найдено попутно**: в `docs/AGENT_API.md` и `docs/EXTERNAL_FEEDBACK.md` имя
  `$.camera.visibleRect` стоит в списке «чего НЕТ» — это не ошибка, но наивная
  проверка «имя встречается в `docs/**`» зачла бы такое упоминание как
  документацию. Владелец гейта (task-25/31) это учёл: гейт не считает строки с
  отрицанием, проверено подложенным примером.
- **Константы `$.alive` теперь и в заморозке**: `BREAK_STRESS = 0.72`,
  `PULSE_REST = 62`, `PULSE_MAX = 200`, `PULSE_TUNNEL = 140`, `TRAIT_NAMES`
  (14 имён) с этого дня входят в снимок `tests/api_freeze_baseline.txt` со
  значениями (снимок берёт публичные константы) — в `docs/highlevel/alive.md`
  §8.1 они описаны с теми же значениями, поэтому и гейт документации, и
  заморозка зелёные. Менять значения — только осознанно:
  `python3 tests/api_freeze_test.py --write` плюс строка здесь.


### Не выпущено — геймпады: навигация интерфейса, снимок состояния, сброс (task-24, 2026-10-16)

Появились два публичных имени — **`$.ui.gamepadNavigation(on|opts)`** и
**`$.input.padState(slot)`**; они описаны в `docs/highlevel/input.md` §2.1–2.4 и
в `docs/AGENT_API.md` (команда `pad`), снимок API обновлён осознанно.

- **Что было и осталось (не «сделано с нуля»)**: `$.input.gamepad(slot)` с
  `down/pressed/axis/connected/rumble`, привязки `gamepad.a`, мёртвая зона
  `$.input.deadzone()` (0.2), четыре слота, события `gamepadOn`/`gamepadOff` и
  агентская инъекция `pad`. Проверено на живом движке: фронт живёт один кадр,
  курки — оси 0..1, диагональ стика в `vec()` нормируется до длины 1, слоты
  независимы, `rumble` на неподключённом слоте возвращает `false`.
- **Навигация интерфейса геймпадом (главная дыра)**: `$.ui.gamepadNavigation(true)`
  — d-pad и левый стик ведут фокус с автоповтором, `A` подтверждает, `B`
  отменяет. Второго фокус-менеджера нет: геймпад превращается в те же
  синтетические клавиши, что читают экраны, диалоги и виджеты (направление идёт
  стрелкой там, где её читает контрол, и `Tab`/`Shift+Tab` в остальных случаях).
  Выключено по умолчанию — поведение существующих игр не менялось.
  **Ограничение:** документы RmlUi (DevTools, `.rml`) этим путём не ходят: они
  получают ввод событиями SDL, мост «геймпад → SDL-событие клавиши» не сделан.
- **Залипание кнопки при отключении**: дефекта нет — движок обнуляет кнопки,
  фронты и оси слота при отключении устройства, а `$.input` раз в кадр сбрасывает
  удержания у слота без устройства; `$.input.stuck()` в норме пуст,
  `$.input.resetHeld(slot)` доступен игре. Проверено тестом через `pad { reset }`
  (то же состояние, что при отключении).
- **Детерминированная проверяемость**: команда `pad` принимает имена SDL
  (`"a"`, `"dpup"`, `"lefttrigger"`) и `reset: true`, неизвестное имя — явный
  отказ; `$.input.padState(slot)` отдаёт снимок (`down`, `pressed`, `axes`,
  `connected`, `virtual`) — слот с инъекцией честно показывается как
  `virtual: true`, а не как подключённый.
- Тест: `tests/agent/gamepad_test.py`, 51 проверка.


### Не выпущено — SMAA: пост-антиалиасинг сцены (task-22, 2026-10-16)

Появилось публичное имя **`$.gfx.smaa(on|opts)`** (геттер `$.gfx.smaa()`),
поэтому запись здесь, в `docs/highlevel/render.md` §4.8 и в `docs/AGENT_API.md`
§3.3.4.

- SMAA (Jimenez et al., MIT у эталонной реализации; наш код — свой, LUT не
  вендорились) врезан в существующий пост-проход: тот же `post.frag.glsl`,
  собранный вторым вариантом `-DR2D_SMAA_MODE=1` (entry `smaa_frag`).
- **Выключено по умолчанию и побитово не меняет кадр.** Проверено дважды:
  SPIR-V/MSL варианта без SMAA совпадают с прежними байт-в-байт (`cmp`), а кадр
  теста на сборке с SMAA равен кадру прежней сборки по хешу пикселей
  (`3f983ce4…`, `tests/agent/smaa_test.py`).
- **Порядок проходов: сцена → SMAA → UI.** SMAA живёт в пост-проходе, который
  читает `scene_target` (мир и свет); интерфейс (`$.ui`, RmlUi) рисуется после
  поста, поэтому текст не мылится: контраст кромки глифа 0.803 → 0.803, число
  резких кромок в панели 8270 → 8241 (в пределах 0.4 %, панель полупрозрачная).
  Для сравнения: тонкий штрих **в сцене** получает 237 → 399 промежуточных
  пикселей — это и есть причина, по которой UI оставлен после AA.
- **Числа.** «Лестничные» пиксели на наклонной кромке (перепад яркости > 0.5 без
  промежуточного значения): **775 → 620**. Цена (профайлер, headless Metal,
  окно 120 кадров): GPU 0.78 → **1.12 мс** на 1280×720 и 0.92 → **1.18 мс** на
  1920×1080; draw CPU 0.038 → 0.040 и 0.024 → 0.044 мс соответственно.
- **Пиксель-арт**: `$.gfx.smaa({pixelArt: true})` выключает AA (шаги 0, кадр
  побитово равен кадру без AA) — AA противоречит целочисленному скейлу и
  пиксель-снапу, `reason` это объясняет.
- **Веб-сборка (WebGPU)**: SMAA-вариант собирается только из GLSL, поэтому
  `renderInfo().smaa_available` = false; `$.gfx.smaa(true)` не падает и
  возвращает причину.
- Пресеты качества `low`/`medium`/`high` = 2/4/8 шагов поиска паттерна.
  Включённый SMAA сам включает пост-проход (иначе у игры без других эффектов
  «включено» ничего не делало бы).
- Тест: `tests/agent/smaa_test.py`.


### Не выпущено — удалено из публичной поверхности: `$.net.host_` (2026-10-16)

Имя с хвостовым подчёркиванием возвращало внутреннюю переменную `host`
(адрес, который игра сама передала в `$.net.join`). Вызовов не было нигде по
дереву: ни в `src/`, ни в `tests/`, ни в `demos/`, ни в `tools/`, `sdk/`,
`site/`, `docs/`, `dist/`, `examples/`, `witch_game/` — единственное вхождение
было определением (`src/highlevel/net.js:673`). У клиента есть `join`, у
сервера — `port`, поэтому имя удалено, а не задокументировано.

Снимок публичного API обновлён осознанно (`--write`): **3000 → 2999 имён**.
Если какая-то игра всё же дёргала это имя, она получит `undefined` — публичным
оно не документировалось ни в одной версии. Проверки: `api_freeze` зелёный,
`tests/js/net_test.mjs` (40 проверок), `net_loopback_test`, `net_delay_test`,
`net_smooth_test` — зелёные.


### Не выпущено — долг по документации: `$.net`, `$.proc`, `$.replay` (task-27, 2026-10-16)

Из 612 имён долга эта часть — 86: `$.net` 45, `$.proc` 22, `$.replay` 19.
Сначала разведка (что это вообще такое), потом решения — не «описание по названию»:

- **`$.net`** — авторитарный сетевой слой (`src/highlevel/net.js`): сетевые id,
  стол владельцев, снапшоты с дельтой, ввод по номеру, предсказание клиента,
  лаг-компенсация, симуляция плохой сети. Транспорт подключается снаружи
  (`attach`) либо берётся у движка (`bindEngine`, SDL3_net). Это **2D-API**:
  проверено запуском в `tests/fixtures/hello` — `host`, `addPlayer`, `replicate`,
  `snapshotNow`, `deltaFrom`, `describe`, `bindEngine` работают.
- **`$.proc`** — процедурный пиксель-арт (`proc.js`): палитры-рампы, силуэт по
  частям тела, свет, контур, зеркало; рендер в RGBA-холст и спрайты движка.
  Проверено: `define` → `render` (16×24, 229 непрозрачных пикселей) → `sheet`
  (4 направления) → `toSprite`.
- **`$.replay`** — запись и воспроизведение ввода (`replay.js`): заголовок-паспорт
  прогона, ввод на уровне actions, проверки state hash с divergence-отчётом.

Что сделано: полные перечни имён с сигнатурами, параметрами по умолчанию,
возвратом и единицами — `docs/highlevel/net.md` §9.1, `proc.md` §3.1,
`replay.md` §1.1 (130 имён из 131). `$.net.host_` — единственное внутреннее
(нет вызовов ни в `src/`, ни в `tests/`, ни в `demos/`), вынесено в
`tests/api_docs_allowlist.txt` с причиной. Русских алиасов у этих трёх
неймспейсов нет: `$.сеть` — это алиас `$.http` (`src/highlevel/ru.js`).

Числа гейта `tests/api_docs_sync_test.py`: долг 708 → **99** (осталось чужое —
`$.ctx` 70, `$.math` 22, `$.fn` 7); имён `$.net`/`$.proc`/`$.replay` в долге
больше нет, мёртвых строк в allowlist нет.

Попутно найдено запуском (и исправлено в доках): `$.replay.record` в собранном
движке — это НЕ низкоуровневая запись кадра, а обёртка «из коробки»
(`record(sampler, apply)`; кадр ядром пишет `_push`); `$.proc.makeRandom(seed)`
возвращает объект-генератор `{next,int,range,pick,chance}`, а не функцию.


### Не выпущено — ХРТФ в 2D: бинауральный режим (task-18, 2026-10-16)

Запрос «хочу хртф в 2д». Режим `$.audio.hrtf(...)` для позиционных звуков —
**выключен по умолчанию**, включается игрой осознанно.

- **Два backend'а, оба названы честно** (`$.audio.hrtf().backend`): `'steam'` —
  настоящая HRTF (Steam Audio 4.8.1, он уже был в бинарнике, но 2D-слой его не
  использовал) и `'synthetic'` — встроенная модель без HRIR-датасетов (ITD
  дробной задержкой по Вудворту, ILD, ФНЧ-тень головы, полка «сзади»).
  `'auto'` берёт библиотеку, если она поднялась.
- **Гибрид ITD**: у Steam Audio своей межушной задержки нет — измерено
  кросс-корреляцией: лаг **0** при ILD 16.6 дБ (то есть библиотека фильтрует,
  но не задерживает). Поэтому при `itd:'auto'` задержку добавляет модель
  (лаг −29 сэмплов = **0.658 мс**), а спектр остаётся библиотечным; `itd:'off'`
  возвращает ровно библиотечный выход. Что звучит — видно в `itd_source`.
- **Числа** (живой выход, 44.1 кГц, захват post-mix): ITD на 90° — 0.658 мс
  (модель и гибрид), 0 мс при `itd:'off'`; ILD 4 кГц / 200 Гц — 10.1 / 0.13 дБ
  (модель) и 10.4 / 0.11 дБ (HRTF); тень выше 4 кГц — −15.6 / −21.0 дБ;
  фронт/тыл по лог-спектральному расстоянию (LSD, 24 полосы 300 Гц–8 кГц) —
  **1.65 дБ** (модель) и **3.41 дБ** (HRTF) — прежняя метрика HF/LF оказалась
  слепой (2.05 / 0.39 дБ).
- **Диагностика для тестов**: `$.audio.captureStart(N)` + `$.audio.captured()`
  снимают итоговый микс (post-mix, после шин и реверба) — метрики выше получены
  измерением буфера, а не доверием коду.
- **Выключено = как раньше**: бинауральный путь не исполняется вовсе, инварианты
  панорамы совпадают до/после включения, bypass подтверждён C-тестом
  `tests/audio/spatial_test.c`. Побитовое сравнение двух прогонов микшера
  критерием не является (поток идёт в своём темпе) — это записано в доке,
  чтобы следующий человек не искал «побитовость» в аудио.
- **Побочно исправлено**: `r2d_audio_spatial_test` компилировался без
  `-DR2D_STEAM_AUDIO`, поэтому проверял фолбэк-панораму, а три проверки
  (инициализация HRTF, фронт/тыл, высота) падали «не по делу»: теперь 9/9.
- **Ограничение**: высоты в 2D-режиме нет (только азимут и дистанция) — сказано
  в доке прямым текстом; сторонние HRIR-датасеты (SADIE/KEMAR/CIPIC) не
  добавлялись.


### Не выпущено — отчёт внешней команды BASHNYA: A/B/C закрыты (2026-10-16)

Отчёт переноса уровня на 0.1.34 (`docs/EXTERNAL_FEEDBACK.md`,
текст сохранён как цитата, решения — в конце файла). Раздел A — восемь дефектов
поведения, все исправлены с тестами, падающими на старом коде:

- **A1** `.x`/`.y` обёртки узла: чтение давало `undefined`, присваивание молча
  вешало JS-поле и узел не двигался (у команды из-за этого «исчез» меч — позиция
  стала `NaN`). Теперь это аксессоры: чтение числом, запись двигает узел и тело
  физики; мусор позицию не меняет и называет причину; неизвестное свойство не
  создаётся молча.
- **A2** импорт модулей: относительный путь резолвится от файла-источника, `..`
  нормализуется, подъём выше каталога игры разрешён, пока файл существует; явные
  коды `R2D_MODULE_OUTSIDE_GAME` и `R2D_MODULE_ABSOLUTE_PATH`. Раньше импорт вверх
  молча грузил **двойника** внутри каталога игры.
- **A3** `areaOverlap()` фильтровал в две стороны — цель с чужой маской для
  области не существовала. Решает только маска запроса (как у `raycast`/`query*`),
  прежний режим — `{both: true}`.
- **A4** `.frame(i)` писал спрайт, но не `frame_index` — поле врало.
- **A5** запись файлов проваливалась молча: теперь одна строка с путём и причиной
  (`errno`) плюс `R2D_FS_WRITE_FAILED` в `$.debug.errors()`, успешная запись молчит.
- **A6** узел без компонента здоровья больше не выглядит мёртвым (`alive: null`).
- **A7** предупреждение «неизвестный тег» писалось на каждый узел: 125 строк → 3 на
  масштабе отчёта.
- **A8** `state.entities` раздувал снимок: `entities:{limit,sel,fields}` —
  125.7 КБ / 3.8 мс → 2.2 КБ / 0.5 мс на 774 узлах, полный снимок без параметра
  остаётся полным.

Раздел B (док расходился с бинарником) и C (лимиты) закрыты: доки приведены к
фактам живого движка, а из «мелочей» исправлено то, что было дефектами:

- **шум игнорировал `--seed`** (собственный дефолт 0): игра выглядела
  детерминированной, но смена зерна не меняла мир. Теперь шум берёт зерно сессии,
  явно переданное побеждает;
- **`$.random.stream(name, {independent: true})`** — поток, который не сдвигает
  чужой `seed(n)`;
- **звуковых каналов 16 → 128** (замер: +12.2 КБ статической памяти, CPU только за
  звучащие голоса — 17.9 % ядра на 128 при полной загрузке, время кадра не
  меняется), `$.sound.channels()` отдаёт фактический предел;
- **`$.hits.pool(n)`** — размер кольца эмиттеров искр настраивается (1..64) вместо
  жёстких 8, где девятый одновременный удар обрывал первый залп;
- **`$.fs.remove()`** различает «файла нет» (тишина, идемпотентность) и настоящий
  отказ (`R2D_FS_REMOVE_FAILED` с путём и причиной).

### ХРТФ в 2D и новые имена в API

- `$.audio.hrtf(...)` — бинауральный режим: **настоящая HRTF** (Steam Audio, уже
  вендорен и собран — к 2D-слою подключён впервые) либо встроенная модель
  (ITD, ILD, тень головы, подсказка «сзади») как фолбэк. По умолчанию выключено;
  геттер всегда называет фактический бэкенд и причину отказа. Измерено на живом
  выходе: модель — ITD 0.658 мс на +90°, ILD 10.11 дБ на 4 кГц против 0.13 дБ на
  200 Гц, тень −15.58 дБ; HRTF — ILD 10.34/0.24 дБ, тень −20.54 дБ, но своей
  межушной задержки не имеет (в steam-режиме ITD добавляет модель — это указано
  в геттере). Высоты в 2D нет ни в одном бэкенде.
- `$.audio.captureStart/captured/captureClear` — захват post-mix для проверок.
- `$.sound.channels()` — фактический предел каналов (16 → **128**).
- `$.hits.pool(n)` — размер кольца эмиттеров искр (1..64) вместо жёстких 8.
- Заморозка API обновлена: `tests/api_freeze_baseline.txt` (3000+ имён).

Заморозка API обновлена осознанно: новые публичные имена `$.sound.channels`,
`$.hits.pool`, `ctx.defineTag` внесены в снимок `tests/api_freeze_baseline.txt`
(`--write`); переименований, смен сигнатур и схем нет.

### Не выпущено — эталонное меню настроек: демо и туториал (2026-10-16)

Ответ на вопрос «можно ли на нашем движке сделать полноценное меню настроек» —
рабочий образец, а не обещание: `demos/settings` (четыре вкладки: графика, звук,
управление, язык) и публичный `docs/tutorial-settings.md` с кодом и числами.

- Всё применяется **на лету**: полный экран и разрешение (`$.window.displayModes()`
  + `fullscreen({mode,width,height,refresh})`), масштаб `$.ui.scale()`, SMAA
  `$.gfx.smaa()`, громкости `$.sound.volume/sfxVolume/musicVolume/mute`, язык
  `$.i18n.lang()` — без перезапуска игры.
- Сохранение через `$.store` в отдельный `settings.json` (718 Б на 15 значений),
  настройки переживают перезапуск движка (проверено автотестом), сброс возвращает
  дефолты; запись отложенная — `$.time.after(250)`, потому что `setTimeout` в
  QuickJS нет.
- Переназначение клавиш — штатным `$.input.waitForInput()` (отдельный
  `$.input.capture` не понадобился), конфликты — `$.input.conflicts()`, сброс
  к эталону — `markDefaults()`/`resetDefaults()`.
- Интерфейс — документ RmlUi (`demos/settings/settings.rml` + `.rcss`), как требует
  закон UI; кольцо выбора ведёт JS и обслуживает клавиатуру, геймпад и мышь одним
  кодом. Честное ограничение записано в туториале: `$.ui.gamepadNavigation` ведёт
  слой `$`-виджетов, но не документы RmlUi — геймпад в образце работает через
  привязки контекста ввода и чтение стика.
- Числа: открытие экрана 10.5 мс (повторные hide/show — 23 мкс), зона
  «интерфейс (RmlUi)» 0.080 мс с открытым меню против 0.023 мс с закрытым
  (≈ 0.06 мс на кадр, 0.35 % бюджета 60 FPS), применение настройки от 0.3 мкс
  (привязка клавиши) до 1.76 мс (полный экран), смена языка 0.28 мс, сброс 0.61 мс,
  запись файла 0.36 мс. Разметки 360 строк (170 RML + 190 RCSS), логики 757 строк JS.
- Проверка: `tests/agent/settings_menu_test.py` — открытие, изменение каждой
  настройки (числа до/после в API подсистем), сохранение через перезапуск,
  сброс, навигация клавиатурой/геймпадом/мышью, захват клавиши.


### Не выпущено — 1.2.1

### Фуллскрин: честный отчёт и починенный хоткей

Обе правки выросли из находок проверяющего на финальной связке 1.2.0.

1. **`--headless` больше не рапортует успех, которого нет.** Раньше
   `fullscreen({mode:'exclusive'})` при скрытом окне возвращал `{ok:true}`, а
   drawable не менялся (1280×720 → 1280×720), при этом `state()` сообщал
   `fullscreen_mode:'exclusive'`. Теперь движок после входа в эксклюзив сверяет
   ФАКТИЧЕСКИЙ drawable с выбранным режимом и при несовпадении откатывает всё
   (снимает фуллскрин и режим дисплея, возвращает сохранённую геометрию) и
   возвращает `false` с текстом вида: `режим 1920x1080 не применён: окно скрыто
   (headless), drawable 1280x720`. `state().fullscreen_mode` остаётся `windowed`.
   Отказ — это вариант (б): скрытое окно на macOS эксклюзив применяет ПО-НАСТОЯЩЕМУ,
   и глухой отказ был бы враньём в другую сторону; на X11-поде CI тот же вызов
   drawable не меняет — там сработает отказ.
2. **`state()` получил `drawable_changed` и `last_mode_error`.** `drawable_changed`
   вычисляется ЛЕНИВО: SDL применяет смену режима не в том же вызове, и
   синхронное сравнение врало `false` при изменившемся drawable. Уточнение: у
   режима `desktop` разрешение не меняется по определению, поэтому
   `drawable_changed:false` там — норма, правило касается эксклюзива.
3. **F11 больше не отключается навсегда после первой смены режима.** Настоящая
   причина (не «транзиент», как мы думали): снимок состояния `last` обнулялся в
   `$.window.fullscreen()` («состояние прочитаем заново»), а `tickWindow()` начинался
   с `if (!last) return` — то есть после первой же смены режима опрос хоткея
   умирал (`frames` замирал на 10), и клавиша не читалась вовсе. Исправлено: опрос
   идёт первым и без гейта по снимку; выдержка 6 кадров после любой смены режима
   (нажатие копится в защёлке); до 2 повторов, если режим не сменился (одно
   нажатие = один `toggles`); защёлка снимается при отпускании, иначе одно нажатие
   могло сработать дважды; `toggleFullscreen()` и `fullscreen(true|false)` идут
   через общий учёт.

Числа: чистое окно — нажатие обработано за 5 кадров (`toggles 0→1`,
`windowed→desktop`); сразу после 5 циклов `desktop↔exclusive↔windowed` — за 6
кадров; три нажатия подряд — три переключения с чередованием режимов;
`hotkey(false)` — режим и `toggles` не меняются; `frames` растёт непрерывно
(150 против замерших 10 до правки). Тест `window_fullscreen_test`:
38 ok / 2 fail → **40 ok / 0 fail**, формулировка «ограничение среды» заменена
фактом. Не воспроизводится локально только ветка ОТКАЗА (на macOS с дисплеем
эксклюзив применяется даже скрытым окном) — она покрыта кодом и инвариантом теста
(«либо отказ без смены режима, либо успех с `drawable_changed:true`») и сработает
на X11-поде CI.
## Не выпущено — заморозка API и хвосты оверлеев (2026-10-16)

- **§63: публичный API заморожен машинно.** `tests/api_freeze_test.py` снимает
  публичную поверхность с живого движка (имена неймспейсов `$.` с их методами и
  биндинги `engine.*` — 2986 имён) и сверяет со снимком
  `tests/api_freeze_baseline.txt`. Появление или исчезновение имени валит гейт;
  намеренное изменение — только осознанным обновлением снимка (`--write`) с
  объяснением в этом файле. Гейт стоит в статическом шаге CI.
- **§66 закрыт целиком: 82 пункта из 82** — у каждого закрытого пункта названо
  доказательство (файл теста или job CI), молчаливых и «закрытых на словах» нет;
  форму проверяет `tests/production_polish_checklist_test.py`.
- **Хвосты оверлеев:** у исчезнувшего узла `$.anim.debug` отдаёт `sel: null`, а не
  строку-заглушку; лог `$.tilemap.debug` при отсутствии карты называет причину
  (`reason: no_map`) вместо общего «ничего не рисует».


## Не выпущено — PASS 5 и правки по находкам команды (2026-10-16)

- **Время (§50).** Разведены четыре шкалы: gameplay/simulation/presentation/real.
  `scale()` зажат в `[0, 100]`, иначе `scale(Infinity)` уходил в шаг физики и
  давал NaN в позициях тел. `presentationDelta()/presentationTime()` идут при
  `scale(0)`, паузе и hit-stop — интерфейс остаётся живым. Частицы с
  `clock:'simulation'` больше не летят на сыром `dt`: стоят при остановленном
  времени.
- **Камера и вьюпорты (§49, §40).** Мусорные значения больше не утекают в кадр:
  `zoom(NaN)`, `at(NaN)`, `shake(NaN)`, `limits(NaN)`, `panTo(NaN)`, `offset`,
  `restore`, зоны; `smooth` зажат в `[0,1]` (было: `smooth=2` уводил камеру на
  76 500 px). `$.camera.add('p2')` без региона больше не роняет каждый кадр, а
  показывает весь кадр.
- **Ресурсы (§40.1).** Освободившиеся слоты таблицы спрайтов переиспользуются:
  100 циклов `$.viewport.create/destroy` больше не добавляют 100 строк.
- **Аудио (§47).** `priority`/`pitch`/`keep` доезжают до канала через
  `$.audio.play`; `$.audio.clear()` освобождает группы микшера; звук принадлежит
  ТЕКУЩЕЙ области сцены, а не анонимной, — выгрузка комнаты глушит её звук.
- **Атласы (§45).** Кэш сборок: 100 циклов `unload → load` дают 9 → 9 спрайтов
  вместо 9 → 209. `unload(name, { drop: true })`, `$.atlas.builds()`, коды
  `atlas_frame_invalid`, `atlas_duplicate_frame`, `atlas_duplicate_tag`.
- **Материалы (§43).** Два расхождения исправлены: материал узла вообще не
  доходил до отрисовки (нативный быстрый проход не знал про `attrs.material`), а
  `lit` у материала ПО ИМЕНИ молча терялся. `tint`, `lit`, `emissive` теперь
  работают одинаково на обоих путях, тесты сравнивают кадры хешами.
- **Перезапуск скриптов (§46).** Точка входа компилируется ДО уничтожения
  рантайма: при синтаксической ошибке игра больше не теряет старый код и
  глобалы, а сообщение «продолжаю со старым рантаймом» стало правдой.
  `$.reload.behavior` дополнительно проверяет `main.js` до запроса
  (`R2D_RELOAD_SYNTAX`).
- **Профайлер (§17.2, §18).** `engine.profile()` отдаёт историю кадра и
  перцентили, добавлен hitch-детектор с контекстом кадра и причиной.
- **DevTools.** Вкладки, сводка PERF, график кадра, hitch-капчуры, ENTITY 2.0 и
  world picking; данные для физики/рендера/света отдаёт `engine.devtools.*`.
- **Контракты.** `$.attr('friction'|'density'|'restitution')` после создания тела
  больше не молчит (отложенная диагностика `R2D_ATTR_AFTER_BODY`), односторонняя
  платформа не считается опорой при проходе сквозь неё, площадной свет уважает
  `.lightLayer()`, `limits().user_shaders_max` перестал обещать лишний слот.
- **Проверяемость.** §66 получил машинный гейт: у закрытого пункта обязано быть
  доказательство, у незакрытого — причина. 64 пункта закрыты, 18 — с причиной.


## Не выпущено — PASS 3/4 начаты: профайлер, бэкенд инспекторов, сейв анимации (2026-10-16)

- **Профайлер (§17.2, §18).** `engine.profile()` отдаёт `history` (времена кадров
  окна, старые → новые) и `stats` (current/min/mean/p50/p95/p99/max/count) из
  того же кольца, что и средние: второго профайлера нет. Добавлен hitch-детектор:
  кольцо захватов с контекстом 2+1+2 кадра, причина — самая дорогая зона спайка,
  настраиваемый порог, подавление «эха» одного спайка. Живой движок, тесты
  `devtools_hitch_test.py` (36 проверок) и дополненный `debug_diagnostics_test.py`.
- **Бэкенд инспекторов (§19, §25, §37).** `engine.devtools.shapes(body)` отдаёт
  геометрию форм из Box2D (тип определяется по контуру — v3 не хранит «box»),
  фильтры, `sensor`/`enabled`/`one-way`; `renderInfo()` получил честные
  `batches`, `draw_calls`, `targets`, `textures{count,max,pixels}`,
  `viewport{w,h,snap,bound}`; `engine.devtools.lights()` перечисляет ровно
  нарисованные в кадре источники. Выдуманных полей нет: `bytes_estimate`,
  `atlases` и `viewport.scale` не добавлены, потому что их нечем измерить.
- **Площадной свет и слои (§37, баг).** У `<lightarea>` слой был захардкожен
  единицей, поэтому `.lightLayer(bits)` при включённой карте света молча не
  действовал. Исправлено; тест `light_area_layer_test.py` проверяет в обе
  стороны и падает на старом коде.
- **Сейв: анимация и сцена (§10).** Состояние проигрывателя сохраняется
  провайдером `anim.player` по стабильному `nid` (клип, время, скорость, loop,
  окна удара, маркеры), откат возвращает прежнюю цель. `data.scene` наконец
  читается: `$.scene.adopt()` / `$.room.adopt()` восстанавливают идентичность
  без повторного builder'а (иначе появился бы второй мир), а расхождение
  называется кодами `R2D_SAVE_SCENE_*`. Тесты `highlevel_save_anim_test.py`,
  `highlevel_save_scene_test.py`; `docs/highlevel/world.md` §6.
- **Контракты (§6.6, §52, §23).** Смена `friction`/`density`/`restitution` после
  создания тела больше не молчит — запись `R2D_ATTR_AFTER_BODY` в диагностике.
  Односторонняя платформа не считается опорой при проходе сквозь неё (прыжок
  снова воздушный). Добавлены lifetime stress (100 циклов по широкому списку
  ресурсов) и продюсеры журнала событий для звука и ввода.

## Не выпущено — Linux-приёмка зелёная, пайплайны трёх хостингов, чистка репозитория (2026-10-16)

- **P0: use-after-free в грузе.** Зашифрованная standalone-сборка
  (`r2d-sdk build --encrypt`) падала SIGSEGV сразу на старте на Linux: поля
  футера (nonce/tag/ключ/aad) читались уже после `SDL_free(bytes)`, а `footer`
  указывает внутрь этого буфера. На macOS и Windows освобождённая память
  остаётся отображённой, поэтому баг не проявлялся. Теперь поля копируются до
  освобождения. Регрессия — `tests/agent/build_test.py` (он запускает
  зашифрованную сборку).
- **Linux SDK GUI regressions — шаг зелёный.** Причина была двойная: (1) mesa
  25.2.8 (lavapipe) падает SIGSEGV внутри `vkCreateGraphicsPipelines`, если её
  дисковый кэш шейдеров уже прогрет предыдущим запуском движка в том же job —
  каждый тест теперь идёт со своим пустым `MESA_SHADER_CACHE_DIR`;
  (2) `screenshot` отвечал `ok:true`, не сохраняя файл (у скрытого окна на
  Vulkan SDL отдаёт NULL swapchain) — теперь причина называется, а запрос
  снимка в сессии SDK помечен `optional` и его отказ не валит сессию, но виден
  в диагностике. Снимок из распакованного пакета проверяется с видимым окном
  (в CI это Xvfb).
- **Пайплайны Mos.Hub и GitVerse.** `.gitlab-ci.yml` (GitLab CI, раннер
  `appsechub`) и `.gitverse/workflows/build.yaml` собирают Linux x86_64 и
  Windows x86_64 (кросс-сборка MinGW), гоняют тесты и создают релиз по тегу
  `vX.Y.Z`; macOS они не собирают, а забирают архивы нужной версии из витрины
  `dist/`. Для GitVerse нужен секрет `GITVERSE_API_KEY`.
- **Витрина `dist/`.** Удалены старые сборки пяти платформ (470 МБ): остались
  только свежие macOS-пакеты arm64 и x86_64 с версией в имени. Linux и Windows
  попадают туда после релиза — `tools/fetch_release_assets.py`.
- **Репозиторий почищен.** Из git убраны `site/` (сайт публикуется отдельно и
  содержит доступы), локальные `build_and_push.sh`/`push_and_deploy.sh`,
  каталоги «к удалению/» и «отклонено/», а также `saves/` — артефакты тестовых
  прогонов. Файлы остаются на диске, правила — в `.gitignore`;
  `tests/release_ownership_test.py` проверяет и отсутствие в git, и политику
  локальных скриптов.

## Не выпущено — дополировка PASS 1: переносимость, владение сборками, релиз (2026-10-16)

План — `docs/PRODUCTION_POLISH.md`. Закрыт PASS 1 (§4) и добавлены машинные
гейты к нему; сам PASS 1 закрывается зелёным CI на Windows/Linux.

- **§4.1–4.3. Три причины красной Windows-сборки** (подтверждены логом
  workflow: `error C2065: 'M_PI'`, `LNK2019: unresolved external symbol
  strtok_r`, `error C2057/C2133` на runtime-sized массиве):
  - своя константа `R2D_PI`/`R2D_TAU` в `src/r2d.h` вместо libc-`M_PI`
    (`src/nodes.c`, `tests/audio/fx_test.c`);
  - разбор тегов атласа — локальным `sdk_next_field` вместо POSIX `strtok_r`
    (`sdk/native/sdk_atlas.c`); глобальный `strtok` убран и из генератора
    встраивания (`tools/r2d_embed_js.c`);
  - шумовая текстура рендера — константа времени компиляции вместо VLA
    (`src/render.c`).
  Проверка — `tests/portability_test.py`; все 144 единицы трансляции
  собираются с `-Wvla -Werror=vla`.
- **§4.5–4.9. Владение сборками.** macOS убран из матрицы GitHub Actions:
  Windows x86_64 и Linux x86_64/aarch64 собирает CI, он же считает
  `SHA256SUMS.txt` и создаёт **единственный** GitHub Release по тегу.
  Локальные `build_and_push.sh`/`push_and_deploy.sh` собирают только macOS
  (не-macOS платформа в `PLATFORMS` — ошибка, а не сборка «на всякий случай»)
  и релизы не создают. macOS-архивы прикладывает к релизу CI
  `tools/attach_macos_release.py`, а витрину `dist/` наполняют артефактами CI
  через `tools/fetch_release_assets.py`. Проверки —
  `tests/release_ownership_test.py`.
- **§4.9/§58. Контракт имени артефакта.** `release.archive_name()` — один
  источник имени `russiano2d-v<версия>-<платформа>.<ext>`; архивов без версии
  в каталоге релиза больше не остаётся (`release.prune_stale_archives`),
  `tools/ci_package.py` падает при расхождении с контрактом.
- **§57. Воспроизводимость.** Шаг обновления документов пакета пересобирает
  архив тем же кодом, что и релиз (`release.write_archive`), а не
  `shutil.make_archive`: повторное обновление даёт байт-в-байт тот же архив
  (проверка в `tests/package_docs_refresh_test.py`).
- **§4.5. Пакетный smoke macOS.** `tests/macos_package_smoke_test.py`
  распаковывает архив из `dist/` и проверяет `VERSION`, контрольные суммы
  пакета, `russiano2d --version`, `r2d-sdk version` и headless-прогон 30
  кадров; `macos-x86_64` запускается через Rosetta, без неё — честный пропуск.
- **Static-гейты в CI.** Перед сборкой платформ идёт одна джоба: доки,
  переносимость, контракт упаковки, владение релизом и сверка тега с версией
  проекта. Заодно починен подсчёт сумм: `sha256sum *` захватывал сам файл
  манифеста, и в релиз попадала строка с хешем пустого `SHA256SUMS.txt`.
- **Починка локального выпуска.** `push_and_deploy.sh` ссылался на
  несуществующий `tests/demos_examples_test.py` (файл лежит в `tests/agent/`)
  и падал на этом шаге до сборки; добавлены гейты переносимости и владения.
- Документация приведена к новому разделению ответственности:
  `docs/RELEASING.md`, `docs/BUILD.md`, `docs/TASKS.md`, `site/doc-home.md`;
  исторические записи о прежней матрице помечены в `SDK_HANDOFF.md`.

## Не выпущено — производственная готовность: презентация, свет/материалы, атласы (§18, §20, §22)

- **§29. Панели проверки студий.** Девять инструментов получили кнопку
  «Проверить» и «Проверить в игре» на общем помощнике `sdk/lib/panel_check.js`:
  панель вызывает тот же нативный `r2d-sdk validate`, что CLI, и показывает его
  структурные диагностики (коды панели совпадают с CLI на том же файле — новый
  `tests/agent/sdk_tools_panels_test.py`, 126 проверок). Preview — ссылка на тот
  же путь, что проверялся (`previewMatchesValidated`), без базы проекта. У каждой
  панели появился import report/сводка (кадры/trim/sockets/страницы для Sprite,
  диапазоны и прерывание для Animation, слои/occlusion/chunk budget/комнаты для
  Tilemap, space/clock/trails/бюджет/seed для Particle, роли/masks/one-way/
  footprint для Collision, маршруты/stems/voice/missing для Audio, контексты и
  конфликты для Input, элементы/фокус/ссылки/переполнение перевода для RmlUi,
  lifecycle/фикстуры для DevTools, задания манифеста для Automation).
  Undo/redo документа сохраняется после проверки. Починен краш Tilemap Studio на
  файле без слоёв: пустой `data` больше не роняет `$.update`.

- **§18. Контракт презентации.** Порядок проходов зафиксирован таблицей и
  эталонными сценами (alpha/add/multiply, Y-sort, UI поверх света, параллакс,
  resize, освобождённый render target). Добавлены презентационные
  `$.gfx.snap(true)` (вершины осевых спрайтов по целым пикселям) и
  `$.gfx.integerScale(true)` (зум кадра мира к целому) — логика, тела и пикинг
  не квантуются. Смена слоя/глубины меняет только картинку: проверено тестом на
  позиции тела, числе тел и raycast.
- **§20. Свет, лимиты и материалы.** Профиль качества
  `$.gfx.light.quality({ maxShadowLights, maxRays, maxSegments })` с
  документированной деградацией (источник без тени вместо потери света, урезание
  лучей и отрезков), `qualityReport()` и расширенные `stats()`. Маски
  препятствий (`occluderMask` + `mask` у отрезка), динамический occluder из
  узлов со своими `.occluders([...])`, инвалидация теней по затронутой области
  (правка рядом с одним источником не пересчитывает остальные; индекс
  дополняется без пересбора). Узлы `.lit(false)` вне мирового света и темноты.
  Материалы спрайтов: `$.gfx.material(...)` / `.material(...)` с albedo, normal
  (данные, `normalConvention`), emissive, tint, lit и `response`; нейтральная
  норма `flatNormal()`. Попиксельное освещение по normal-карте закрыто
  ОБЪЯВЛЕННЫМ fallback (§20.2): данные материала полные, но спрайтовая
  фрагментная стадия имеет один сэмплер, а вершинная не несёт ни нормали, ни
  мировой позиции (измерение — `docs/highlevel/render.md` §4.7.1: 32 источника в
  стресс-сцене, до 29 млн вычислений «источник↔пиксель» за кадр для варианта со
  вторым сэмплером). Контракт проверяем машиной: `$.gfx.normalPath()` отдаёт
  `{ supported: false, reason, fallback: 'flat_normal', required }`,
  `$.gfx.perPixelNormal()` всегда `false`, а `$.gfx.perPixelNormal(true)` не
  включает режим, а возвращает `false` и сообщает причину одной строкой. Приёмка
  §20.2 — изображениями и числами в `tests/agent/node_normal_map_test.py`
  (свет слева/справа, материал с normal-картой = базовый пиксель в пиксель,
  flip/поворот при той же позиции не меняют освещённость, trimmed атлас не
  смещает свет, тень следует за движущимся occluder).
- **§20.1. Маска получателя света и слои источников.** Узел объявляет, свет
  каких слоёв принимает (`.lightMask(bits)`, по умолчанию `0xFFFFFFFF` — все
  слои, прежнее поведение), источник — свой слой (`.lightLayer(bits)`,
  `lightLayer` при создании, слой по умолчанию — `$.gfx.light.layer(bits)`).
  Гейт применяется при накоплении света: перед ним идёт проход маски в цель
  половинного разрешения (RGBA8 = 32 бита, очистка в «все слои»), а пакеты света
  рвутся по смене слоя. Без масок в кадре прохода, цели и выборки в шейдере нет
  — цена и картинка прежние (p95 8.35 → 8.34 мс на `demos/stress --scene lights`;
  с масками у 120 спрайтов — 8.36 мс). Вариант «N композитов по слоям» измерен и
  отвергнут: 0,030 мс GPU за композит × N и N текстур, но маска получателя нужна
  и ему. `$.gfx.light.maskPath()` объявляет путь и fallback (`all_receivers`,
  когда свет идёт прямо в сцену). Заодно исправлен дефект: при включённой
  световой карте `.lit(false)` получал свет поверх себя (255 вместо 169,3) —
  композит теперь выполняется до неосвещённого слоя. Приёмка —
  `tests/agent/light_receiver_mask_test.py` (22 проверки) и фикстура
  `tests/fixtures/light_mask`.
- **§22. Атласы.** Страницы (`meta.pages`, `sheet.pages()/page()`), политика
  padding/extrusion (мипмапы включаются только при запасе — иначе кадр
  «протекает» на соседа), import-манифест (`meta.import`: version, importer,
  contentHash, settings, dependencies) и `$.atlas.manifest()`. Повёрнутый кадр
  отклоняет атлас целиком с кодом `atlas_rotated_frame` (явное
  `allowRotated: true` — для необязательных ассетов). Ошибки стали
  структурированными: `$.atlas.verify()` (кадры, страницы, padding, теги,
  манифест), кольцо `$.atlas.errors()` и запись в `$.debug.reportError`.
  Пути страниц разрешаются относительно JSON атласа.

## Не выпущено — программа производственной готовности: трансформы, площади, дорожки, тайлы, шум (2026-10-15)

К движку приложена инженерная спецификация
[docs/PRODUCTION_READINESS.md](docs/PRODUCTION_READINESS.md) (версия 1.1) и
рабочий план `docs/PRODUCTION_PLAN.md`. Ниже — что
закрыто по ней в этой ревизии; остальное перечислено в плане как очередь.

- **§30. Packaging, export и CI.** Версия — одна на проект: `r2d-sdk version`
  берёт `PROJECT_VERSION` из `CMakeLists.txt` (определение вместо строки в
  `sdk.h`), оболочка SDK показывает ответ бэкенда; `VERSION` лежит в пакете,
  тег проверяется против той же строки. Повторная упаковка того же дерева даёт
  побайтно тот же архив: `release.py` пишет `tar.gz`/`zip` сам (фиксированное
  время, сортировка, `uid`/`gid` = 0). `ci_verify.py` подтверждает
  конфигурацию по `CMakeCache.txt`, наличие/отсутствие объектов 3D-слоя,
  `demos/` рядом с бинарником и цели в `build.ninja`; в OFF-сборке всё это
  обязано отсутствовать, в ON — присутствовать (`--config-only` для быстрой
  проверки). Web-экспорт без emsdk честно пропускается с причиной. Пакет
  проверяется тестом на состав (лицензии, docs, `game/`, `assets/`, `VERSION`,
  SHA256SUMS) и на отсутствие `demos/`, `save.json`, кэшей и исходников
  backend; standalone-игра собирается одной командой и проходит агентский
  smoke.

- **§23. Tilemaps, комнаты и prefab data.** Появился `$.room`: комната — открытые
  данные (`bounds`, карта, инстансы prefab, маркеры, `exits`/`connections`), а не
  второе дерево узлов. Загрузка/перезагрузка комнаты — **транзакция** поверх
  `$.scene.prepare/commit`: сборка идёт в области владения §5 и публикуется
  целиком, поэтому неудачная загрузка не меняет мир (узлы/тела/подписки до и
  после совпадают), а `$.scene.current()` = `room:<id>` — это же значение хранит
  §14, так что ID комнаты переживает save/restore (`$.room.adopt()` возвращает
  комнату по её узлу карты после восстановления мира). Идентификаторы инстансов
  и детей — из данных (`door_north`, `door_north/lamp`), повторная сборка даёт те
  же логические id; дубликат — ошибка данных. Ссылка на отсутствующий маркер,
  выход или комнату — структурированная ошибка `R2D_ROOM_*` в
  `$.debug.reportError`, а не молчаливый переход. Карта комнаты строится из
  одних данных для визуала, коллизии и occluders, а правка одной клетки теперь
  пересобирает только затронутые тела: `$.tilemap.resultOf()` отдаёт `dirty_cells`,
  `created`, `reused`, `destroyed`, `rebuilt` (раньше любая правка снимала и
  создавала ВСЕ тела карты), и правка попадает в данные узла, поэтому входит в
  снимок §14. Найдено и закрыто: инстансы prefab не принадлежали области
  владения (смена комнаты оставляла их в мире) — комната объявляет владение
  явно. Тесты: `tests/agent/room_transaction_test.py`, фикстура
  `tests/fixtures/room_tx`; расширены `tests/js/tilemap_test.mjs` и
  `docs/highlevel/{tilemap,scene,prefab}.md`.
- **§27. Хот-релоад ассетов.** Подсистема `$.reload` (src/highlevel/reload.js):
  граф зависимостей (`watch(name, { deps })`, `order()`, цикл — ошибка), версии
  ассета (`version/versions/value`) и конвейер `read → validate → prepare →
  apply`: новая версия сначала читается и проверяется, публикует только apply, а
  неудачная замена оставляет работать прежнюю (last-known-good) и возвращает
  `{ ok:false, stage, code }` с кодами `R2D_RELOAD_*` в
  `$.debug.reportError`. Встроенные виды: `texture` (перезагрузка пикселей
  **на месте** — `engine.reloadTexture`, handle не меняется), `atlas` (та же
  раскладка — ни одного нового спрайта; изменённая — перепривязка кадров по
  имени, пропавший используемый кадр — отказ `R2D_RELOAD_FRAME_MISSING`),
  `tilemap` (клетки; визуал, коллизия и occluders пересобираются одним
  проходом), `rml` (проверка разметки до подмены; внешний `.rcss` RmlUi
  кэширует по URL — предупреждение `R2D_RELOAD_STYLE_CACHED`), `json`. Старые
  texture handle'ы освобождаются на следующем кадре (`retire/flush/pending`).
  Три операции различаются явно: reload данных, reload поведения
  (`behavior()` — перезапуск рантайма, замыкания не сохраняются) и scoped
  restart сцены (`restartScene(name, { capture, restore })`). `$.resource`
  получил версию записи и `publish(name)`; `$.devtools.assets()` и кнопки в
  панели F1. Тесты: `tests/js/reload_test.mjs`,
  `tests/agent/highlevel_reload_test.py` (100 reload — нулевой прирост узлов,
  тел, подписок, ресурсов, текстур и спрайтов).
- **§39. Полноценные local/world трансформы.** Узел получает opt-in локальный
  трансформ (translation/angle/signed scale) с композицией по цепочке
  родителей; dirty-обход пакетный, с защитой от циклов; reparent с политикой
  keep-world/keep-local. Старые `.at()/.pos()` и world-space дети работают как
  раньше — расширение включается опцией. Добавлены `worldPoint/localPoint/
  localAt/localAngle` и `engine.setResolveTransforms`.
- **§40. Независимые площади и включение форм.** У узла может быть несколько
  именованных областей с ролью, локальным смещением/углом, слоями и масками:
  `$('#hero').area('sword', {...})`, `.areaOn()`, `.areas()`, `.areaOverlap()`.
  Нативно — `engine.setShapeEnabled(body, index, on, …)`, `engine.setShape`
  (пересборка с сохранением индекса) и `engine.shapeOverlaps()`. Событие
  контакта несёт `areaA/areaB`, `roleA/roleB`, `ownerA/ownerB` — sensor-узел и
  логический владелец раздельно; индекс формы не съезжает при пересборке, а
  выключение формы не удаляет владельца.
- **§41. Мультицелевые дорожки анимации.** У дорожки появились `target`
  (относительно корня плеера), стабильный `id`, `binding` и `mode`; binding
  разрешается в `play()`, а не селектором каждый кадр. Поддержаны числовые,
  дискретные bool/enum и event/audio/method-дорожки; минимальные bindings —
  transform, visible, sprite.frame/clip, emitter, shape.enabled, light, UI,
  audio.gain, attr/value. Audio cue несёт resource/bus/gain/offset/length и
  огибающую **своего** handle. Маркеры имеют ID и policy при seek/loop/skip/
  restore; gameplay-окна открываются и закрываются, прерывание закрывает окно
  атаки; seek предпросмотра урона не наносит. `$.anim.load()` играет клипы из
  JSON без ручного frame-callback. Плеер получил опцию `clock`
  (`simulation`/`presentation`).
- **§42. Частичная коллизия тайла и логические координаты.** В данные тайлсета
  добавлен необязательный дескриптор `tiles`: visual region/source, локальная
  геометрия коллизии, маски, one-way, sensor и occluder. Полная клетка идёт
  прежним быстрым слиянием; частичная геометрия сливается только при точной
  эквивалентности, а не «до размера картинки». Появились `origin` и `pad`
  (логические координаты, клетка `x=-1` и нижняя рамка без выхода за буфер),
  канонизация нескольких атласов в таблицу visual ID, `shapeAt/shapesOf/
  shapeOccluders`, `.tileOccluders()`. Превышение лимита тел даёт **failed
  result** (`{ok:false, error:'body-limit', planned, created}`) вместо молча
  неполной коллизии; прежнее поведение доступно явным `.collisionLimit('partial')`.
- **§43. Seeded simplex.** `$.random.simplex2D/noise/fbm2D/algorithms/hashCells`
  с контрактом algorithm/version/seed/frequency и зафиксированными эталонными
  samples; старый value noise и его последовательности не изменены. Потоки
  `gameplay/generation/presentation` и состояние RNG: `$.random.stream/state/
  restore/validateState` — сохранение продолжает последовательность с середины
  сессии. Эталоны и их воспроизводимая пересборка — `tests/fixtures/generation_noise`.
- **§17. Структурированная диагностика.** Новый модуль `src/highlevel/diag.js`:
  ошибка несёт code, subsystem, operation, message, recoverability, nodeId,
  assetPath, jsonPath, source (файл:строка) и frame; одинаковые сообщения
  подавляются со видимым счётчиком потерь, журнал ограничен кольцом на 128
  записей; публичный вход — `$.debug.errors()`, `$.debug.report()`,
  `$.debug.reportError()`, `$.debug.expectClean()`.
- **§4.3/§13/§14. Фазы кадра, трассировка, стабильные ID.** Порядок фаз
  задокументирован в [docs/FRAME_PHASES.md](docs/FRAME_PHASES.md) и проверяется
  тестом; у узла появился стабильный логический ID `$('#x').nid()`, который
  попадает в снимок узла и в события (`nid`, `source_id`, `target_id`); журнал
  `$.trace` показывает цепочку событий и ограничен по размеру.
- **§35.2. Стенд производительности.** `demos/stress` — шесть сцен (физика и
  контакты, тайлмап 200×100, частицы, свет, интерфейс, смешанная) и
  `tools/bench_stress.py`, который печатает перцентили, CPU-зоны и GPU-время из
  профайлера и отказывается называть GPU-время, если движок его не измерял.
- **§31-1. Первый вертикальный пример.** `demos/foundations` на чистом `$`:
  край платформы, склон, односторонние платформы, спрыгивание, перенос
  движущейся платформой, зоны камеры и геймпад. Приёмка —
  `tests/agent/foundations_test.py` (25 проверок, включая перенос 39 px = 39 px).
- **§44. Обработка узлов, visibility events и simulation ticks.** Отдельные
  opt-in политики узла (`src/highlevel/triggers.js`): `update` (кадровая логика
  и контроллер), `fixed` (подписки/таймеры шага), `animation` (спрайтовые
  кадры), `timers` (`$.time.after/every` с владельцем), `physics`
  (`engine.setBodyEnabled`) — плюс наследование от области владения §5 через
  `$.processing.scope(scope, spec)`. Методы узла `.processing()/.active()/
  .isActive()`; `.hide()`, сон тела, «не обрабатывать» и `.areaOn()` —
  по-прежнему четыре разные операции. Visibility/activation: `$.activation.
  watch/visible/auto` шлёт `screen:enter/exit` и `region:enter/exit` по реальным
  world bounds, с `margin`/`hysteresis`, политикой камер (`any`/`main`/имя/
  список) и `once`. Симуляционные тики отделены от кадров: `$.time.tick()/
  simDt()/simTime()/onTick()/everyTicks()/afterTicks()/duration()/mark()/
  since()`, владелец подчиняется политике (§6 не тронут: пауза и hit-stop
  останавливают шаги тем же множителем `engine.setTimeScale`). Приёмка —
  `tests/agent/highlevel_activation_test.py` (120 шагов симуляции при 30/60/144
  render FPS дают одинаковую позицию и одинаковую жизнь снаряда).
- **§11. Контракт зон: enter/stay/exit, once, cooldown.** У зоны появились
  `stay`/`stay_ms`/`stay_ticks` (событие, пока цель внутри, со своим
  интервалом), `once` (ровно один `enter`; `$.triggers.reset(zone)` возвращает
  зону в работу), `cooldown` (не чаще одного `enter` на цель за окно, без
  «leave без enter»), `onStay` и выбор часов `clock: 'game' | 'ticks'` — на
  паузе игровое время стоит, значит `stay` молчит. Зона, в которой цель
  оказалась созданием или телепортом, получает `enter` следующим кадром.

- **§10/§14/§26. Пакет W2-C: save/restore, состояние RNG, replay-хэши.** Формат
  слота версии 3 делит снимок на разделы `profile`/`run`/`room`/`presentation`
  (политика одного `$.save`, не четыре системы): настройки ввода, звука и язык
  лежат в `profile` и не сбрасываются при перезапуске прохождения
  (`$.save.restartRun()`), плоские `store`/`world`/`speeds` остаются в объекте
  снимка зеркалами для старого кода, а в файл не пишутся. Состояние узлов
  (скорости, FSM-фаза, cooldown, логические статусы) сопоставляется по
  стабильному `nid`, а поведение поднимают зарегистрированные фабрики
  `$.save.behavior()` — логика не сериализуется. Восстановление транзакционное:
  чтение → проверка schema и content-версий → подготовка мира во временной
  области → связи и поведение по `nid` → инварианты → commit → освобождение
  старой области; ошибка до commit не уничтожает рабочее состояние
  (`restore()` отдаёт `{ ok, stage, missing, providers, content }`,
  `lastFailure()` — машиночитаемый код). Запись на диск: временный файл,
  проверка чтением, backup `.bak`, восстановление `read()/recover()/verify()`;
  слот будущей неподдерживаемой версии не перезаписывается. Replay-заголовок
  версии 2 несёт schema, ID движка/сборки, content-версии, seed и полный снимок
  RNG, fixed step и версию input mapping; ввод пишется на уровне разрешённых
  actions (raw — рядом для диагностики), `checkpoints({every})` снимает state
  hash на заданных simulation ticks, а `divergence()` называет первый
  расходящийся tick, поля (`nid.поле`), IDs и версии. Hash не включает
  настенные часы, GPU-ресурсы и presentation-значения, а потребление
  `presentation`-потока RNG на расхождение не влияет. Приёмка —
  `tests/agent/save_restore_test.py` (restore в прыжке/полёте/coodown/фазе,
  счётчики подписок и таймеров, death/retry, два одинаковых прогона, backup и
  версия из будущего), `tests/agent/highlevel_save_test.py`,
  `tests/js/{save,replay}_test.mjs`.

## Не выпущено — спецификация проверяется машиной: чеклист §37, приёмка §35, состав данных §33

- **Исправлено встраивание скриптов.** Сборка экранировала знак вопроса
  восьмеричным `\077` с пустой строкой рядом, чтобы к escape не «прилипла»
  цифра. Движок читает встроенный текст как JavaScript, и QuickJS понимает
  такую запись иначе: получался `\0` и пустая строка, поэтому весь бандл
  падал на старте с `SyntaxError: invalid property name`, а `$` не появлялся.
  Теперь управляющие символы идут шестнадцатеричным escape, а `?` не
  экранируется вовсе. Регрессию ловит новый
  [tests/embed_sync_test.py](tests/embed_sync_test.py): он сверяет КАЖДЫЙ
  встроенный модуль с файлом на диске побайтово и запускается перед релизом.
- **§29. Preview SDK и движок сверены по числам.** Новый
  [tests/sdk_preview_parity_test.py](tests/sdk_preview_parity_test.py) собирает
  проект, разбирает атлас через SDK (`atlas-info`) и через движок
  (`$.atlas.load`) и сравнивает кадры и их регионы: расхождение backend и
  runtime теперь ловится тестом, а не глазами. Там же проверяется, что SDK
  видит ассеты по реальной файловой структуре и привязывает их к инструментам
  реестра (`assets`), а испорченный атлас отклоняют обе стороны.
- **§31-7. Пример Recovery.** `demos/recovery` показывает восстановление:
  битый слот поднимается из копии `.bak`, последний корректный слот остаётся
  целым, битый ассет даёт `ok:false` с кодом и игра продолжает отвечать,
  после починки ассета перезагрузка применяется без перезапуска, а запись и
  проигрывание прогона обнаруживают расхождение и называют первый
  расходящийся тик с полем и ID. Приёмка — `recovery_test.py` (66).
- **Тесты перестали падать от нагрузки.** `demos_test` требовал первого
  убийства ровно за 900 кадров, хотя момент подхода врага в радиус
  автонаведения зависит от загрузки машины: на одном и том же дереве он то
  проходил, то нет. Теперь тест ждёт появления первого убийства (но не дольше
  потолка), а `tools/agent_client.py` повторяет ЗАПУСК движка, если он не
  успел сказать `ready` за `start_timeout` — отказ старта под нагрузкой это не
  результат теста. Настоящие ошибки по-прежнему не повторяются.
- **§20.1. Маска получателя света.** Узел объявляет, свет каких слоёв он
  получает (`.lightMask(bits)`), источник — свой слой (`.lightLayer(bits)`,
  `$.gfx.light.layer(bits)`). Сначала измерение: N композитов по слоям стоит
  N × 0.030 мс и всё равно требует маску получателя, поэтому выбран проход
  маски (запускается только если в кадре есть узел с маской) плюс гейт
  `(receiver & layer) != 0` при накоплении света. Вершина выросла с 20 до 24
  байт (+2.9 КБ/кадр в стресс-сцене против 0.88 МБ геометрии света), p95
  остался 8.35–8.36 мс при бюджете 16.67. Замерами найдены и исправлены четыре
  реальных дефекта, в том числе `.lit(false)`-узел внутри радиуса источника
  получал свет поверх себя (255 вместо 169.3). Приёмка —
  `light_receiver_mask_test.py` (22 проверки).
- **§20.2. Попиксельные normal-карты: измерение и объявленный fallback.**
  Замеры показали, что корректная реализация требует юниформов и атрибута
  нормали в спрайтовой вершинной стадии (сейчас 20 байт на вершину: позиция,
  UV, цвет), а свет приходит одним аддитивным композитом — то есть от 29.5 млн
  вычислений «источник↔пиксель» на кадр при 32 источниках. Выбран объявленный
  fallback, который приёмка §20.2 прямо допускает: `$.gfx.normalPath()` честно
  сообщает, что режим недоступен и ЧЕГО не хватает, а `perPixelNormal(true)` не
  включает его молча, а объясняет причину. Приёмка — изображениями
  (`node_normal_map_test.py`, 18 проверок): свет слева и справа зеркалит
  градиент, материал с normal-картой идентичен базовому, trimmed кадр не
  смещает свет, тень следует за движущимся occluder. Замер до/после: p95
  8.348 → 8.345 мс, GPU-время 1.817 → 1.660 мс.
- **§16. UI-слой, локализация и timeline.** Постоянный HUD отделён от временных
  окон явно (`$.ui.persist/transient`): раньше HUD, собранный в `$.ready`,
  умирал на первой же смене сцены. Модальный диалог занимает контекст
  `ui.modal` и гасит игровые действия, фокус возвращается в том же кадре.
  `$.i18n.onChange/missing/mark/number` + `$.ui.tr`/`doc.tr` переводят меню, HUD
  и открытый диалог без перезапуска, пропавший ключ даёт явный маркер, а не
  пустую строку. Привязки данных перерисовывают только изменившееся.
  `$.timeline.skipAll/markers/skippedMarkers` и контракт возврата
  `state().restored` (камера, музыка, управление) закрывают сценарии
  stop/skip/restore. Приёмка — `highlevel_ui_contract_test.py` (76).
- **§29: звук тоже проверяет ссылки.** Валидатор `.audio.json` принимал любой
  непустой `path` и не смотрел, существует ли файл, — тогда как атлас и шрифты
  это проверяют. Теперь отсутствующий звук даёт `SDK_AUDIO_FILE_MISSING` с
  машиночитаемыми `details` ещё до запуска.
- **§29: валидаторы манифеста batch и сессии агента.** `.batch.json` и
  `.agent.json` раньше проверялись типом `json`, то есть только «это JSON»:
  манифест с несуществующей операцией проходил проверку, а панель Automation
  показывала свои замечания вместо структурных кодов. Теперь есть типы
  `sdk.manifest` (version, jobs[], только `op: validate`, непустой source) и
  `sdk.agent-session` (version, game, requests[], timeoutMs, seed uint32, `quit`
  только последним) — те же правила, по которым файлы реально исполняются.
- **§31: семь примеров проверяются как проекты.** Новый
  `tests/demos_examples_test.py` запускает каждый из семи вертикальных примеров
  движком (`--headless`) и проверяет структуру проекта, README, наличие
  приёмочной проверки и присутствие в `docs/demos.md` — «пример есть в дереве»
  и «пример работает из пакета» больше не одно и то же утверждение.
- **§23. Комнаты, tilemap и prefab data как транзакция.** Новый `$.room`
  проводит загрузку через §5: сначала валидация всего описания (без создания
  узлов), затем сборка в staging-области владения, и только успешная
  публикуется на границе кадра — неудачная загрузка не меняет мир. Комната
  регистрируется и как сцена (`room:<id>`), поэтому её ID переживает
  save/restore. Визуал, коллизия и occluders строятся из одних данных, а правка
  клетки пересобирает только изменившиеся тела (сопоставление по геометрии):
  `dirty_cells`, `created`, `reused`, `destroyed`. Ошибки ссылок —
  структурированные `R2D_ROOM_*`. Приёмка — `room_transaction_test.py` (31).
- **Заголовок replay называет версию сборки из коробки.** Движок отдаёт
  `engine.version` (версия проекта из CMake), а `$.replay.identity()` без
  аргумента возвращает РАЗРЕШЁННЫЙ паспорт вместо `null`: заголовок записи и
  отчёты больше не пишут «версии нет», когда она есть. Игра по-прежнему может
  уточнить ID явно — явное значение важнее автоматического.
- **`$.save` пробрасывает `fatal` на все стадии записи.** Раньше отказ записи
  ВРЕМЕННОГО файла (и замена основного) возвращался структурой без записи в
  `$.debug.errors()`: провал обязательной операции был виден только строкой в
  журнале. Теперь `$.save.save(slot, { fatal: true })` даёт
  `R2D_SAVE_TEMP`/`R2D_SAVE_REPLACE` в `stats().last_failure` и структурную
  запись для машины, а пример `demos/recovery` проверяет именно поведение ядра
  — обход на стороне игры убран.
- **Исправлен `$.atlas.get(...).size()`.** Метод обещан в
  `docs/highlevel/atlas.md`, но падал с `ReferenceError`: внутри стояло
  свободное имя `texture`, которого нет в области видимости. Теперь размер
  берётся у страницы атласа, а регрессию ловит проверка в
  `highlevel_atlas_test.py`.
- **§31-5. Пример Lit sprites.** `demos/litsprites` показывает 2D-свет целиком:
  яркость на свету и в тени, маски источников (чужой слой не освещается),
  динамический occluder на узле мира (скрытый препятствием не считается),
  `.lit(false)` для неосвещённого слоя, неизменность UI и кадры атласа с
  отражением без протечки на соседа. Приёмка — `litsprites_test.py` (25).
- **§31-3. Пример Pattern arena.** `demos/arena` показывает арену с фазами по
  таблице (HP / длительность / интервал), отменяемыми действиями фазы (после
  отмены за 90 кадров не появляется ни одного снаряда), пулом с жёстким
  потолком узлов (48 узлов при 163 выдачах), паузой через `$.time.pause` и
  политики §44, смертью ровно один раз и рестартом, возвращающим числа к
  исходным. Приёмка — `tests/agent/arena_test.py` (62 проверки).
- **§29. Валидация ассетов SDK под тестом.** Новый
  [tests/sdk_validation_test.py](tests/sdk_validation_test.py) прогоняет КАЖДЫЙ
  зарегистрированный тип валидатора SDK (project, sprite.atlas, tilemap,
  particles, collision, layers, fonts, audio, input, rmlui.document,
  rmlui.style): корректный ассет проходит без диагностик, сломанный выявляется
  ДО запуска структурированным кодом, ссылка на отсутствующий файл (картинка
  атласа, шрифт, звук) ловится отдельно. Тест берёт список типов у самого SDK,
  а не из своей таблицы, поэтому новый валидатор без проверки не останется.
- **§28. Отладочные цепочки боя и анатомия узла.** `$.trace.hit(id)` собирает по
  hit ID всю цепочку: источник атаки → решение фильтра → результат урона →
  смерть; отказ (`immunity`, `duplicate`, `team`, `inactive_window`, …) — такая
  же запись с причиной, поэтому на вопрос «почему урона нет» отвечает журнал, а
  не чтение кода боя. `$.debug.anatomy(sel)` отдаёт одним снимком тело с
  фильтром, области с ролями и native-индексами, опору, активные окна и
  политику обработки; `$.debug.contacts()` — контакты за шаг с фазой, нормалью
  и ролями. Снимки не меняют исход симуляции (проверено сравнением состояния).
- **§18/§20/§22. Презентация, свет и атласы.** Порядок проходов кадра
  зафиксирован таблицей (мир → свет → неосвещённый слой → UI → пост →
  переход) и проверяется эталонными сценами; добавлены презентационный
  снаппинг, целочисленная шкала и материалы спрайтов. Свет получил профиль
  качества с ИЗМЕРЕННОЙ деградацией (`maxShadowLights/maxRays/maxSegments`),
  маски, динамические occluders и неосвещённый слой `.lit(false)`. Атласы:
  страницы с путями относительно JSON, мипмапы только при запасе padding и
  extrusion (иначе кадр «протекает» на соседа), import-манифест и 11 кодов
  ошибок в `$.atlas.verify()`. Найден и исправлен баг: собственные препятствия
  узла попадали в ключ кэша, но не участвовали в лучах.
- **§27. Горячая перезагрузка ассетов.** `$.reload` проводит замену через
  read → validate → prepare → apply: первые три стадии ничего не публикуют, и
  ошибка любой из них оставляет last-known-good (структурный код
  `R2D_RELOAD_*` в `$.debug.errors`). Граф зависимостей с топологическим
  порядком (atlas → страницы → клипы; tilemap → коллизия; rml → стили),
  версии ресурсов, отложенное освобождение старых handle'ов после кадра.
  Проверено на 100 перезагрузках: узлы, тела, ресурсы, текстуры, спрайты и
  подписки не меняются. Новый биндинг `engine.reloadTexture` заливает текстуру
  НА МЕСТЕ, поэтому спрайты продолжают работать; смена размера и внешний
  `.rcss` честно отклоняются как «не хот-релоад».
- **§19. Зоны камеры и аренды.** `$.camera.zone/enter/leave/control` описывают
  комнату как ДАННЫЕ поверх существующей камеры (границы, зум, следование,
  смещение, deadzone, lookahead, приоритет), а не как вторую камеру.
  `$.camera.lease/release` — временное управление для катсцен: аренда перебивает
  зону по приоритету и возвращает РОВНО прежнюю конфигурацию, а с `ms` истекает
  сама. `$.camera.enter()` без имени переходит в комнату, где находится цель.
- **Разбор всех модулей под QuickJS.** Парсер QuickJS-ng строже Node: реальная
  незакрытая скобка вызова (`normalizeAttack({ ... };`) проходила
  `node --check`, но валила весь встроенный бандл — движок падал с
  `SyntaxError`, `$` не определялся, и ни один агентский тест не запускался.
  Новый [tests/parse_all_test.py](tests/parse_all_test.py) разбирает КАЖДЫЙ
  модуль `src/highlevel` и каждую точку входа игры и примеров тем же qjs, что и
  юнит-тесты, и запускается перед релизом.
- **Чеклист §37 стал тестом.** `tests/checklist_test.py` проверяет
  архитектурные обязательства (§1.1, anti-goals §36) по коду и файлам: игра и
  примеры не импортируют внутренние модули, ECS/компонентов нет, UI описан
  разметкой RmlUi, timeline связан с диалогами, RE2D-профиль задан опцией и
  закреплён тестом. Для каждого P0-пункта чеклиста назван файл-доказательство;
  незакрытое помечается явно («ждёт §45»), а не зеленеет по умолчанию.
- **Программа приёмки §35 стала тестом.** `tests/acceptance_test.py` проверяет
  три части: доказательства по классам сценариев (unit, integration, recovery,
  lifecycle, visual, audio, delivery), отчёт замера производительности с
  конфигурацией измерения (commit, бэкенд, разрешение, целевой FPS, счётчики,
  p50/p95/p99, CPU-зоны, GPU-время) и gate `p95 ≤ 16,67 мс`, а также связку
  «спецификация + план + фикстуры». Недоступная метрика (память движка) честно
  помечена как отсутствующая, а не подменена памятью обвязки.
- **Стресс-стенд §35.2 расширен**: отчёт теперь называет железо, ОС, GPU-бэкенд,
  ревизию, разрешение и целевой FPS, а gate записан числом. На базовом профиле
  1920×1080, 60 FPS, fixed 60 Гц все шесть сцен дают p95 ≈ 8,35 мс.
- **Приёмка 2D-профиля.** `tests/profile_2d_test.py` запускает НЕ исходники, а
  собранный движок без Re2D-authoring: проверяет, что `$` поднимается, кадры
  идут, игра и примеры работают без ошибок, все подсистемы 2D-профиля доступны
  игре, authoring-подсистемы 3D отсутствуют, а возможности P0 (контексты
  ввода, области узла, локальные трансформы, `nid`, боевой контракт, тики
  симуляции, экранное искажение, снимок RNG) действительно доступны.
- **Состав данных §33 задокументирован и сверяется с кодом**:
  [docs/FORMATS.md](docs/FORMATS.md) называет для каждого расширения место в
  коде, а `tests/format_extensions_test.py` ловит расхождение обещаний и
  реализации. Незаявленные расширения (страницы атласа, полный материал,
  музыкальные stems) помечены как не входящие в профиль.

## Не выпущено — P0-волна закрыта: ввод, save/replay, обработка, экранный эффект (§15, §10/14/26, §44, §46)

- **§15. Контексты ввода, перепривязка и устройства.** `$.input.context(name,
  {active, priority, binds})` — меню, диалог, gameplay и загрузка объявляют
  действия независимо, а нажатие достаётся самому приоритетному активному
  контексту. `$.input.consume(action)` гасит действие для всех остальных на
  текущий и следующий кадр — именно это требование «один confirm не должен
  закрывать реплику и бить одновременно». Добавлены `conflicts()`,
  `markDefaults()/resetDefaults()`, `waitForInput()` с отменой и таймаутом,
  политика слотов геймпада (`device(slot).assign(player)`, `stuck()`,
  `resetHeld()`), подписи кнопок `glyphs()` для UI, оси с гистерезисом
  (`axisAction`) и виртуальный ввод (`synthPress/synthDown/synthRelease`),
  идущий тем же разрешением действий, что настоящие клавиши.
- **§10/§14/§26. Save, restore и replay.** Формат слота v3 делит снимок на
  profile / run / room / presentation: настройки управления, языка и звука не
  сбрасываются при перезапуске забега. Состояние сопоставляется по стабильному
  `nid`, а не по порядку обхода дерева; restore идёт по протоколу
  чтение → версии → подготовка → связи → инварианты → commit, и ошибка до
  commit не уничтожает рабочее состояние. Запись на диск — временный файл,
  проверка чтением, копия `.bak` и `recover()`; слот будущей версии отклоняется
  без перезаписи. Replay v2 хранит ID движка и сборки, хеши контента, seed и
  ПОЛНЫЙ снимок RNG-потоков, fixed step и версию раскладки ввода; ввод пишется
  на уровне actions, чекпоинты — по тикам симуляции, а `divergence()` называет
  первый расходящийся тик, поля и ID. Поведение при restore восстанавливают
  зарегистрированные фабрики (`$.save.behavior`), а не сериализованные функции.
- **§44. Политики обработки, видимость и тики симуляции.** У узла и области
  владения появились независимые политики `update` / `fixed` / `animation` /
  `timers` / `physics`: «не обрабатывать», скрыть, усыпить тело и выключить
  сенсор — четыре разные операции. `$.activation.watch` даёт события
  enter/exit по реальным world bounds с margin и гистерезисом, поддержкой
  нескольких камер и режимом «один раз». Счётчик тиков симуляции отделён от
  кадров рендера: 120 тиков достигаются за 59, 119 и 288 кадров при 30/60/144
  FPS, а путь тела остаётся тем же.
- **§46. Экранное искажение.** `$.gfx.post({distort, wave_amp, wave_freq,
  wave_speed, wave_axis, noise_amount, noise_scale, channel_shift})` и пресеты
  `underwater`/`glitch`: волна, дрожание по процедурному шуму (генерируется
  движком, ассет не нужен) и расхождение каналов живут в существующем
  пост-проходе, который и так читает готовый кадр. При нулевых параметрах
  проход — тождество, эффект переживает resize и не оставляет feedback-мусора.

## Не выпущено — P1-волна: изоляция аудио-шин и музыкальные слои (2026-10-16)

- **§48. Изоляция шинных эффектов.** Шина — группа микшера со своим пост-микс
  колбэком, поэтому эффект (в т.ч. реверб-посыл) считается по её буферу и не
  протекает в другие шины; на канале он не дублируется. Новое:
  `handle.toBus(name)` (смена шины на ходу без изменения громкости/панорамы и
  без переноса хвоста), `$.audio.remove()` переподчиняет звуки родителю и
  освобождает нативную группу с эффектом (`engine.audio.destroyGroup`, слот
  переиспользуется), `$.audio.routes()` — карта маршрутизации с `dry/colored`
  и предупреждением, когда общая комната микса красит сухую шину. dB и
  линейный gain разведены явно: сеттеры принимают `{ db }`,
  `$.audio.dbToLinear/linearToDb`. PCM-проверка — `tests/audio/fx_test.c`
  (сухая шина прозрачна бит-в-бит, хвост соседа не протекает, двойное
  применение отличимо, reset гасит хвост).
- **§25. Музыкальные слои.** `$.sound.stems(paths, opts)` — нативный transport:
  все слои стартуют ОДНОЙ командой под локом микшера (общий sample-clock),
  seek и pause применяются ко всем, петля идёт по `loopStart`/`loopEnd`
  (`MIX_PROP_PLAY_LOOP_START_*`), огибающие громкости слоёв и `crossfade`
  считаются по кадрам. Замер приёмки: расхождение слоёв 0.0000 мс после старта,
  seek и паузы; петля возвращается на 1.016 с вместо нуля; сумма громкостей
  слоёв при кроссфейде ≤ 1.

- **§16. UI/HUD, локализация и timeline.** Контракт интерфейса стал
  проверяемым: `$.ui.persist/transient/persistCount/persistList` отделяют
  постоянный HUD от временных окон (`clearWorld` сносит всё, кроме помеченных,
  поэтому раньше HUD, собранный в `$.ready`, умирал на первой же смене сцены);
  `$.ui.required/checkRequired/has/documents/report` объявляют обязательные ID
  RmlUi и возвращают структуру «вот чего нет»; `$.ui.tr` + `doc.tr` + подписка
  на `$.i18n.onChange` обновляют открытые документы и узлы при смене языка НА
  ХОДУ (объектная форма `{ key, n }` поддержана); `$.ui.trList/retranslate`.
  Модальность и фокус: widgets занимает контекст `ui.modal` (§15) и гасит
  `pressed()` игровых действий, `$.ui.inputBlocked()/modalOpen()/modalContext()`
  — единый гейт, `$.ui.closeTop()` закрывает верхний контекст по Escape/back,
  стек фокуса (`focusStack/pushFocus/restoreFocus`) возвращает фокус в том же
  кадре после закрытия диалога. Локализация: `$.i18n.onChange/listenerCount`,
  `missing()` со языком и счётчиком, явный маркер fallback `mark(true)` →
  `⟨key⟩`, числа без `Intl` (`number/separators`), активный диалог
  перерисовывается на смену языка и снимает подписку при закрытии
  (`langBound()`), пропавшие ключи не дают пустой строки. Timeline: биты
  `marker` (по умолчанию ровно один раз за прогон, `once: false` — каждый),
  `skipAll()` доводит прогон до конца без исполнения необратимых маркеров
  (`markers()/skippedMarkers()`), и единый контракт возврата
  `state().restored = { camera, music, control }` для конца, stop и skip
  (снимок берётся до `buildStage`). Приёмка —
  Привязки данных `$.ui.bind/bindings/bindStats/unbind` (здоровье, cooldown,
  таймер, прогресс загрузки, устройство) обновляют вид только при смене
  значения. Приёмка — `tests/agent/highlevel_ui_contract_test.py`
  (76 проверок: HUD переживает
  рестарт комнаты, ru→en→ru меняет видимые строки узла и документа, Shift-
  независимые числа, модальный ввод погашен, Escape вернул фокус,
  800×600↔1200×700 сохраняют раскладку, ru/en длинный текст 351.7/343.5 px при
  панели 360, маркеры/skip/stop без роста подписок), `tests/js/i18n_test.mjs` и
  `tests/js/widgets_test.mjs`.
- **§45. Фактическая загрузка и progress.** Новый нативный модуль
  `src/async.c/h`: рабочий поток читает файлы и декодирует картинки в RGBA8
  (`SDL_LoadFile`, `IMG_Load_IO` + конвертация), главный поток в безопасной
  фазе забирает результаты (`engine.async.poll`) и применяет их — GPU-текстура
  создаётся только там, вне render pass, и регистрируется в кэше ядра под
  разрешённым путём, поэтому `.sprite(path)`/`loadTexture(path)` не грузят файл
  второй раз. QuickJS из чужого потока не трогается. В `$` появился
  `$.resource.request(list)` со состояниями queued → loading → decoded →
  uploading → ready | failed | cancelled и progress в известных единицах
  (реальные байты из stat + задачи; оценочные стадии честно помечены
  `estimated`), отмена освобождает задания и не применяет поздний результат, а
  провал уходит структурой в `$.debug.reportError` (`R2D_LOAD_RESOURCE`).
  `$.loading.watch(req)` ведёт полосу по байтам и стадиям, `$.loading.cancel()`
  отменяет запрос. `$.scene.loadAsync(name, { resources })` ждёт ресурсы,
  режет инстанциацию шагами `$.task` и публикует сцену только при совпадении
  generation: отменённая загрузка не появляется ни на следующем кадре, ни
  позже; отмена запроса отменяет зависящую сцену. Старый синхронный API
  (`$.resource.load/get/preload`, `$.scene.load`) работает как раньше, а без
  `engine.async` запрос честно идёт синхронным путём (`stats().workers === 0`).
  Приёмка — `tests/agent/highlevel_loading_test.py` (тяжёлый PNG 4096×4096:
  12–14 кадров анимации, 105–124 мс суммарно, самое дорогое кадровое время
  13.7–14.9 мс, отмена 8–9 мс), `tests/js/loading_test.mjs` (19 проверок).

## Не выпущено — курс на 2D-платформер: RE2D за опцией сборки, SDK без 3D (2026-10-15)

- **Опция `R2D_ENABLE_RE2D`** (по умолчанию `ON`). `-DR2D_ENABLE_RE2D=OFF` —
  сборка 2D-платформера: не компилируются `src/re2d*`, `src/real2d4.*`,
  `src/rotsprite*`, не подключается EXR-декодер панорамного неба (`tinyexr` +
  `zlib`, цель `r2d_world_exr`), не ставятся нативные биндинги
  `engine.re2d/rotsprite/real2d`, поэтому не устанавливаются модули `$`
  `$.re2d`, `$.re2dWorld`, `$.rotsprite`, `$.real2d`, `$.mesh`, `$.cels`.
  Игровой код обеих сборок один: конфигурацию видно из скрипта через
  `$.re2dEnabled`. Поведение по умолчанию не изменилось, существующие 3D-демо
  требуют сборки с `ON`.

  В сборке платформера каталог `demos/` (260 МБ, половина — 3D-авторинг) рядом
  с бинарником не копируется; `game/` и `assets/` копируются всегда.

  Честный замер (macOS arm64, RelWithDebInfo, одна сборка): секция `__TEXT`
  11.26 МБ с RE2D против 10.88 МБ без, `__DATA` 0.62 против 0.46 МБ — то есть
  сам слой стоит около 0.4 МБ кода и данных, а не «минус семь мегабайт». Плюс
  из сборки уходят зависимость `tinyexr`/`zlib` (цель `r2d_world_exr`),
  компиляция 26 исходников `re2d*`/`real2d4`/`rotsprite*` и три C-теста.
- **Вид узла `re2d` остаётся данными в обеих сборках.** `$.kinds` регистрирует
  его всегда, а отрисовщик по умолчанию — «вид узел не берёт»: `.kind(Re2D)`
  переживает JSON/prefab/снимок, в сборке без RE2D узел рисуется обычным 2D-путём.
  Камера при этом честно отказывает: `$.camera.kind(Re2D)` без нативного прохода
  бросает `TypeError` с причиной и подсказкой, а не падает на `engine.re2d.view`.
- **Честный hit-stop вместо пиннинга тел.** Физика шагается в C, поэтому
  добавлен множитель времени шага: `R2DApp.time_scale` (по умолчанию 1),
  аккумулятор в `src/main.c` получает `app->dt * app->time_scale`, а игра
  ставит его через `engine.setTimeScale(x)` / читает `engine.timeScale()`.
  Замер: при `setTimeScale(0)` тело не двигается ни на пиксель за 20 кадров,
  `$.time.frame()` продолжает расти, после `setTimeScale(1)` движение
  возвращается. Отрицательные значения и `NaN` приводятся к нулю.
- **RE2D вырезан из SDK.** Удалены нативные `sdk_re2d*`, `sdk_char`,
  `sdk_animation`, `sdk_fbx`, `sdk_obj`, `sdk_gltf`, `sdk_world`, `sdk_bake*`,
  `sdk_v2to3`, студии `re2dsprite-studio`, `re2d-baker`, `re2d-world-studio`,
  их тесты, документация и записи в реестре инструментов. Остались атласы,
  тайлмапы, спрайты, параллакс, частицы, звук, шрифты, коллизии, RmlUi,
  SDK-CLI и упаковка.
- **Документация:** [docs/BUILD.md](docs/BUILD.md) — таблица двух конфигураций
  и проверка обеих сторон опции; [docs/PHILOSOPHY.md](docs/PHILOSOPHY.md) §1 —
  RE2D назван необязательным слоем, а не фундаментом; [docs/TASKS.md](docs/TASKS.md) —
  курс на платформер; `docs/internal/NATIVE.md` —
  `engine.setTimeScale`; README — сборка и запуск.
- **Первая игра: кампания из трёх уровней.** `game/` — меню (RmlUi), три
  уровня (48x18 тайлов, 1536x576 px — на 2-3 экрана шире, чем старая сцена,
  поэтому камера с follow/deadzone/lookahead наконец работает), HUD, пауза,
  победа, чекпойнты и прогресс в `save.json`. Логика уровня живёт в
  `game/level.js` (сборка мира, монеты, шипы, движущиеся платформы,
  односторонние платформы, чекпойнты, ворота, отклик на удар), данные — в
  `game/levels.js`, кампания — в `game/campaign.js`; старые
  `game/scenes/{menu,platformer}.js` удалены, имя сцены `platformer` сохранено
  как псевдоним первого уровня для внешних инструментов.
- **Геймплей уровней:** шипы наносят урон с отбрасыванием и кулдауном,
  чекпойнт возрождает в точке касания (считается по расстоянию — ловится и на
  скорости падения), падение в яму штрафует 20 HP, враги патрулируют и бьют по
  кулдауну, ворота открываются только по сбору всех монет, отклик удара идёт
  через `$.hits` (искры, вспышка экрана, тряска, hit-stop).
- **Ручная проверка:** скриншоты меню и первого уровня; `game_test` проходит и
  в обычной сборке, и в `build-2d` (RE2D=OFF).
- **Проверки:** `tests/agent/re2d_gate_test.py` (фикстура
  `tests/fixtures/re2d_gate`) гоняется на обеих сборках и проверяет
  `$.re2dEnabled`, отсутствие 3D-семейства, отказ камеры и работу обычного 2D
  (ходьба, прыжок, тайлмап); `tools/ci_verify.py` получил флаг `--re2d {on,off}`,
  который при `off` ещё и требует, чтобы RE2D-целей в сборке не было.
- **Встроенное управление платформера.** `.controls(схема)` получил coyote time
  (`coyote`), буфер прыжка (`jumpBuffer`), переменную высоту (`jumpCut`),
  воздушные прыжки (`airJump`) и спрыгивание с односторонних платформ
  (`S`/`↓`+`Space`, метод `.dropThrough(ms)`); окна считаются игровым временем,
  а не кадрами. Новые поля по умолчанию выключены, поэтому прежние игры
  поведения не меняют. Управляемый игрок переносится движущейся кинематической
  платформой, а не отстаёт от неё: замер на фикстуре с трением платформы 0.02
  за 40 кадров — с переносом игрок проходит столько же, сколько платформа
  (−86.7 px против −86.7 px), без переноса — только −3.1 px.
- **ИЗМЕНЕНИЕ ПОВЕДЕНИЯ: `.attr('jumpForce')` теперь действует всегда.** Раньше
  сила прыжка из атрибута доходила до тела только у объектной схемы
  (`.controls({ axis: 'both' })`), а у строковой (`.controls('both')`) молча
  бралось умолчание 640 — вопреки `docs/tutorial-platformer.md`. Теперь порядок:
  `jumpForce` схемы → атрибут узла → 640. Игры, которые ставили
  `.attr('jumpForce', N)` со строковой схемой, прыгают иначе: в `game/` прыжок
  стал 700 (135 px) вместо 640 (114 px). Вернуть прежнюю высоту — убрать
  атрибут или поставить `640`; документированное поведение теперь работает без
  правок.
- **ИЗМЕНЕНИЕ ПОВЕДЕНИЯ: спрыгивание с односторонних платформ включено по
  умолчанию.** `S`/`↓`+`Space`, стоя на one-way, теперь спускает вниз, а не
  прыгает вверх (платформерная норма). Прежнее поведение возвращает
  `dropThrough: false` в схеме `.controls()`.
- **Проверки:** `tests/js/controls_test.mjs`,
  `tests/agent/highlevel_controls_test.py` (фикстура
  `tests/fixtures/controls_plat`), `tests/agent/highlevel_physics_test.py`.

## Не выпущено — три дефекта: сохранение модели, битая ссылка, охват бенчмарка (2026-10-12)

- **Сохранение модели без правок больше не трогает файл.** Раньше `serializeCharacter`
  (это `JSON.stringify`) терял написание чисел и разворачивал компактные файлы:
  Save без единой правки переписывал ассет, а анимации Dust2 раздувались
  (`npc.animations.json` 487 КБ → 1,66 МБ, `aks.animations.json` 575 КБ → 1,35 МБ).
  Проверка всех **76** описаний дерева (`*.character.json` + `*.animations.json`)
  нашла **24 расхождения**: 18 — только написание чисел (`0.0`→`0`, `25.0`→`25`),
  6 — только раскладка. Теперь `serializeDocument` отдаёт исходные байты, когда
  модель не менялась, и каноническую запись тем же отступом при правке;
  `markDocumentSaved` делает записанный текст новой базой (повторный Save снова
  байт-в-байт). Студия использует это в `save()` и черновике.
- **14 файлов `demos/rotsprite/weapons/*.character.json` канонизированы:** менялись
  только числовые литералы, значения те же. Генератор `bake_guns.py` пишет целые
  координаты без дробной части — иначе повторный бейк вернул бы `0.0`.
- **Битая ссылка.** `demos/real2d/assets/README.md` вёл в несуществующий
  `demos/real2d/rotsprite/README.md`; теперь `../../rotsprite/README.md`.
  `tests/repository_hygiene_test.py` — 0 сбоев.
- **Модуль `real2d` в охвате бенчмарка.** Он не был объявлен ни в одном кейсе
  `tools/bench_api_cases.json`, из-за чего стенд отдавал `uncovered=['real2d']`
  и код 1. Добавлен кейс синтеза кадра на реальном контейнере
  `demos/real2d/assets/head_real2d_v4.r2d4`: 4918.54 µs/op (для сравнения
  `rotsprite` — 4238.24). `docs/API_PERFORMANCE.md` перегенерирован.
- **Проверки:** `tests/js/sdk_re2d_model_test.mjs` 18/18 (сплошной прогон по 76
  файлам дерева), `tests/bench_api_runner_test.py` 7/7,
  `tests/repository_hygiene_test.py` — 0 сбоев.

## Не выпущено — SDK читает контейнер Re2DSprite v3 и правит его сетку (2026-10-11)

- **SDK читает Re2DSprite v3.** `r2d-sdk re2d-info`, `re2d-debug`, `re2d-sample` и
  `validate` распознают плотный контейнер (цвет, позиция, нормаль+блеск, кости,
  веса) и работают с ним так же, как с картами v2: версия, сетка `W×H`, `extent`,
  живые тексели, диапазон позиции, блеск, суммы весов, кости с числом текселей.
  Раньше v3 отвергался как «не PNG v2» (`SDK_RE2D_PNG_SIZE`), потому что карты и
  контейнер — разные раскладки одного ассета. Поле `format` (`v2`/`v3`) называется
  только тогда, когда файл действительно прочитан: для нечитаемой PNG там `null`,
  а не «v2 по умолчанию». Новый модуль `sdk/native/sdk_re2d3.c`
  (чтение, статистика, виды, проверка) собирается с ядром SDK и покрыт C-тестами.
- **Новая команда `re2d3-paint`.** Правка сетки текселей операциями `bone`
  (id + вес, нормировка к 255), `gloss` и `color` по прямоугольникам; меняются
  только живые тексели, заголовок контейнера не пересобирается, ошибка любой
  операции отменяет всю запись. Файл операций — JSON, один код для CLI, GUI и агента.
- **Re2DSprite Studio: вкладка «Сетка».** Редактор сетки v3 в RmlUi: кисть по
  кости, блеску и цвету, размер кисти, масштаб и сдвиг вида, undo/redo, отсчёт под
  курсором (цвет, позиция, нормаль, блеск, кости с весами). Правки живут в
  `build/sdk_cache` и в `.r2d-recovery-<ассет>.grid.json`; контейнер PNG меняет
  только «Сохранить PNG» — после него рантайм перечитывает спрайт сам. Вкладка
  «Поверхность» получила режимы v3 (нормаль, блеск, кость, вес). На картах v2
  редактор сетки честно отказывает кодом `SDK_RE2D3_ONLY`.
- **Правки сетки — разница с ассетом.** После «Сохранить PNG» список операций
  обнуляется, а сохранённый контейнер становится новой базой: Undo/Redo и
  «Сбросить правки» больше не могут разойтись с файлом (операции присваивающие,
  и «отмена» после Save не вернула бы тексели). Пустой список снимает и recovery.
  Веса операции `bone` нормируются к 255 методом наибольших остатков (прежний
  довесок первой доле мог дать вес −1 → байт 255 и сумму 511), значения в
  `ops.json` проверяются строго: `true`, строка и дробное число отвергаются, а не
  превращаются в 0. Нулевые веса текселя — факт данных (`weightsSum: 0`,
  `SDK_RE2D3_WEIGHT_ZERO` уровнем info): рантайм подставляет кость 1 сам.
- **Факты вместо догадок.** Идентификатор слоя костей трактуется двумя способами:
  `bake-re2d3` пишет индекс кости + 1, `convert-re2d3` переносит id части v2.
  SDK отдаёт обе трактовки (`asBone`/`bone`, `asPart`/`partBone`), а неописанные
  идентификаторы отмечает предупреждением `SDK_RE2D3_ID_UNDECLARED`.
- **Проверки:** `tests/sdk/sdk_core_test.c` (сборка контейнера в памяти, чтение,
  статистика, правка, запись, пустой и чужой контейнер), новый
  `tests/agent/sdk_re2d3_test.py` (CLI, рантайм на правленом контейнере, студия и
  мазок мышью), `tests/js/sdk_re2d_model_test.mjs` (кисть, мазок, режимы, тексель).

## Не выпущено — аудит документации: сверка всех доков с кодом (2026-10-11)

- **Проверены все справочники** (`docs/*.md`, `docs/highlevel/*.md`,
  `docs/internal/NATIVE.md`, `docs/re2d/*.md`, `docs/RE2DSPRITE_*`, туториалы) —
  READ-ONLY сверка каждого утверждения с кодом, шесть независимых аудитов.
  Демо-код не трогали.
- **Исправлены устаревшие утверждения**: у `$` вырос список подсистем (в §30
  добавлены `$.mesh`, `$.collision`, `$.cutscene`, `$.replay`, `$.loading`,
  `$.real2d`, Re2DSprite v3, тег `<real2d>`); `$.gfx.defineShader` принимает
  строку, а не `{frag}`; геймпадов четыре слота (а не один); `$.ui` больше не
  описывает несуществующие `on/off/listeners/text/html/style/unload`; у
  `engine.setOverlay` честно указано, что это легаси-хук без реализации, а
  клавиши `F1`/`F2` живут в JS; аудио-эффектов канала восемь
  (`lowpass/highpass/echo/tremolo/bitcrush/ringmod/reverb/none`); контакты
  приходят и односторонним платформам; цвет вершин меша — `0..255`; DXIL не
  собирается; `--record/--replay` существуют; `$.camera.pip` есть и проверен
  пиксельным тестом. Поправлены пути, ссылки и количества (файлы тестов, строки
  модулей, лимиты, `_CONTRACT.md` — 352 имени методов обёртки: добавлены
  `real2d*`).
- **Документация догнала новые подсистемы**: `docs/highlevel/real2d.md` и
  `docs/highlevel/rotsprite.md` описывают v3-конфигурацию синтеза
  (`engine.rotSpriteConfig`, `projection.raster/light/detail/eye/window/cull/
  motionLod`), `docs/RE2DSPRITE_JSON.md` — `skin`-клипы и 1..128 костей,
  `docs/internal/NATIVE.md` — группы `engine.nodes.*` и `engine.real2d.*`.
- **Сайт**: `site/build-doc.py` публикует и семейство `docs/re2d/*` (13 страниц
  были доступны только ссылкой на GitHub) — в сайдбаре появился раздел
  «RE2D World»; стражи `tests/repository_hygiene_test.py`,
  `tests/doc_claims_test.py`, `tests/doc_coverage_test.py` зелёные.

## Не выпущено — Real2D v4, стадия A: вычисляемый layered warp головы (2026-10-10)

- **Новый нативный модуль `src/real2d4.c`** — детерминированный CPU-рендер
  персонажа из отдельных семантических RGBA-компонентов. Контейнер `.r2d4`
  (ZIP store-only, CRC32, фиксированные timestamp'ы) несёт манифест, атлас,
  базовую геометрию (cage + mesh + барицентрические привязки) и манифолд
  `q(θ)=μ+B·a(θ)` с серией Фурье `K=3`. Кадр собирается
  инверсно-барицентрической растеризацией реальных texels атласа: правило
  top-left, билинейная выборка с clamp внутри клетки, linear RGB с
  premultiplied alpha, порядок слоёв по псевдоглубине, гейты видимости
  кольцами и маска окклюзии деталей лица по силуэту. Полнофигурных кадров в
  контейнере нет — каждый пиксель объясняется цепочкой
  patch → треугольник → UV (`engine.real2d.provenance`).
- **Модуль `$`: `$.real2d` и тег `<real2d>`** — `load`, `frame`, `pixels`,
  `info`, `provenance`, `provenanceMap`, `atlasPixels`, `debugSetAtlas`,
  `dispose`; методы узла `.real2dSrc/.real2dPose/.real2dYaw/.real2dSpin/`
  `.real2dSize/.real2dReload/.real2dInfo()`. Документация —
  [docs/highlevel/real2d.md](docs/highlevel/real2d.md). Отличие от Re2DSprite
  v2/v3 зафиксировано явно: там одна развёртка с попиксельными part-ID, здесь
  отдельные компоненты + манифолд + гейты.
- **Демо `demos/real2d`** с интерфейсом на RmlUi (закон UI): угол кнопками и
  стрелками, автоповорот, перечитывание контейнера клавишей `R`. Авторинг и
  bake — Python-инструменты `demos/real2d/tools/`, они не создают готовых
  кадров и не меняют texels атласа.
- **Доказательный тест стадии A** `tests/agent/real2d_test.py`: петля yaw
  (θ и θ±2πk — один кадр), шов на 0 и 2π, семь не-анкорных углов, provenance,
  зануление и восстановление атласа, мутация одного патча (изменяются только
  его пиксели), hard-validator вывернутых треугольников, `fill rule`, полный
  круг 24 шагами. Юнит-тест модуля — `tests/js/real2d_test.mjs`.
- **Композиция и переходы (второй проход).** Слои группы «лицо» складываются
  внутри группы с нормированным покрытием: два appearance-варианта по 0.5 дают
  alpha 1.0, а не 0.75 — ушла полупрозрачная «голова-призрак» на переходах.
  Переходы сужены до быстрого свапа (лицо 1.5°, глаза 3°, нос/рот 4°, волосы
  6–10°). Provenance пишется только для непустых сэмплов и переаллоцируется при
  смене размера растра (был выход за границу буфера). Добавлена структурная
  диагностика `engine.real2d.patchWeights`.
- **Честные границы стадии:** только голова, `pitch = 0`, растеризация
  однопоточная; в узком окне перехода (≈±1.5°) наложение двух рисунков ещё
  заметно — решение в общем chart с согласованной топологией (спека §6).
  Замер: 13.5 мс/кадр при 512×512 и 4.3 мс при 256×256 (цель спеки ≤1 мс не
  достигнута). Растеризация распараллелена через общий пул потоков движка
  (`r2d_rot_parallel`), очистка и загрузка в текстуру идут по грязному
  прямоугольнику; фазовая диагностика — `$.real2d.info().ms`.
  Планы и остатки — `demos/real2d/STAGE_A_PLAN.md` §8.

## Не выпущено — гейт: сначала философия, главный гейт «только 2D» (2026-10-10)

- **`tools/dsh-russiano2d-docs-gate` переделан.** Перед работой нужно прочитать
  только `docs/PHILOSOPHY.md` — конституцию движка (целиком, инструментом `read`).
  Остальные доки стали справочниками в системном промпте: они обязательны по
  правилам репозитория, но запись больше не блокируют.
- **Главный гейт: движок только 2D.** Страж отклоняет правку, вводящую 3D-сущность:
  имя пути (`render3d.c`, `mesh3d.js`, `r3d/`), имена `R3D`, `Scene3D`, `Mesh3D`,
  `World3D`, `Vector3`, `Matrix4`, `Quaternion`, `MeshRenderer`, `Physics3D`,
  `Camera3D`, загрузчики glTF/FBX в рантайме (`assimp`/`tinygltf`/`cgltf`/`glm`) и
  three.js. Это non-goal из [PHILOSOPHY.md](docs/PHILOSOPHY.md) §3; RE2D разрешён —
  projection в обычный 2D-кадр (§1). Из гейта исключены `docs/`, `sdk/`, `tools/`,
  `tests/`, сборки и дистрибутивы. Шаблоны откалиброваны тестом по существующему
  коду `src/`, `game/`, `demos/` — ложных срабатываний нет.
- Тесты плагина (26): `node --test tools/dsh-russiano2d-docs-gate/tests/gate.test.mjs`.

## Не выпущено — Re2DSprite v3 (2026-10-10)

- **Формат v3** ([RE2DSPRITE_V3.md](docs/RE2DSPRITE_V3.md)): плотная геометрическая картинка, кости/веса на тексель, скин-клипы, попиксельный свет, многопоточный растр. `src/rotsprite3.c`, `rotSpriteConfig`, `projection.raster/light/detail`.
- **SDK:** `bake-re2d3` (FBX/GLB/OBJ → v3 + клипы) и `convert-re2d3` (v2 → v3: Руся, цвет прямо из атласа).
- **Перспектива v3:** `projection.eye` (камера от первого лица), `window`, `cull`, `motionLod`; сглаживание силуэта при одном отсчёте на пиксель; частичная загрузка текстуры; растеризатор с приращениями рёберных функций. Бейкер: `--eye/--zoom/--raster/--window/--cull/--motion-lod/--detail`, поля UV-островов ложатся на ребро (без «плавников»).
- **Dust2:** автомат — один v3-спрайт с перспективой и клипами idle/draw/fire/reload (на полэкрана, вспышка у дула); зомби и Руся — v3 на растре 512 (≈2,5 мс синтеза вместо ≈24); новая комната «FIRE ALARM» с сиреной через HRTF; карта с пожаром — по `0`.
- **Окно:** щелчок возвращает фокус клавиатуры, захват мыши применяется заново при получении фокуса.

## Не выпущено — FBX в baker, AKS-74U, зомби и вторая карта (2026-10-10)

- **SDK: FBX.** `r2d-sdk bake-re2d` читает FBX (ufbx, `sdk/native/sdk_fbx.c`): меши со скином в позе клипа (`--fbx-stack/--fbx-time`), `--pivot`, `--fbx-tint`, `--fbx-ao`; `--type character` для Mixamo-гуманоида (`--fbx-rot` — A-поза). Тест `sdk_fbx_test.py`.
- **Игрок:** основной ствол — анимированный AKS-74U с руками (31 кадр, запечён SDK), автоогонь, перезарядка, патроны, красивая вспышка, HRTF-звуки пака Free Gun Sounds, оружие освещается светом мира.
- **Карта 2** (`0`): отдельный `$.re2dWorld` «горящий объект» — темно, красные аварийные панели, огонь/дым/взрывы штатными частицами, сирена через HRTF; переключение миров и возврат.
- **Зомби:** Re2D-персонажи из Mixamo FBX через SDK, ходьба через `animation-import`, `hit`/`death`, ИИ (слух, луч, обход), HRTF-рычание; смерть игрока и перезапуск.
- Dust2: добавлены надверные перемычки (в рантайме нет замыкания над открытым порталом), `nearest`-фильтр, текстуры с «кирпичными» швами, внутренний кадр 1024×576.

## Не выпущено — Dust2 Annex, пушки через SDK, HRTF-окружение (2026-10-10)

- **Dust2 расширен огромным крылом** (173 ячейки, 9 дверей, пандус на мезонин, этаж над этажом в атриуме, туманные/тёмные/эмиссивные/цветные комнаты, двор с небом, лабиринт). Камеры — `Tab`. Данные дописываются `demos/re2d_dust2/build_annex.py` в `dust2.re2dmap`, компилирует нативный `r2d-sdk world-compile`.
- **HRTF на максимум:** 17 позиционных источников окружения (ближайшие шесть живут одновременно — 16 каналов микшера общие), звуки дверей и выстрела тоже через HRTF. Звуки сгенерированы математически (`make_annex_assets.py`).
- **Оружие только через Re2DSprite и SDK:** новые `pistol`, `revolver`, `shotgun`, `smg`, `sniper`, `lmg` — 3D-модели из пиксель-арт текстур, запечённые `r2d-sdk bake-re2d --type weapon`; viewmodel игрока (`C`), оружие в руках NPC, просмотрщик `demos/re2d_gun_viewer`. Старые пистолет/дробовик из материалов АК удалены.
- Тест `tests/agent/re2d_dust2_annex_test.py`; ожидания `re2d_dust2_test.py` обновлены (312 ячеек, 315 промежутков, 11 спрайтов).

## Не выпущено — актуализация документации и r2d-help (2026-10-10)

- Документы сверены с кодом: в TASKS обновлён раздел Re2D World (порталы, небо, GPU-путь, World audio
  уже реализованы), описаны EXR-небо (`.sky({texture:'*.exr',exposure})`), сторонние библиотеки tinyexr,
  Steam Audio и ufbx (`docs/BUILD.md`).
- Терминология: в документах World вместо «actor» — «sprite node» (узел `$` со спрайтом); класса Actor
  в архитектуре нет, `$.story.actor` — имя из сценария, а не сущность.
- r2d-help: обучение эмбеддингов запускается на Mac на CPU (`tools/help_train/run.sh`, потоки
  `R2D_HELP_THREADS`, по умолчанию все ядра минус одно).

## Не выпущено — r2d-help: CLI-помощник по `$` API (2026-10-09)

- Новый бинарник SDK `r2d-help` (C11, `sdk/help/`): поиск по реестру `$` API, который собирается из
  `src/highlevel/*.js` (`def`/`defGet`, члены `$.<имя>`, комментарии), и по разделам `docs/`. BM25 +
  эмбеддинги GGUF через C API llama.cpp (только CPU), слияние рангов, детерминированный ответ JSON.
- Индекс пересобирается сам при сборке и при запуске из репозитория; векторы неизменённых записей
  берутся из прошлого индекса. Без модели — режим `bm25`. Описание — `docs/HELP.md`.
- `tools/release.py` кладёт `r2d-help`, индекс и модель рядом с `r2d-sdk`; тест `r2d_help_test` в
  `tools/ci_verify.py`.

## Не выпущено — SDK: все инструменты спецификации, новая тема, рабочие кнопки (2026-10-09)

- **Исправлено «кнопки не нажимаются»:** у контейнеров с `overflow: auto` не было стилей полос прокрутки,
  RmlUi резервировал под полосу всю ширину, и содержимое (каталог инструментов, списки) схлопывалось до
  нуля — кнопки «Открыть» были недоступны. Стили полос — в `sdk/ui/theme.rcss`.
- **Движок:** виртуальная мышь агента (`mouseMove`, `mouse`, `wheel`) теперь доходит до RmlUi: агент
  наводит курсор, нажимает кнопки интерфейса и крутит списки (раньше RmlUi получал только настоящие
  события SDL). Тест `tests/agent/ui_virtual_mouse_test.py`, описание в `docs/AGENT_API.md` §3.5.
- **SDK, оформление:** собственная тема в стиле сайта (`sdk/ui/theme.rcss`, `shell.rcss`, `studio.rcss`),
  навигация по группам, экран «Шаблоны» и «Сборки движка», Debug и Package.
- **SDK, недостающие инструменты:** Tilemap Studio, Particle Studio, Collision / Physics Tools, Parallax
  Tools, Font / Text Tools, Audio Tools, Input Tools, RmlUi Studio и DevTools; все предпросмотры — настоящий
  рантайм (`$.tilemap`, `$.particles`, Box2D, `$.layers`, `$.font`, `$.audio`, `$.input`, RmlUi). Форматы —
  JSON с `version: 1`, содержимое которого игра читает `$.fs.readJSON`; описание — `docs/SDK.md` §13–§17.
- Re2D Baker: импорт Wavefront OBJ + MTL (`bake-re2d model.obj`, `*.obj` в реестре); тест `sdk_obj_test.py`.
- `r2d-sdk`: команды `templates`, `new`, `engines`; нативные валидаторы `tilemap`, `particles`, `collision`,
  `layers`, `fonts`, `audio`, `input`, `rmlui.document`, `rmlui.style`; `build` создаёт каталог результата;
  Asset Browser не показывает служебные `.r2d-*` черновики.
- Тесты: `sdk_studios_test.py` (все студии настоящей мышью), `sdk_data_parity_test.py` (JS ↔ C, 2912 правок,
  0 расхождений), `sdk_kinds_test.mjs`, `sdk_rml_test.mjs`.
- Тесты `sdk_shell_test` и `sdk_classic2d_test` обновлены: карточки проверяются по id (буфер `getText` 8 КБ),
  рамка кадра — по серединам пикселей (не зависит от дробной раскладки RmlUi).

## Не выпущено — завершение SDK и контрольный аудит (2026-10-08)

- Добавлен отдельный периодический стенд `$` API: 75 компонентных и 20 кадровых нагрузок, сырая базовая линия и таблица с условиями измерения; сравнение учитывает оборудование и сборку.

- Re2DSprite: авторинг clips/emotions/variants/equipment, timeline seek и undo/redo.
- Baker: выражения VRM, dense/sparse morphs, material/UV binds, humanoid mapping, атомарная запись отдельных файлов.
- World Studio: RmlUi-авторинг `.re2dmap`, native compile, runtime preview и многоэтажность.
- Automation: C batch/agent, паритет 19 команд, RmlUi UI и CI проверки.
- Уточнены ограничения MVP и статус исходников относительно готовых пакетов 0.1.22.
- Документация и списки задач сверены с кодом; убраны системные файлы и временные артефакты.


## SDK: Character / VRM в Re2D Baker (Phase 5)

- `r2d-sdk bake-re2d --type character`: VRM 0.x и 1.0 → псевдоскелет Re2DSprite (10 костей,
  сокеты кистей), владение частями по весам скина, `*.character.json` + `spin`/`walk` + отчёт.
  Неоднозначное владение считается и сообщается (`SDK_BAKE_SKIN_AMBIGUOUS`), выражения VRM
  сопоставляются эмоциям Re2DSprite; выбранное `--expression` запекается в PNG.
- Загрузчик glTF читает узлы, скины (inverseBind, JOINTS_0/WEIGHTS_0) и расширения VRM.
- Re2D Baker (GUI): тип Character, `*.vrm` в реестре, панель VRM/владения/выражений.
- Проверено на синтетических VRM 0.x/1.0 и реальном Seed-san. Это не проверка всех экспортёров VRoid.

## SDK: Re2D Baker MVP — GLB/glTF → Re2DSprite (Phase 4)

- `r2d-sdk bake-re2d`: GLB/glTF (внешний `.bin`, `data:`-URI, иерархия узлов, текстуры
  baseColor) → PNG v2 + `*.character.json` + анимация `spin` + машинно-читаемый отчёт.
  Пресет Prop; Auto Unwrap и Use Existing UV; авто-вписывание Coordinate Fit; origin
  center/feet; PNG 1024/2048/4096; детерминированный результат.
- Re2D Baker в SDK (RmlUi): параметры, панель Coordinate Fit, отчёт, диагностика, превью
  запечённой модели настоящим `$.re2dSprite`, переход в Re2DSprite Studio.
- Тестовые low-poly props: crate, barrel, lamp, chair (+ негативные GLB/glTF).

## SDK: Re2DSprite Studio (Phase 3)

- Re2DSprite Studio: просмотр модели настоящим `$.re2dSprite`, yaw/pitch мышью и
  числами, клипы/эмоции/варианты/стиль, отладочные виды карт PNG v2 (материал, ID
  части, владелец, X/Y/Z, покрытие, группа, перекрытие), осмотр отсчёта, правка
  скелета и сокетов с undo/redo, сохранение тем же отступом, hot reload.
- `r2d-sdk`: валидатор `re2dsprite.character` (описание, анимации, PNG v2) и команды
  `re2d-info`, `re2d-debug`, `re2d-sample`; паритет с рантаймом проверяет тест на 82 правках.
- Исправлено: `$.re2dSprite.from('/абсолютный/путь.character.json')` теряло ведущий
  «/» у атласа и не находило PNG (`relativeAsset`).

## SDK: Sprite Studio и Animation Studio, Classic 2D срез (Phase 2)

- Sprite Studio и Animation Studio в `sdk/`: атлас `*.atlas.json` (Aseprite-
  совместимый формат `$.atlas`): кадры, пивот-слайсы, длительности, теги-
  анимации, метаданные, undo/redo, просмотр настоящим рантаймом.
- `r2d-sdk`: `atlas-grid`, `atlas-format`, `atlas-info`, валидатор `sprite.atlas`
  (стабильные коды `SDK_ATLAS_*`); канонический вид файла — одна строка на кадр.
- Движок: hot reload теперь следит и за `*.atlas.json` в каталоге игры
  (раньше — только `.js`).

## SDK: оболочка, реестр инструментов и нативный бэкенд (Phase 1)

- `sdk/` — приложение SDK на R2D (RmlUi): проекты, Asset Browser, каталог
  инструментов из корневого `sdk_tools.json`, запуск и сборка игры,
  документация, панель диагностик. Запуск: `./build/russiano2d --game sdk`.
- `r2d-sdk` (`sdk/native`, чистый C): `tools`, `assets`, `project`, `projects`,
  `validate`, `run`, `build`; один JSON-объект на команду, диагностики со
  стабильными кодами. Описание — `docs/SDK.md`.
- `$.sdk` — мост инструментов (только при `"toolHost": true` в `project.json`):
  запуск `r2d-sdk` и движка фоновыми процессами без shell.
- RmlUi-интеграция: `$.ui.doc().value/setValue/content/attr/rect/click`,
  обработчики получают цель события (`targetKey`, `targetId`) — делегирование
  списков одним обработчиком. Прежние игры не затронуты.

## Документация под C → $

- Конституция, архитектура, правила агентов и справочник описывают схему
  C → `$`; справочник ядра — внутренний `docs/internal/NATIVE.md` (вместо
  `docs/API.md`, в релизный AGENTS.md не входит).
- В `$` добавлено то, что игра раньше брала из `engine.*`: `.angularVelocity()`,
  `.mass()`, `.allowSleep()`, `$.sound.channel(ch)`, `$.debug.render()`.
  Остаток сверки — `docs/TASKS.md` §13.

## Текст, тайлы, частицы и HUD в C

- `<text>`, статичные слои `<tilemap>`, частицы, `ui.label`/`ui.panel` и
  очередь подписей HUD собираются в C; кадр совпадает с JS-путём до байта.
- Release, 2000: текст 7,2 → 1,8 мс, `ui.label` 4,7 → 2,7, тайлмап 1,9 → 1,0,
  частицы 3,2 → 2,3. Тик виджетов — без обходов всего реестра.
- `$.debug.memory()` — факты о JS-куче (утечка или шум замера).

## Твины в C

- Простые твины (`.tween/.moveTo/.fadeTo/.scaleTo/.rotateTo`) со встроенной
  плавностью считает C: 2000 твинов — 0,04 мс за кадр, значения побитово как
  в JS. Таймеры тряски/вспышки/неуязвимости — тоже в C.
- Сценарии `$.tween(target)` без лишней работы в кадре: 2000 сценариев
  10,3 → 2,9 мс («JS итого», Release). Новая сцена стенда `move`.

## Дешёвые спавн и удаление узлов

- Индекс реестра строит C (`engine.nodes.buildIndex`); конструктор узла
  4,2 → 2,7 мкс (умолчания на прототипе, кэш цветов тега, быстрый `addClass`).
- `.remove()` по нескольким узлам чистит реестр одной уборкой; одиночное
  удаление ищет узел с конца. Пачка 200 спавнов и удалений на 2000 узлах —
  4,4 → 2,0 мс, `churn:2000` 14,5 → 3,4 мс (`HIGH_LEVEL_API_PERF.md` §0.6).

## C → $: нативные проходы кадра

- Синк тел, автособытия мира, наведение мыши, сортировка и сборка батча
  обычных узлов идут в C (`src/nodes.c`, `engine.nodes.*`) прямо над узлами `$`;
  особые узлы C отдаёт обратно в JS — кадр совпадает до байта.
- Release, 2000 узлов: спрайты 6,9 → 2,1 мс, тела 6,6 → 2,3, твины 10,3 → 4,2,
  `$.batch` 13,5 → 5,1 (`docs/HIGH_LEVEL_API_PERF.md` §0.5).
- Y-sort хук tilemap работает только при карте с `ysort` — раньше он
  обходил все карты перед каждым узлом.
- `$.debug.nativePasses(false)` — вернуть JS-проходы для сверки.

## C → $: игре виден только `$`

- `globalThis.engine` убирается после установки `$`; модули `src/highlevel`
  берут ядро из приватного `native.js`, загрузчик не отдаёт игре `r2d/*`,
  кроме `'r2d'`. Агентский `eval` видит `engine` на время вызова.
- Новое в `$` вместо прямых вызовов: `$.startScene`, `$.gfx.white`,
  `$.time.perfNow()`. Демки, `game/`, веб-сцена и фикстуры переведены на `$`.
- **Миграция:** `engine.startScene` → `$.startScene`, `engine.whiteSprite` →
  `$.gfx.white`, `engine.width/height` → `$.gfx.size()`, `engine.time` →
  `$.time.realNow()`, `engine.setCursor` → `$.input.cursor`, `engine.drawSprite`
  → `$.gfx.push.sprite`, `engine.log` → `$.log` (таблица — `docs/highlevel/native.md`).

## Имя технологии Re2DSprite

- Основной API $.re2dSprite и методы .re2d*, сцена re2dsprite.
- Название в демо и документации, руководство RE2DSPRITE_GUIDE.md.
- Старые API/сцена/пути/PNG совместимы; миграция данных не требуется.

## Изготовка Re2DSprite и полное руководство

- Двухзвенные руки: локти, ID предплечий 20/21, новая holdRifle,
  направление ствола вперёд и совмещение обеих кистей с сокетами АК.
- Модельный PNG-шаблон и руководство RE2DSPRITE_GUIDE.md: рисунок,
  карты, сетки, скелеты, клипы, подмены, сборка, сокеты и ограничения.
- Загрузка PNG 3072 согласована с компилятором и контрактом v2.

## Re2DSprite JSON, анимации и предметы

- Пользовательские поверхности samples/grid/loft, JSON скелеты и клипы,
  C-проекция по матрицам частей без зависимости от человеческих ID.
- High-level from/equip/rotAttach/rotDetach, сокеты, JSON-слои мимики и удержания,
  hot reload описания и анимаций. Шаблоны предмета и четвероногого животного.
- Отдельные PNG/JSON АК-47, пистолета и дробовика; G переключает предмет в демо.
- Native, JS, authoring и реальная проверка креплений/перезагрузки/владения.
  Формат и ограничения: [RE2DSPRITE_JSON.md](docs/RE2DSPRITE_JSON.md).

## Re2DSprite v1 — прототип головы из развёртки всего тела

- Один строгий PNG-атлас всего персонажа (`8N×8N`): базовый шаблон 512×512
  для разработчиков и заполненный по той же раскладке атлас Руси-тян.
- `$.re2dSprite`, `<rotsprite>`, `.re2dSpriteAtlas(path)`, `.re2dPose(yaw,pitch)`:
  нативный синтез головы и ушей в спрайт 64×64, полный yaw, pitch ±75°,
  nearest, pixel snapping, переиспользование текстуры и освобождение при
  удалении/hot reload. Области тела есть в PNG, но ещё не проецируются.
- Демо `--game demos --scene re2dsprite`: общий атлас, вращение стрелками,
  автоповорот и проверки pitch. Весь интерфейс — RmlUi.
- Проверки C с ASan/UBSan, JS и детерминированный агентский тест по пикселям.
  Спецификация: [RE2DSPRITE_V1.md](docs/RE2DSPRITE_V1.md).

## Экспорт в веб: движок в браузере (WebGPU)

Движок впервые собирается и **играется в браузере**: Emscripten + SDL_GPU с
бэкендом WebGPU (ветка PR libsdl-org/SDL#16020), шейдеры на WGSL, интерфейс
RmlUi работает как обычно. Полный разбор, грабли и ограничения —
[docs/WEB_EXPORT.md](docs/WEB_EXPORT.md).

### Добавлено
- **`web/export.py`** — экспорт игры в веб: `--game`, `--out`, `--index`,
  `--custom_loader` (своя HTML-страница), `--custom_image` (картинка экрана
  загрузки), `--force_play` (старт без кнопки «Играть»).
- **`web/shell.html`** — загрузочная страница в стиле Godot: маскот, полоса
  прогресса, «Инициализация P2D», кнопка «Играть» (она же жест, без которого
  браузер не включает звук), фуллскрин, сцена 16:9 и журнал в DOM для автотестов.
- **`tests/web/smoke.py`** — дымовой прогон веб-сборки: сервер, страница,
  вердикт по маячкам движка (`first-frame`, `shutdown: …`, ошибки WebGPU).
- **`shaders/wgsl/`** — WGSL-варианты всех встроенных шейдеров: WebGPU не
  принимает ни SPIR-V, ни MSL.
- **`third_party/patches/rmlui-webgpu.patch`** — две правки бэкенда RmlUi:
  WGSL-ветка (без неё `Invalid shader format` и интерфейса нет вовсе) и
  порядок освобождения transfer-буфера (без неё атлас глифов пуст — интерфейс
  рисует геометрию без текста). Патч применяется сам на конфигурации веба.
- **`site/play/`** — играбельные демо на сайте, страница `/play/`.

### Изменено
- **Шрифт по умолчанию — Open Sans** (`assets/fonts/OpenSans-Regular.ttf`):
  семейство выбирается по наличию кириллицы, а не «первый файл по алфавиту» —
  из-за этого русские подписи молча не рисовались.
- **Лаунчер демо — на RmlUi и адаптивный**: размеры в `vh`, карточки и кнопки
  тянутся flex'ом, вёрстка одинакова на 1280×720 и 1920×1080. Платформер из
  меню убран (запускается как `--scene platformer`), фон меню и музыка —
  новые (`witch_lobby.png`, `lobby_groove.mp3`).
- **Заглушки подсистем** пополнены (`shader_live_stub.c`, `r2d_gui_load_markup`),
  `http.h`/`render.h` берут типы QuickJS из `quickjs.h` — сборки с выключенными
  подсистемами и конфигурации с nan-boxing больше не падают.
- **Длительность звука в журнале** считается в секундах, а не в кадрах/1000.

### Проверено
- нативная сборка и `tools/run_tests.py`: 82 теста, все зелёные;
- веб: демо-меню и «Типичная ночь в Мытищинском лесу» играются в Chrome,
  интерфейс RmlUi виден, ошибок WebGPU в журнале нет.
## DevTools: инспектор сущностей на RmlUi

Первый срез инструмента разработчика (ROADMAP, фаза 8): список сущностей →
выбор → свойства → копирование селектора. Открывается по **F2**.

### Добавлено
- **`$.devtools`** — панель на **RmlUi**: `open()/close()/toggle()/isOpen()`,
  `select(uid)` / `selectBy(sel)`, `selector()`, `panel()` (машиночитаемое
  состояние), `refresh()`. Данные — из `$.agent.nodes('*')`, той же инспекции,
  что у агента и команд `query`/`inspect`.
- **`engine.ui.loadMarkup(name, markup)`** — документ RmlUi из строки разметки.
  Нужен инструментам, которые строят интерфейс кодом и не кладут `.rml` в игру.

### Как устроено
- панель собирается кодом (маркап в памяти), ImGui не используется — закон UI
  соблюдён ([UI_RMLUI_LAW.md](docs/UI_RMLUI_LAW.md));
- обработчики вешаются один раз при открытии: RmlUi уносит слушателей вместе с
  элементом, поэтому разметка не перерисовывается — обновляются тексты и
  классы;
- содержимое обновляется раз в 6 кадров; закрытая панель не стоит ничего,
  кроме проверки F2;
- панель только читает мир и не становится источником истины.

### Проверено
- `tests/js/devtools_test.mjs` — состояние и выбор без GUI;
- `tests/agent/devtools_test.py` — в движке: документ создаётся, F2
  переключает, выбор даёт селектор, мир не тронут.

## Реактивные запросы: `$.watch`

Вход и выход по **составу выборки** (ROADMAP, фаза 7): узел попал под селектор
или перестал подходить — удалён, сменил класс, вышел из `within()`.

### Добавлено
- **`$.watch(sel, { onEnter, onLeave, immediate })`** — наблюдение; возвращает
  handle `{ stop, size, active, selector }`; `$.watch.count/list/clear` —
  диагностика и снятие.
- Сравнение по `uid`: пересозданный узел — новое вхождение, удалённый не
  путается с чужим. По умолчанию первый кадр молчит (`immediate: true` — иначе).
- Кадровый шаг встроен в цикл `$` после триггеров; кадр без наблюдений ничего
  не стоит.

### Проверено
- `tests/js/watch_test.mjs` — вход/выход, `immediate`, пересоздание узла,
  `list/count/clear`;
- `tests/agent/watch_test.py` — в движке: удаление тела даёт выход, новый враг —
  вход, `clear()` прекращает события.

## Утверждения в понятиях мира: `$.expect`

Тест и агент формулируют ожидания селектором, а не самодельным `eval`
(ROADMAP, фаза 6).

### Добавлено
- **`$.expect(селектор)`** — утверждения: `.exists()`, `.empty()`, `.count(n)`,
  `.hp(n)`, `.prop(имя, значение)`, `.positionNear(x, y, eps?)`,
  `.state(значение)`. Каждое идёт через `$.test.check`, поэтому попадает и в
  общий счётчик (`results()`/`report()`), и в снимок агента.
- **Структурные детали провала**: `$.test.results().details` и
  `state.tests.details` содержат `{ message, subject, prop?, expected, actual }` —
  падающий тест оставляет разбираемый артефакт, а не строку в логе.

### Проверено
- `tests/js/expect_test.mjs` — 5 наборов без движка (успех, провал, детали,
  пустая выборка, разные виды субъекта);
- `tests/agent/expect_test.py` — в движке: утверждения, общий счётчик, детали
  в снимке агента, продолжение работы после провала.

## Запросы в радиусе: `$().within()` и нативный `engine.queryCircle`

Первый нативный конвейер запросов (ROADMAP, фазы 1–2): выборка «кто рядом с
целью» больше не перебирает все узлы в JS.

### Добавлено
- **`$('.enemy').within('#hero', 500)`** — метод обёртки: узлы, чей центр не
  дальше радиуса от цели. Цель — селектор, узел, обёртка или точка `{x, y}`.
  Узлы с телом отбирает `engine.queryCircle` (broadphase Box2D), узлы без тела
  (спрайты, зоны, свет) проверяются по координатам и не теряются. Порядок
  результата — порядок выборки; пустая цель и нечисловой радиус дают пустую
  выборку, а не исключение.
- **`engine.queryCircle(x, y, radius, mask)`** — низкий уровень: `Int32Array`
  id тел, отсортированный по расстоянию (при равенстве — по id): результат
  воспроизводим и не зависит от порядка обхода broadphase.
- **`engine.queryStats()`** и **`$.debug.queryStats()`** — диагностика
  последнего запроса: `{ calls, candidates, results, ms, cap, truncated }`.
- **`withinRadius()`** в ядре — чистая фильтрация, проверяемая без движка.
- **Команды агентского протокола `query` и `inspect`** (ROADMAP, фаза 3):
  `{"cmd":"query","sel":".enemy","limit":10}` → список сущностей,
  `{"cmd":"inspect","sel":"#hero"}` → одна сущность (или `null`). Селектор
  разбирает тот же JS-код, что и `$.agent.node/nodes`, — движок только перевозит
  строку, поэтому у агента, DevTools и игры одна реализация поиска.
- **`engine.setAgentQuery(fn)`** — хук, через который игра отдаёт эту
  инспекцию; высокоуровневое API ставит его само.
- **`$.agent.nodes(sel, limit)`** — предел списка.
- **Обёртки клиента** `Agent.query(sel, limit)`, `Agent.inspect(sel)` и
  `Agent.profile(sel, x, y, radius)`.
- **Команда `profile`** (ROADMAP, фаза 4): `{"cmd":"profile","sel":".enemy",
  "x":100,"y":100,"radius":500}` → число сущностей по селектору, статистика
  нативного поиска (`candidates`, `results`, `ms`, `cap`, `truncated`), зоны
  кадра и честный `allocations: null` (движок аллокации не измеряет).
- **`--record <файл>` и `--replay <файл>`** (ROADMAP, фаза 5): запись ввода
  кадра и воспроизведение вместо настоящего ввода. Формат — JSON-строки с
  версионированным заголовком (версия движка, игра, `--fixed-dt`, `--seed`);
  файл чужой версии отвергается с объяснением. Мир не сериализуется: при том
  же зерне и шаге симуляция обязана прийти туда же. Записаны клавиши, мышь и
  колесо; касания, геймпады и текст IME — нет (честное ограничение).

### Изменено
- **`engine.queryPoint`, `engine.queryBox`, `engine.keysPressed`,
  `engine.keysReleased` возвращают настоящий `Int32Array`** — как и было
  обещано в internal/NATIVE.md; раньше это был обычный массив. Для кода с индексным
  доступом и `.length` ничего не меняется.
- **Кадр ImGui больше не начинается, пока оверлей скрыт.** Раньше он шёл
  каждый кадр ради очереди текста, которая давно мертва (игровой текст рисуется
  спрайтами глифов). Теперь ImGui существует только когда разработчик открыл
  оверлей по `F1`/`--overlay`/`$.debug.on()` — как и обещает
  [UI_RMLUI_LAW.md](docs/UI_RMLUI_LAW.md).
- **`engine.drawText.length` = 9** — по числу объявленных параметров
  (регистрация биндинга отставала: 6).

### Добавлено
- **`--version`** — печатает версию движка и выходит (её же печатает `--help`).
- **`engine.pixel_width` / `engine.pixel_height`** — физический размер буфера
  кадра (Retina/HiDPI); в доке они были обещаны, но не выставлялись.

### Исправлено
- **Версия движка одна на проект.** `R2D_VERSION_STRING` приходит из CMake
  (`PROJECT_VERSION`), а не зашита в `r2d.h` как `"0.1.0"`; строка идёт в
  `--help`, заголовок окна, событие `ready` агента и User-Agent HTTP.
- **`engine.seed` без `--seed` равен `12345`** — ровно тому зерну, от которого
  работает `$.random` (было `0`: заголовок реплея расходился с фактическим
  миром).

### Документация
- **Появились законы и направляющие документы:** [docs/PHILOSOPHY.md](docs/PHILOSOPHY.md),
  [docs/UI_RMLUI_LAW.md](docs/UI_RMLUI_LAW.md),
  [docs/AGENT_IMPLEMENTATION_RULES.md](docs/AGENT_IMPLEMENTATION_RULES.md),
  [docs/ROADMAP.md](docs/ROADMAP.md), [docs/TESTING.md](docs/TESTING.md),
  [docs/DEVTOOLS.md](docs/DEVTOOLS.md), [docs/RECORD_REPLAY.md](docs/RECORD_REPLAY.md),
  [docs/R2D_R3D_CONVENTIONS.md](docs/R2D_R3D_CONVENTIONS.md). Все они
  автоматически попадают в релизный `AGENTS.md`; правила агентов идут в нём
  первыми (`AGENTS_DOC_ORDER` в [tools/release.py](tools/release.py)).
- **Гейт документации требует правила агентов**: `docs/AGENT_IMPLEMENTATION_RULES.md`
  добавлен в обязательный список (`tools/dsh-russiano2d-docs-gate`).
- **Пройдена сверка документации с кодом** (четыре независимых аудита):
  починены устаревшие числа и версии, восстановлены сигнатуры `$.world.spawn/
  castShape/query/background`, `.collisionLayer` заменён на существующие
  `.layerBits()/.mask()`, примеры `map/filter/every/some` приведены к
  `(индекс, обёртка)`, цепочка `$.store.file().save().load()` разделена,
  снят остаток заглушки в `docs/highlevel/render.md` §3, обновлён список
  занятых имён в `docs/highlevel/_CONTRACT.md`, добавлены разделы про зоны и
  недостающие вызовы (`$.agent.install()`, `.sleeping()`, `.bullet()`,
  `engine.audio.*`, `engine.pixel_width/height`).

### Проверено
- полный прогон `python3 tools/run_tests.py` — **79/79 ok, 0 fail, 0 skip**
  (283.8 с), включая новые тесты ниже;
- `tests/js/*_test.mjs` — 79 наборов под QuickJS, 0 провалов;
- `tests/agent/highlevel_within_test.py` — 28 проверок в движке (радиус и
  граница, узлы без тела, цели точка/узел/обёртка, нативный порядок,
  диагностика, `remove()` поверх выборки), фикстура `tests/fixtures/within`;
- `tests/agent/agent_query_test.py` — проверки команд `query`/`inspect`/`profile`
  (селекторы, предел, порядок реестра, совпадение с `$.agent.node/nodes`,
  диагностика запроса, понятные ошибки);
- `tests/agent/replay_cli_test.py` — запись ввода, версионированный заголовок,
  воспроизведение в ту же позицию, отказ на чужую версию формата
  (фикстура `tests/fixtures/input_walk`);
- `tests/js/within_test.mjs` — 6 проверок чистой фильтрации без движка.

## Lightmap: свет в отдельной текстуре, мягкая кромка и независимость от порядка

Свет перестал быть треугольниками внутри сцены: он копится в отдельной текстуре
половинного разрешения и накладывается на кадр одним полноэкранным проходом.
Отсюда сразу три вещи — независимость от порядка отрисовки, мягкая кромка без
лишних лучей и половинная стоимость заливки.

### Добавлено
- **`$.gfx.light.map({ on, intensity, soft })`** — световая карта: свет в
  отдельной текстуре. `soft` добавляет размытие (полутень на кромке тени),
  `intensity` — множитель силы света. Есть `$.gfx.light.mapSupported()` и
  запрос состояния без аргументов.
- **`engine.submitLightTriangles(vertices, count?, blend?)`** — низкоуровневый
  канал света: тот же формат вершин, что у `submitTriangles`, но свой список и
  свой проход.
- **`engine.lightMap(on?, intensity?, soft?)`** — режим карты света для C-стороны.
- **`shaders/light_map.frag.glsl`** — композит карты света (аддитивное
  смешивание); в `cmake/Shaders.cmake` добавлена одна строка регистрации.
- Свет в карте опционален: выключенная карта (или кадр в render target игры)
  рисует свет прямо в сцену, как раньше, — свет не теряется ни в одном режиме.

### Изменено
- `<light>` и `<lightarea>` с включённой картой уходят в отдельный слой
  (`submitLightTriangles`). `$.gfx.draw.glow` остаётся в сцене: это эффект, а не
  источник света.
- Порядок кадра: свет → текстура света → проход сцены → композит света →
  интерфейс. С включённой картой `.punch(true)` не нужен — свет и так ложится
  поверх тумана и темноты.
- `r2d_render_draw_world` умеет дорисовать свет из своего списка, если карта не
  применилась: потерять свет нельзя.
- `r2d_batch_triangles` и `r2d_batch_light_triangles` делят общую раскладку
  вершин (`r2d__pack_triangles`), а пакеты треугольников рисует один помощник
  (`r2d__draw_tri_batches`).
- Документация: `docs/highlevel/render.md` §3.0.5 (световая карта),
  `docs/internal/NATIVE.md` (новые биндинги).

### Тесты
- `tests/agent/highlevel_light_test.py`: карта включается и выключается, свет в
  ней не теряется (207 против 207), тени работают, проход считается
  (`renderInfo().passes`), размытие смягчает кромку (1.6 → 3.8), свет с картой
  прорезает темноту.

---
## Свет: кэш границ, отсечение по радиусу, темнота и мягкие тени

Свет перестал считать одно и то же каждый кадр, а у сцены появился слой
темноты: ночь, подвал и пещера теперь делаются через `$.gfx.light.ambient`, а
свет с `.punch(true)` её прорезает.

### Добавлено
- **`$.gfx.light.ambient({ level, color })`** — темнота поверх кадра
  (multiply). Рисуется после мира, тумана и свечения фонарей, но **до** света с
  `.punch(true)`: получается ночной город, где всё в полутени, а лампы светят в
  полную силу. Есть `.off()`, `.params()`, `.on()`.
- **`.shadowSoft(rays, deg)`** у `<light>` и `<lightarea>` — мягкая кромка тени:
  источник считается не точкой, а маленьким диском, поэтому на кромке
  препятствия появляется полутень. По умолчанию 1 — прежняя резкая кромка.
- **`$.gfx.light.stats()` / `.resetStats()`** — счётчики за кадр: сколько
  границ посчитано (`built`), сколько взято из кэша (`cached`), сколько отрезков
  дошло до света из всех, что лежат в реестре (`culled` / `considered`).
- **`engine.light.prepare(segments)`, `preparedCount()`, `preparedMaxPoints()`,
  `visibilityPrepared(x, y)`** — подготовленный набор препятствий: разрезание
  O(n²) делается один раз, а не на каждый вызов полигона; оценка буфера
  становится линейной (40 против 152 на четырёх отрезках коробки).

### Изменено
- **Границы теней кэшируются на узле.** Они зависят от положения источника,
  веера, набора препятствий и версии реестра, но **не от камеры**, — поэтому
  статический фонарь считается один раз, а не каждый кадр. Площадной свет
  кэширует каждую свою точку отдельно.
- **Препятствия разложены по клеткам** (128 единиц мира): свету достаются только
  те отрезки, что попали в его радиус, а не весь реестр уровня. Индекс
  перестраивается при изменении реестра.
- **`lightBoundary()` принимает `count` и `soft`** — набор отрезков читается из
  переиспользуемого буфера без копии, а `soft` даёт полутень. Дальность каждого
  подлуча проецируется на главное направление, поэтому ровная стена перед
  светом не «раздувается».
- **Веер света без лишней тригонометрии**: косинусы, синусы и кромка конуса
  считаются один раз на веер, а не на каждое кольцо (было 7× на луч). Буферы
  переиспользуются — в кадре нет `new Float64Array` на каждый свет.
- **`$.gfx.light.polygon(x, y)`** готовит набор по версии реестра и считает
  полигон из подготовленного набора, а не режет отрезки заново.
- Документация: `docs/highlevel/render.md` §3.0.3–3.0.4 (темнота и
  производительность света), `docs/internal/NATIVE.md` §12 (подготовленный набор).

### Тесты
- `tests/js/light_test.mjs`: индекс по клеткам (выборка, длинные отрезки, дубли,
  пустой реестр), отсечение по `count`, мягкая кромка и ширина полутени через
  `spread` — 44 проверки.
- `tests/agent/highlevel_light_test.py`: кэш границ (`built == 0` на прогретой
  сцене), отсечение далёких препятствий по радиусу, полутень по пикселям,
  темнота и свет, который её прорезает, подготовленный набор из C.

---
## Свои шейдеры в рантайме: таблица §28 закрыта

Последний пункт раздела «Ограничения (честно)» из `docs/HIGH_LEVEL_API.md`
закрыт: игра может компилировать собственные фрагментные шейдеры во время
работы. Таблица §28 заменена списком ограничений по устройству движка.

### Добавлено
- **`$.gfx.defineShader(имя, исходник)`** — компиляция GLSL в рантайме:
  glslang (GLSL → SPIR-V) и SPIRV-Cross (SPIR-V → MSL для Metal). Те же
  библиотеки, которыми `cmake/Shaders.cmake` собирает встроенные шейдеры,
  теперь линкуются в движок (`src/shader_live.cpp`).
- **Шапка шейдера фиксирует контракт**: `u_texture` (set 2 binding 0),
  `NodeParams { vec4 p; vec4 c; } u` (set 3 binding 0), входы `v_texcoord` /
  `v_color`, выход `o_color`. Показать её игре — `$.gfx.shaderPreamble()`.
- **Свой шейдер работает как встроенный эффект**: `.shader(имя)`,
  `.shader(имя, { p1, p2, p3, color })`, `.shaderParam(...)`, общая пакетная
  отрисовка. Конвейеры создаются на все четыре режима смешивания.
- **Диагностика**: `$.gfx.shaderError()` возвращает текст glslang,
  `$.gfx.shadersSupported()` — есть ли компилятор в сборке,
  `$.gfx.userShaders()` — список зарегистрированных имён. Повторная
  регистрация с тем же именем перекомпилирует шейдер (hot reload).
- **Опция сборки `R2D_ENABLE_LIVE_SHADERS`** (`ON` по умолчанию): `OFF`
  убирает компилятор из бинарника, оставляя встроенные эффекты узла.

### Изменено
- `engine.defineSpriteFx(index, kind, p1, p2, p3, color, userShader)` — седьмой
  аргумент: слот пользовательского шейдера (0 — встроенный эффект).
- `docs/HIGH_LEVEL_API.md` §28: вместо таблицы «чего нет» — список
  ограничений по устройству (DXIL/D3D12, только фрагментные шейдеры,
  синхронная компиляция, render target как цель кадра).
- Тесты: юнит-тесты `tests/js/sprite_fx_test.mjs` (разбор параметров
  пользовательского шейдера, проверка тела до компилятора) и агентские
  проверки в `tests/agent/highlevel_render_test.py` — компиляция, ошибка
  компиляции, перекраска узла своим шейдером (6400 px зелёным).

---

## Честный bloom, шейдеры узлов, render target, DSP-эффекты и реверб-шины

Закрыты оставшиеся пункты таблицы «Ограничения (честно)» из
`docs/HIGH_LEVEL_API.md` §28: свечение, шейдеры на узел, render target игры и
канальные DSP-эффекты с реверб-шинами. В таблице осталась одна строка —
рантайм-компиляция произвольного GLSL.

### Добавлено
- **Честный bloom** (`shaders/bloom_pre.frag.glsl`, `shaders/bloom_blur.frag.glsl`):
  яркий проход с понижением разрешения (порог с мягким коленом), два
  разделяемых размытия и композит в пост-обработке. Раньше свечение было
  восемью выборками в одном проходе и потому выглядело контуром, а не светом.
  Параметры `bloom_threshold` и `bloom_radius` у `$.gfx.post({...})`,
  признаки `bloom_ready`/`bloom_buffers` у `engine.getPost()` и
  `engine.renderInfo()`. Если буферы не создались, движок честно откатывается
  на прежний однопроходный вариант.
- **Шейдеры узлов** (`.shader('flash' | 'dissolve' | 'chroma' | 'wave', {…})`,
  `.shaderParam(имя[, значение])`, `$.gfx.fxKinds()`): эффекты поверх спрайта
  отдельными конвейерами (`shaders/sprite_fx.frag.glsl`) и таблицей параметров
  на кадр. Узлы с одинаковым эффектом и параметрами рисуются одним вызовом;
  узлы без шейдера идут прежним конвейером.
- **Render target игры** (`$.viewport`): `create/size/bind/bound/sprite/draw/
  destroy/count`, `engine.viewport.*`. Кадр рисуется в свою текстуру (target),
  прошлый кадр остаётся в history-текстуре и доступен как спрайт — так делают
  шлейфы, накопление и порталы.
- **DSP-эффекты каналов и шин** (`src/audio_fx.c`): кроме `lowpass` и `echo`
  появились `highpass`, `tremolo`, `bitcrush`, `ringmod` и `reverb`.
  `$.audio.effects()` берёт список из движка.
- **Реверб-шина с посылом**: у шины (группы) или канала может быть свой хвост,
  в который уходит доля `send` её микса; остальные шины и мастер остаются
  сухими (`engine.audio.setGroupReverb/setChannelReverb`,
  `$.audio.effect(name, 'reverb', { send, room, damp, width })`).
- **Тесты**: офлайн-тест DSP `tests/audio/fx_test.c` (29 проверок, собирается в
  `r2d_audio_fx_test`), юнит-тесты `tests/js/sprite_fx_test.mjs` и
  `tests/js/shape_spec_test.mjs`, пиксельные проверки bloom и шейдера узла в
  `tests/agent/highlevel_render_test.py`, проверки эффектов и реверб-шин в
  `tests/agent/highlevel_audiobus_test.py`, render target там же.

### Изменено
- **`r2d_render_draw_world/draw_ui/draw` принимают командный буфер**: юниформы
  шейдеров узлов пушатся во время отрисовки, а не после.
- **`engine.submitSprites(transforms, colors, count, blend, fx)`**: пятый
  аргумент — индексы шейдеров узлов; без него поведение прежнее.
- **`bootstrap.js` показывает настоящую причину падения установки `$`**:
  раньше исключение внутри `createApi()` уносило контекст, и в журнале
  оставалось «bootstrap.js не выставил globalThis.$».

---

## Коллизии по слоям, свип формы, частицы-цели и игровое время (§28 справочника)

Закрыты шесть пунктов таблицы «Ограничения (честно)» из
`docs/HIGH_LEVEL_API.md` §28: слои и маски коллизий, свип формы, частицы как
цели, габарит агента у `<tilemap>`, виброотклик, пауза и масштаб времени для
клипов. Остались шейдеры, render target, bloom и DSP-шины — это этап C.

### Добавлено
- **Слои и маски коллизий** (`b2Filter`): `.layerBits(bits)`, `.mask(bits |
  узел | селектор)`, `.collidesWith(цель[, true|false])` — раньше это были
  заглушки в `api.js`, которые возвращали обёртку и ничего не делали. Маски и
  группа Box2D живут на теле, меняются без пересоздания (`r2d_physics_set_filter`,
  `engine.setBodyFilter/getBodyFilter`), переживают `.size()` и prefab.
  Запросы получили слои: `$.world.raycast/bodyAt/bodiesIn/raycastAll/lineOfSight`
  и `engine.raycast/queryPoint/queryBox` принимают `mask`; `.onFloor()`/`.onWall()`
  уважают маску узла.
- **Свип формы (аналог `ShapeCast2D`)**: `r2d_physics_cast_shape` на
  `b2World_CastShape`, `engine.castShape(opts)`, `$.world.castShape(from, to,
  {w,h} | {radius} | {capsule:[r,halfH]})` и метод узла `.sweepTo(цель, opts)`.
  Луч отвечает «что на линии», свип — «пролезет ли объём»: им проверяют проёмы
  и задевание углов плечом.
- **Частицы как цели**: `$.particles.at/inBox/raycast/hit`,
  `$.world.particlesAt/particlesIn` и флаг `{ particles: true }` у
  `$.world.raycast`. Попадание убивает частицу (`hit(..., {kill:false})` —
  если судьбу решает игра).
- **Габарит агента у `<tilemap>`**: `.agentRadius(r)`, `.agentSize(w, h)`,
  `.fitsAt(x, y, opts)` и `.sample(x, y, opts)` — проверка «пролезу ли я сюда
  телом» по сетке, без физики; тела коллизий остаются клетка в клетку.
- **Виброотклик**: `engine.padConnected/padRumble/padRumbleTriggers` на
  `SDL_RumbleGamepad`, `$.input.rumble(opts)`/`stopRumble()`/`rumbleSupported()`.
  Вызов возвращает `false`, если геймпада нет: игра узнаёт, что тряска ушла в
  пустоту, а не считает, что игрока тряхнуло.
- **Юнит-тесты** (qjs): `tests/js/shape_spec_test.mjs`,
  `tests/js/particle_hit_test.mjs`, `tests/js/tilemap_agent_test.mjs`,
  `tests/js/input_rumble_test.mjs`.
- **Агентские тесты**: `tests/agent/highlevel_collision_test.py` (слои, маски,
  свип, prefab), `tests/agent/highlevel_rumble_test.py`; проверки частиц-целей
  в `highlevel_particles_test.py`, габарита — в `highlevel_tilemap_test.py`,
  времени — в `highlevel_anim_test.py` и `highlevel_animplayer_test.py`.

### Изменено
- **Клипы, машины состояний и таймлайны тикают игровым временем**
  (`$.time.delta()`), а не сырым `dt`: `$.time.pause()` и `$.time.scale()`
  теперь останавливают и ускоряют анимацию персонажа, а не только твины.
  Интерфейс (экраны, диалоги, виджеты) остался на реальном времени — кнопки
  обязаны работать на паузе.
- **`opts.ignore` у лучей и свипов** наконец принимает узел, обёртку и массив,
  а не только селектор: прежний код прогонял аргумент через `query()`, который
  понимает лишь строку, поэтому `ignore: $('#hero')` молча давал пустой список.
- **`$.world`**: `bodyAt`/`bodiesIn` принимают `opts.mask`,
  `raycastAll` фильтрует узлы по слоям.
- **prefab/save**: `layerBits`, `collisionMask` и `collisionGroup` пишутся и
  читаются через `set()`, поэтому фильтр доезжает и до тела.

---

## Индекс реестра: один проход вместо двадцати (P2 аудита `$`)

### Изменено
- **Индекс реестра в ядре `$`** (`src/highlevel/core.js`): один обход
  `ctx.nodes` на версию реестра строит карты `byTag`/`byClass` и срезы по
  признакам (`ui`, `tr`, `controls`, `anim`, `clip`, `parallax`, `zones`,
  `body`). Раньше каждая подсистема отвечала на вопрос «есть ли в мире мои
  узлы?» собственным проходом по реестру: сводка кэшировалась на версию
  реестра, но в сцене, где узлы рождаются и умирают каждый кадр, версия
  меняется каждый кадр — и десяток подсистем делал десяток полных проходов.
  Срезы — снимки, поэтому обход не ломается от создания и удаления узлов
  внутри него.
- **Тики подсистем ходят по своим срезам, а не по всему миру**:
  `tickAnim`, `tickParticles`, `tickTilemap`, `tickLayers`, `tickTriggers`,
  `tickWidgets`, `tickI18n`, `$.ui._tick`, `animateSprites`, `applyControls`,
  `world.sync` (срез `body` — в сцене без физики прохода больше нет).
- **`query()`**: структурный селектор (`.mob`, `enemy.mob`, `*`) берётся из
  индекса целиком и кэшируется на версию реестра, сложный — идёт по якорю
  (ведущий тег/класс терма), а не по всему миру. Селекторы по полям, которые
  меняются без изменения реестра (`:alive`, `[hp<5]`), по-прежнему считаются
  по узлам, а не по кэшу.
- **Контракт подсистем** (`docs/highlevel/_CONTRACT.md`) переписан на новый
  индекс: `nodesByTag`, `nodesByClass`, `nodesWithFacet`, `facetCount`,
  `liveNodes`. `registrySummary()` остался для собственных признаков модуля.

### Добавлено
- **Юнит-тесты индекса** — `tests/js/registry_test.mjs` (8 проверок):
  совпадение срезов с честным проходом по реестру, снимки, удалённые узлы
  (в том числе внутри `$.batch`), поведение `query` с якорем и с `:alive`.
- **Микрозамер раскладки данных** — `tools/bench_storage.mjs`: массив
  объектов против `Float32Array`-SoA и обычного массива на законе движения
  частицы. Нужен, чтобы решать про пункт 21 плана P2 по числу, а не на глаз
  (вывод — в `docs/HIGH_LEVEL_API_PERF.md` §0.4).
- **§0.4 в `docs/HIGH_LEVEL_API_PERF.md`**: замеры «до/после», таблица правок
  и цена решения (перестройка индекса в сценах массового спавна/удаления).

### Производительность (Debug, стенд `tools/bench_highlevel.py`, логика кадра)
- `$('.mob')` в кадре, 1000 узлов: 4,61 → 2,49 мс; обход среза: 3,27 → 1,37;
  цепной метод: 3,54 → 1,67; `$('#id')`: 1,41 → 0,85.
- 1000 спрайтов: 1,31 → 0,85 мс; 5000 спрайтов: 6,05 → 4,35.
- На 5000 узлов: `$('.mob')` 21,9 → 12,4 мс, обход среза 16,8 → 7,6.
- Цена: сцены массового спавна/удаления (`churn`/`batch`) платят за
  перестройку индекса — +0,25 мс и +0,02 мс на 1000 узлов, на 5000 после
  правок перестройки даже −2 %; удаление без `$.batch` по-прежнему O(K·N),
  и это лечится `$.batch` (пункты 14–15, §0.3). Подробности — §0.4.

## Три демо вместо девяти, скриншоты и CI публикации

### Изменено
- **Демо-проект сокращён до трёх сцен** — по одной на слой движка:
  `platformer` (Box2D и анимация), `shooter_witch` (свет, частицы, волны),
  `russi_vn` (`$.timeline` и интерфейс на RmlUi). Удалены `arena`, `bsp`,
  `gallery`, `light`, `physics`, `shooter25d` вместе со своими `.rml`/`.rcss`:
  они дублировали то, что показывают оставшиеся, и тянули ассеты.
- **Лаунчер** больше не показывает под-сцены: меню «Ведьмы» (`witch_menu`)
  скрыто из списка, а её кнопка ведёт в это меню (в бой — `--scene shooter_witch`).
  Подсказки под кнопками укорочены и больше не вылезают за панель.
- **Скриншоты в README и docs/demos.md** пересняты под три демо и меню;
  старые (удалённых сцен) убраны. Обновляются одной командой —
  `tools/make_screenshots.py` (агентский режим, без рук).
- **У каждой демки в папке — README** «что внутри и как собрать такое же»
  (`demos/platformer/README.md`, `demos/shooter_witch/README.md`,
  `demos/russi_vn/README.md`): правило проекта для всех новых демо.

### Добавлено
- **CI публикации без сборки**: `.gitverse/workflows/publish-dist.yaml` и
  `.gitlab-ci.yml` берут архивы из `dist/` и создают релиз — ни компиляции,
  ни зависимостей. На GitLab релиз делает встроенный `release-cli`
  (авторизация — штатный `CI_JOB_TOKEN`, секретов не нужно); на GitVerse
  нужен `RELEASE_API_KEY`, и без него job не падает, а сообщает, что
  публиковать нечем. Сборка остаётся локальной (`tools/autobuild.py`).

## Визуальная новелла: подсистема `$.timeline` (AnimatedTimelineScene2d)

### Добавлено
- **`$.timeline` — таймлайн-сцены для диалогов и визуальных новелл**
  (`src/highlevel/timeline.js`). Сцена описывается одним массивом «битов»:
  реплика, выбор, смена локации, поза героя, вход/выход, акцент, тряска
  экрана, вспышка, затемнение, наезд камеры, музыка, флаг, ветка `if`,
  метка `goto` и концовка. Текст, печатная машинка и выборы отданы `$.dialog`
  — таймлайн отвечает за то, что происходит вокруг текста.
  Справочник — [docs/highlevel/timeline.md](docs/highlevel/timeline.md).
- **`$.animatedTimelineScene2d(spec)`** — то же объявление литеральным именем
  типа сцены: возвращает объект управления прогоном.
- **Управление и наблюдаемость**: `$.timeline.play/stop/next/choose/goto/
  location/pose/auto/speed`, события `start/beat/say/choice/location/ending/end`
  (и они же глобально как `timeline:*`), снимок `$.timeline.state()` для
  агента и тестов: локация, поза, ожидание, число битов, флаги, концовка.
- **Концовки**: бит `{ ending }` ставит флаг `ending:<id>` в `$.store`,
  показывает полноэкранную карточку и переживает перезапуск — прогресс новеллы
  не теряется.
- **Демо «Руси-тян: Бака!»** (`demos/russi_vn/`): одна героиня, пять
  локаций, семь поз, дыхание и акценты, три выбора с флагами, две концовки,
  тряска экрана, вспышки, «руси-метр» и авто-режим чтения. Кнопка в меню демо,
  `--scene russi_vn`. Прогресс новеллы лежит в своём файле `demos/vn_save.json`
  и не подмешивается в сохранение основной игры. Инструкция «как собрать такую же новеллу» —
  [demos/russi_vn/README.md](demos/russi_vn/README.md).
- **Инструменты**: `tools/make_vn_sprites.py` (альфа, общая рамка поз —
  смена позы не двигает героя), `tools/make_vn_backgrounds.py` (локации
  процедурно + CC0-кадры), `tools/vn_playthrough.py` (агент проходит новеллу
  до концовки и снимает скриншоты ключевых моментов).
- **Реплика может рисоваться RmlUi** (`dialogView`): перенос строк по ширине
  блока, шрифт, рамка и `:hover` — на стороне RmlUi, а печатная машинка,
  выборы и клавиатура остаются за `$.dialog`. Демо-новелла переведена на
  RmlUi целиком: реплика (`demos/ui/vn-dialog.rml`), руси-метр, индикатор
  авто-режима, подсказка и табличка локации (`demos/ui/vn-hud.rml`).
- **Озвучка реплик** (опция `voice`): файл на реплику, имя = id её узла
  (`<dir>/<id>.mp3`), нет файла — реплика идёт молча. Список реплик для записи
  голоса отдаёт `$.timeline.lines()`. Для новеллы подготовлены
  `demos/russi_vn/voice/lines_for_minimax.txt` (49 реплик) и карта `lines.json`.
- **Озвучка новеллы записана и подключена**: 49 реплик Руси-тян (MiniMax,
  `speech-2.8-hd`) разложены по `demos/russi_vn/voice/tlN.mp3`, 3,3 МБ. В
  авто-режиме реплика не перебивается, пока голос звучит.
- **Нарезка озвучки**: `tools/vn_voice_slice.py` — режет сгенерированный файл
  по паузам, сверяет число кусков с числом реплик и раскладывает их как
  `<id>.mp3`; при несовпадении ничего не пишет и показывает, что подкрутить.
  Для записи подготовлены `demos/russi_vn/voice/lines_for_minimax.txt`
  (реплики через паузу `<#2.5#>`) и `lines_clean.txt` (без маркеров).
- **Музыка новеллы**: два трека автора проекта (`vn_tension.mp3`,
  `vn_afternoon.mp3`, из WAV 28 и 29 МБ сжаты в 2,9 МБ) привязаны к локациям.
- **Исправлен перенос строк в диалогах движка**: `$.font.measure` получал от
  `engine.measureText` пару `[ширина, высота]` и прогонял её через `num()` —
  выходило `NaN → 0`, из-за чего `wrapDialogText` считал, что любая строка
  помещается, и реплики уезжали за панель. Форма ответа теперь разбирается
  в одном месте (`measureTextWidth`), у `$.dialog` запасной путь тоже.
- **Тесты**: `tests/js/timeline_test.mjs` — 24 проверки логики модуля: порядок
  битов, паузы, выборы и флаги, ветки `if/else`, метки внутри веток, акценты,
  тряска, концовки, авто-режим, тема панели диалога, состояние прогона.
- **Ассеты**: позы Руси-тян (обработаны из присланных картинок), пять
  локаций — класс и небо взяты кадрами из CC0-работ «Classroom 002» (Midnight68)
  и «40 game backgrounds» (rubberduck), остальные сгенерированы процедурно;
  лицензии — в [demos/assets/CREDITS.md](demos/assets/CREDITS.md).

### Изменено
- `docs/HIGH_LEVEL_API.md` — `$.timeline` в таблице подсистем после аудита.
- `docs/demos.md` — раздел про новеллу «Руси-тян» и строку в таблице сцен.
- `README.md` — демо «Руси-тян (ВН)» в списке демо-проекта.

## Оптимизация кадра `$`: весь план аудита (P0, P1 и остаток §5)

### Изменено
- **Внедрён P0 из `docs/HIGH_LEVEL_API_PERF.md`** — восемь правок, снимающих
  паразитную работу JS-слоя. Замеры — стенд `tools/bench_highlevel.py`
  (`--repeat 3`, медиана, Debug, та же машина), миллисекунды JS на кадр при
  бюджете 60 FPS 16,7 мс:

  | Сцена | До | После |
  |---|---:|---:|
  | пустая сцена | 0,39 | 0,25 |
  | 1000 статических спрайтов | 39,11 | 12,84 |
  | 1000 динамических тел (Box2D) | 40,61 | 12,87 |
  | 1000 узлов + `$('.mob').each()` каждый кадр | 55,80 | 13,80 |
  | 1000 узлов + один `$('#id')` за кадр | 54,77 | 12,93 |
  | 1000 твинов | 48,21 | 21,80 |
  | 1000 ui-узлов | 33,40 | 10,67 |
  | тайлмап на 5670 тайлов | 14,80 | 14,66 |

  Штатный платформер из `game/` (169 узлов, код игры не менялся): JS-цена кадра
  **65,4 → 3,1 мс**, из них код самой игры 55–58 → 0,5 мс.

  Вторая часть плана (P1) добавила к этому: 1000 спрайтов 12,84 → **8,97 мс**,
  `$('.mob')` в кадре 13,80 → **9,80**, твины 21,80 → **17,57**, тайлмап
  14,66 → **13,35**, пустая сцена 0,25 → **0,18**. Итог против аудита —
  39,11 → 8,97 мс на 1000 спрайтов (в 4,4 раза).

- **P1: сборка батча разгружена** (`src/highlevel/render.js`): список узлов мира
  переиспользуется, компараторы сортировки подняты на уровень модуля, а
  сортировка пропускается, если состав реестра не менялся и массив всё ещё
  неубывающий (проверка O(N) вместо O(N log N)); встроенные теги получают
  переиспользуемый прямоугольник вместо объекта `{x,y,w,h}` на узел;
  `blendId` кэширует режим на одно имя вместо `Map.get` по строке на каждый
  спрайт; список ui-узлов кэширован на версию реестра; обход по индексу.
- **P1: ленивые контейнеры узла** (`core.js`): `listeners`, `data_store` и
  `tags_extra` создаются при первой записи (`node.dataMap()` для хранилища),
  `classes` остался жадным — его читают селекторы в горячем цикле.
- **Обход без обёртки** (`core.js`, `api.js`): `.each((i, el))` остался прежним
  (в `el` обёртка), добавлен `.eachNode((i, node))` — колбэк получает сам узел.
  Все **97 цепных методов ядра** перешли на `eachNode`, поэтому
  `$('.enemy').damage(10)` больше не создаёт обёртку на узел; на 1000 узлов это
  ≈1,3 мс логики кадра (сцены стенда `query` / `chain` / `fast`). `each` и
  `eachNode` объявлены в классе `Wrapper` в ядре — их видят и модули-подсистемы,
  и юнит-тесты qjs без `api.js`. Кэш обёртки в узле не делается сознательно:
  поле `_wrapper` замыкает цикл «узел → обёртка → узел» и ломает
  `JSON.stringify` узла (агент, `$.store`).
- **`$.batch(fn)`** (`core.js`, `api.js`): массовый спавн и удаление одним
  вызовом. Внутри пакета `destroy()` и возврат в пул только помечают узел, а
  реестр чистится одной компактификацией — K удалений стоят O(K + N) вместо
  O(K·N); вложенные пакеты дают одну уборку. Селекторы и списки отрисовки не
  находят помеченные узлы. Замер: 500 спавнов + 500 удалений за кадр при 5000
  узлах — 153,8 → **117,2 мс** кадра (логика 96,6 → 60,4).
- **Пул переиспользует тело** (`pool.js`, `src/physics.c/h`, `src/script.c`):
  на `release` тело не уничтожается, а выключается (`b2Body_Disable`), на
  `spawn` включается обратно — вместо `destroyBody` + `createBody` на каждый
  выстрел. Новые биндинги `engine.setBodyEnabled(body, on)` и
  `engine.bodyEnabled(body)`.
- **Стенд** (`tests/fixtures/bench`, `tools/bench_highlevel.py`): новые сцены
  `chain` (цепной метод ядра), `fast` (`.eachNode`), `churn` и `batch` (пачка
  спавна/удаления за кадр) — пункты 12, 14 и 15 стали измеримыми; в сцене
  `query` исправлен колбэк `.each((el) => …)` → `.each((i, el) => …)` (`el` был
  индексом, и сцена ничего не двигала).
- **Демки**: `arena` (отжившие трассеры), `physics` (снос/постройка уровня,
  пачки ящиков) и `shooter_witch` (гибель зомби) ходят через `$.batch`;
  примеры `.each(e => …)` в `docs/HIGH_LEVEL_API.md` и `docs/ARCHITECTURE.md`
  исправлены на рабочие `(i, e)`.
- **P1: мелочи кадра**: `Array.from(machines)` в `state.js` → переиспользуемый
  массив; `ctx.nodes.indexOf` в шаге тайлмапа → флаг `node.in_registry`;
  `rectOf` в триггерах пишет в два переиспользуемых прямоугольника;
  `state.target` в акустике переиспользуется; `engine.contacts()` отдаёт
  `JS_NULL`, когда событий нет (пустой массив в C на каждый кадр); ранние
  выходы `tickEffects` (счётчик активных эффектов) и `tickI18n` (счётчик узлов
  с `attrs.tr`).

- **`worldEvents` без `Map` по числовому ключу** (`src/highlevel/world.js`):
  прошлые `hp`/`visible` узла хранятся в его же полях `_hp_seen`/`_vis_seen`.
  Числовой ключ в `Map` в QuickJS стоит ≈6,2 мкс, и четыре такие операции на
  узел съедали 20 мс кадра из 38; карты прошлых значений и их ленивая чистка
  удалены — данные умирают вместе с узлом.
- **Селекторы компилируются один раз на вызов** (`src/highlevel/core.js`):
  строка разбирается в замыкание-предикат (`compileSelector`, кэш на 512 строк),
  а не пятью регулярками **на каждом узле**; у `'#id'` — быстрый путь через
  `ctx.byId`; `Set` для уникализации создаётся только для селекторов с запятой.
  Один `$('#mob42')` при 1000 узлах: 14,2 → ≈0,01 мс; `$('.mob')`: 15,4 → ≈0,4 мс.
  `registerSelector` сбрасывает кэш разобранных селекторов.
- **Версия реестра и сводки подсистем** (`core.js`: `touchRegistry()`,
  `registrySummary()`, `countUiNodes()`): подсистема выходит на первой строке,
  если её узлов в мире нет, а сводка пересчитывается только при изменении
  реестра. Ранние выходы получили `tickWidgets`, `$.ui._tick`, `tickTriggers`,
  `tickLayers`, `tickParticles`, `tickTilemap`, `tickAnim`, `animateSprites` и
  `applyControls` — вместо ≈20 полных проходов по `ctx.nodes` за кадр.
  Контракт для авторов подсистем — `docs/highlevel/_CONTRACT.md` §2.
- **`collectCounters()` убран из кадра** (`pool.js`): снимок считался каждый
  кадр и клался в `ctx.counters`, который никто не читал; `$.debug.counters()`
  считает по запросу, как и раньше.
- **`emit`/`dispatchGlobal` выходят рано** (`core.js`, `api.js`): если
  глобальных подписок нет, объект события, три обёртки `$('*')` и строки
  `'entity:…'` не строятся.
- **Профайлер подсистем выключен по умолчанию и больше не врёт** (`api.js`,
  `debug.js`): метка ставится ПЕРЕД своим отрезком, поэтому ключ отчёта —
  это имя измеренного кода (раньше отчёт был сдвинут на одну подсистему:
  «анимация» мерила `tickAnimPlayer`, «акустика» — `$.ui._tick`). Отрезок кода
  игры переименован `«окно»` → `«логика игры»`. Включается
  `$.debug.profiler.on(true)`, состояние — `$.debug.profiler.isOn()`.
- **`tickWindow`** не читает состояние окна (6 вызовов C за кадр), пока на
  события окна никто не подписан; снимок для сравнения берётся в момент
  подписки, поэтому ложных `resize`/`focus` на первом кадре нет.
- **`destroy()` чистит `ctx.byId`** (`core.js`) — быстрый путь поиска по id не
  отдаёт удалённый узел; раньше запись жила до ленивого свипа в
  `prefab.js`/`save.js`/`scene.js`.

### Проверено
- `python3 tools/run_tests.py` — 34 теста, ok 34, fail 0, skip 0.
- `tests/js/*_test.mjs` (44 файла, qjs) — зелёные; тест кадрового шага пула
  обновлён под новое поведение (`tickPool` больше не пишет `ctx.counters`).
- Строгий A/B: эталонный и оптимизированный бинарники собраны из одного дерева
  и прогнаны перекрёстно (`--binary`, `--repeat 3`).

## Проверка движка и высокоуровневого API, свет в стиле Candle, новые подсистемы

### Добавлено
- **Свет в стиле Candle** (`src/highlevel/render.js`): тени внутри `<light>`
  (`.shadows(true)` — лучи из центра, каждый упирается в препятствие, по этим
  расстояниям строится веер: градиент мягкий, кромка тени резкая), конус
  (`.cone(deg, soft)`, направление — угол узла), мерцание
  (`.flicker(amount, speed)`), площадной источник `<lightarea>` (несколько
  точек вдоль полосы, у каждой свой контур тени) и туман — узел `<fog>` и
  экранный слой `$.gfx.fog({...})`. Реестр препятствий:
  `$.gfx.light.occluders/addOccluders/clearOccluders/count/segments/tiles/
  polygon/debug`, у узла — `.occluders([...])` и `.punch(true)` (свет поверх
  тумана). Документация — `docs/highlevel/render.md` §3.0.
- **GPU-время в профайлере и таблица зон в оверлее F1**: в SDL3 нет
  timestamp-запросов у SDL_GPU (проверено на 3.4.16 и main), поэтому кадр
  меряется по fence — от `SubmitGPUCommandBufferAndAcquireFence` до сигнала,
  опрос в отдельном потоке, выборка со сдвигом 1–2 кадра, кадр не блокируется.
  Строка «GPU: кадр» попадает в `r2d_prof_rows()`, в окно F1 (таблица «зона /
  среднее / пик / доля %», итог кадра, неучтённый остаток, кнопка сброса) и в
  `engine.profile()` (`gpu_ms`, `gpu_available`, `gpu_frames`, `rows[].gpu`).
  Без поддержки — «н/д» без ассертов.
- **Новые подсистемы `$`** (каждая — свой файл `src/highlevel/<имя>.js` и своя
  документация `docs/highlevel/<имя>.md`): `$.save` (слоты, версии, миграции,
  автосейв, экспорт строкой), `$.resource` (реестр ресурсов с ленивой загрузкой
  и счётчиком ссылок), `$.math`, `$.random` (детерминированный ГПСЧ и шум),
  `$.grid`, `$.csv` (+ безопасный JSON), `$.signal`, `$.state` (FSM, методы
  узла `.fsm()`/`.fsmSend()`), `$.flow`, `$.anim.player` (таймлайны, события,
  микширование клипов), `$.dialog`, `$.screen`, `$.font`.
- **Русские имена API** (`src/highlevel/ru.js`, `$.ru`): русские теги, атрибуты
  конструктора, методы узлов и пространства имён — ссылками на существующие
  (`$.мир === $.world`, `.цвет()` — та же функция, что `.color()`). Узел
  создаётся с каноническим тегом, поэтому отрисовка, селекторы и агентский
  снимок видят обычный `<light>`. Свои псевдонимы — `$.aliasTag('камень',
  'wall')`. Документация — `docs/highlevel/ru.md`.
- **Аудит производительности `$`** — `docs/HIGH_LEVEL_API_PERF.md`: замеры зон
  кадра на стенде `tests/fixtures/bench/` (1000 узлов = 38,5 мс JS при бюджете
  16,7 мс; GPU и Box2D при этом свободны), разбор причин (`worldEvents` — 20 мс
  из-за `Map` по числовому ключу в QuickJS, селекторы — O(N) на вызов с разбором
  строки на каждом узле, ~20 полных проходов по реестру за кадр, аллокации
  обёрток) и приоритизированный план правок с оценкой эффекта (38,5 → 6–8 мс).
  Отдельно измерена штатная игра: платформер из `game/` тратит 55 мс кадра на
  169 узлах, потому что `update` сцены зовёт `$('#hero')`, `$('.walker')` и
  `distanceTo('#hero')` внутри `each` — быстрый путь для `#id` и компиляция
  селектора убирают это без правок в игре.
  Там же — проверка полноты API: 138 из 168 биндингов `engine.*` обёрнуто,
  перечислено, что осталось за бортом. Инструмент — `tools/bench_highlevel.py`
  (агентский режим, `--fixed-dt`, замеры не зависят от vsync), тест —
  `tests/agent/highlevel_perf_test.py`.

### Исправлено
- **`$.fs.remove()` врал об успехе**: `SDL_RemovePath` в SDL 3.4.16 сообщает
  успех и для несуществующего пути (проверено отдельной C-пробой: missing →
  `true`, ошибка только на запрет доступа), поэтому `$.fs.remove('нет-файла')`
  возвращал `true`, а `$.save.remove(слот)` «удалял» пустой слот. Теперь
  существование проверяется до удаления — «удалил» и «и так нет» различимы.
- **Первый пример справочника падал**: `.speed(250)` не существовал как метод
  обёртки (только атрибут конструктора) — добавлен.
- **Событие `'collision'` из документации не срабатывало**: движок шлёт
  `'collide'` — имена-псевдонимы (`collision`/`contact` → `collide`,
  `separation` → `separate`) приведены в `core.js`.
- **Умолчания скорости тегов не доходили до управления**: `<enemy>` с
  `.controls()` ехал 150 вместо 90 — `TAGS.speed` теперь применяется в
  конструкторе узла.
- **`$.pool.tickPool()` и `$.input.rumble()` отсутствовали**, хотя упомянуты в
  документации: первый выставлен на пространстве имён, второй стал честной
  заглушкой с одним предупреждением (движок не пробрасывает
  `SDL_RumbleGamepad`).
- **`build_test` валился на macOS**: тест полагался на платформенное умолчание
  шифрования груза (на macOS оно выключено — файл переподписывают `codesign`).
  Теперь гарантия проверяется явным `--encrypt`, а умолчание — отдельной
  проверкой с учётом платформы.
- **Примеры в документации, которые не собирались**: Promise-цепочки
  `rotateTo().scaleTo().fadeTo()` и `$.fn.flashAndDie`, `$('<label>')` вместо
  `<ui.label>`, `t.chain().interval().callback()`, `$.attr()`, `EASES`,
  `$('<weapon>')`, `.attr('x')` против `.pos()`, `$.world.count(sel)`,
  потолок `max_particles`, `gap` у `<ui.scroll>`.
- **Список занятых имён в `docs/highlevel/_CONTRACT.md` отставал на 86 имён** —
  перевыпущен с живого движка (227 имён) и снабжён командой для обновления.

### Проверено
- `cmake --build build -j8` — без новых ошибок; 5 C-тестов (`json`, `crypto`,
  `payload`, `reverb`, `profile`) и 43 qjs-теста подсистем — зелёные.
- Новые агентские тесты: `highlevel_light_test` (тени/конус/площадной свет/
  туман — по пикселям двух скриншотов), `highlevel_ru_test` (все 32 русских
  тега), `highlevel_docsapi_test` (обещания справочника), плюс тесты подсистем.
- Аудит `docs/HIGH_LEVEL_API.md` ↔ `src/highlevel/*.js`: 30 тегов и 217 цепных
  методов сверены с рантаймом; расхождения вынесены в отчёт и исправлены
  (см. «Исправлено»).

## Экран загрузки в высокоуровневом API

- `$.loading.show/progress/label/title/hide/visible/value` и `$.loading.run(steps, done)` —
  полноэкранная панель с полосой прогресса; шаги выполняются по одному за кадр
  (`src/highlevel/loading.js`, документация — `docs/highlevel/loading.md`).
- Демо «Ведьма» использует его на переходе меню → игра.

## Меню и сцены демо «Ведьма»

- Меню — отдельная сцена `witch_menu` (арт, название, Играть/Настройки/Выход,
  музыка `menu_whimsy.mp3`), игра — сцена `shooter_witch` (трек `zombie_plinko.mp3`).
  Переход идёт через `$.scene.load`, в бою Esc или P возвращает в меню.
- Иконки пунктов меню вынесены отдельными метками (`$.ui.setIcon`) — строка
  больше не «ездит» относительно центра кнопки.


Все заметные изменения проекта Russiano2D.
Формат — [Keep a Changelog](https://keepachangelog.com/ru/1.1.0/),
версии — [семантическое версионирование](https://semver.org/lang/ru/).

## [Unreleased]

Раздел для изменений, которые уже лежат в рабочем дереве, но на момент
составления файла ещё не попали в историю коммитов. При выпуске версии
записи переезжают в соответствующий раздел.

### Добавлено
- **Профайлер кадра в движке** (`src/profile.c`, `$.debug.profile()`): зоны
  измеряются монотонным счётчиком SDL — JS-логика, сборка батча, физика,
  ожидание swapchain, загрузка VB/IB, draw-команды, интерфейс, прочее; плюс
  `frame_ms`, `unaccounted_ms` (реальное время минус сумма зон) и пики за
  120 кадров. Внутрикадровые замеры на JS переведены на новый `engine.now()`
  (монотонные миллисекунды): `engine.time` идёт шагами по кадру и для этого
  не годится. Подсистемы `$` размечены и видны в `$.debug.profiler.report()`.
- **DOOM-стайл HUD** в демо «Ведьма»: нижняя панель с лицом героини (лист
  4 выражения × 6 состояний здоровья), числом и полосой HP, иконкой и
  названием оружия, полосой опыта и счётом.

### Исправлено
- **Подсистемы `$` тикали дважды за кадр**: при разметке профайлера блок
  тиков был вставлен второй копией — теперь один (это стоило ~6 мс на кадр).
- **Кровь в демо лилась непрерывно**: у эмиттеров не было `one_shot`/`rate: 0`,
  восемь эмиттеров сыпали по 58 частиц в секунду каждый ещё до первого
  выстрела — теперь только залпом.
- **Мировой слой рисовался в экранных координатах**: `$.fx.*` (ленты, молнии,
  ударные волны, вспышки, поля сил) и `$.gfx.draw.*` передают координаты в
  мире, а батч движка принимает экранные — в итоге весь VFX уезжал на
  расстояние камеры: трассеры летели «не из персонажа», а вспышки и пульсы
  появлялись в углу экрана. Добавлен перевод world → screen
  (`setView`, включается на время `_fxFlush` и внутри `$.gfx.draw.*`), плюс
  масштабирование толщин и радиусов. Демо `light` с полигонами видимости это
  же и лечило: свет больше не «ходит за камерой».
- **Режим смешивания `add` игнорировал альфу вершины**: факторы были
  `ONE, ONE`, поэтому полупрозрачное свечение, вспышка или трассер били в
  полную яркость — свет фонарей превращался в белые круги, а альфа вершин в
  аддитивном режиме не работала вообще. Теперь `SRC_ALPHA, ONE` (и
  `ZERO, ONE` для альфа-канала): альфа честно ослабляет вклад.

### Добавлено
- **Мягкое свечение как примитив движка**: `$.gfx.draw.glow(x, y, radius, color,
  { segments, rings, falloff, inner, blend })` — радиальный градиент с цветом и
  альфой на каждой вершине. Узел `<light>` переписан на него: параметры
  `radius`, `intensity`, `color`, `falloff`, `inner`, `segments`, `rings` и
  `.blend('add')`; градиент гладкий на любом радиусе (раньше на больших
  радиусах были видны кольца).
- **Релизная сборка** (`build-release`, `-DCMAKE_BUILD_TYPE=Release`): демо в
  Debug шло 8 кадров/с, в Release — втрое быстрее.
- **Камерные пресеты пост-обработки** (`$.gfx.postPreset`): `adventure`
  (тёплый мультик), `forest_night`, `horror` (почти ч/б, зерно, кровь по
  краям), `bloodmoon`, `retro`, `noir`, `dream`. Переключение плавное
  (`{ ms }`), поверх пресета можно точечно менять поля через `$.gfx.post()`.
  В шейдер добавлены цветокоррекция (насыщенность, контраст, яркость, оттенок),
  постеризация и «кровавая» вигнетка.
- **Глушение звука в чаще** (`$.audio.obstacles`, `$.audio.damping`,
  `$.audio.densityAt`): каждое препятствие (дерево, колонна) рядом с линией
  «слушатель → источник» добавляет глухости и опускает срез фильтра — в
  плотном лесу выстрел звучит глухо, на поляне чисто. Материал `grass` для
  акустических зон под открытый воздух.
- **HUD демо «Ведьма»**: строка счётчика кадра (FPS, мс, спрайты, тела, звуки,
  трассеры, статистика VFX по `$.fx.stats()`), трассеры выстрелов рисуются от
  дула оружия (`muzzle` в описании оружия) и уходят под спрайт героя.
- **Демо «Ведьма» переделано в ночной лес**: земля из тайлсета с автотайлом
  тропы (террейн `path`), деревья из CC0-набора Kenney с коллизиями и тенями,
  фонари — единственный источник света (плюс слабая свеча игрока), волны зомби,
  опыт, карты апгрейдов, кровь и лужи. Ассеты собираются скриптом
  `tools/make_forest_assets.py` из исходников Kenney (RPG pack и RPG Urban
  pack, оба CC0), лицензии лежат рядом.
- **Суб-эмиттеры частиц** (`on_death`): когда частица умирает, из её точки бьёт
  залп другого эффекта — искры догорают в дым, дым оседает пеплом. Вложенный
  эмиттер один на родителя (не по узлу на частицу) и ровно одного уровня
  вложенности, чтобы не было бесконечной цепочки.
- **Пост-обработка кадра** (`$.gfx.post`): сцена рисуется в offscreen-текстуру,
  а на экран её накладывает полноэкранный проход `shaders/post.*` — свечение,
  вигнетка, хроматическая аберрация, зерно, скан-линии и линза (экранное
  искажение UV по полю `~1/r²`, основа «чёрной дыры» и взрывной волны).
  Интерфейс рисуется после обработки (`engine.markUI()`), поэтому HUD остаётся
  чистым. См. `docs/highlevel/render.md` §3.1.
- **VFX своими руками** (`$`-модуль `fx`, `src/highlevel/fx.js`): ленты и трассеры,
  молнии с ветвями, ударные волны, вспышки в точке, поля сил (аттрактор и вихрь)
  для частиц, hit-stop и готовый `$.fx.impact`. Никаких сторонних библиотек —
  всё рисуется батчем `$.gfx.push`. См. `docs/highlevel/fx.md`.
- **Демо «Ведьма»** (`demos/shooter_witch`): top-down шутер, который показывает
  акустику комнат (зал 20×20, кладовка 5×5, коридор), три оружия с разным pitch,
  «чёрную дыру» на полях сил, окклюзию звука за стеной и мягкий свет игрока.
- **Акустика помещений.** Реверберация (Freeverb, public domain) на последнем
  шаге микшера плюс модель комнат: `$.audio.zone(name, { rect, height,
  material })`, `$.audio.room(...)`, `$.audio.listener(...)`,
  `$.audio.acoustics(flag)`, `$.audio.occlusion(flag)`. Параметры считаются по
  формуле Сабина (RT60) и плавно едут между зонами, поэтому выстрел в комнате
  5×5 и в зале 20×20 звучит по-разному. См. `docs/highlevel/audiobus.md` §8.
- **Настоящие аудио-шины**: каждая шина `$.audio.bus(...)` заводит группу
  SDL_mixer (`MIX_CreateGroup`), каналы приписываются к ней
  (`MIX_SetTrackGroup`), а эффект шины обрабатывает пост-микс группы
  (`MIX_SetGroupPostMixCallback`) — то есть действует и на звуки, запущенные
  позже.
- **3D-позиция звука**: `$.audio.spatial('sdl')` отдаёт координаты источников
  SDL_mixer (`MIX_SetTrack3DPosition`); слушатель у него всегда в нуле, поэтому
  передаются координаты относительно слушателя. По умолчанию остаётся
  JS-панорама (`$.audio.spatial('js')`).
- **Pitch звука и музыки**: `$.sound.play(..., { pitch })`,
  `$.sound.music(..., { pitch })`, `$.sound.musicPitch(v)` —
  `MIX_SetTrackFrequencyRatio` в движке.
- **Окклюзия и живое позиционирование**: источник за стеной глушится фильтром,
  `$.sound.playAt` ведёт панораму и громкость, пока звук играет;
  `$.audio.listener(...)` принимает узел или селектор, а не только координаты.
- `$`-модуль `i18n`: словари и подстановка строк интерфейса.
- `$`-модуль `pool`: переиспользуемые объекты без мусора в кадре.
- `$`-модуль `triggers`: зоны-триггеры со входом, выходом и повторным срабатыванием.
- Юнит-тесты под `qjs`: `i18n_test.mjs`, `triggers_test.mjs`,
  `tween_test.mjs`, `input_deadzone_test.mjs`, `sprite_size_test.mjs`,
  `sound_test.mjs`, `color_test.mjs`, `scene_test.mjs`, `camera_test.mjs`,
  `window_test.mjs`, `ui_test.mjs`, `debug_test.mjs`, `ctor_attrs_test.mjs`
  (грабли конструктора узла: `{ src }`, `{ frames }`, чтение свойств через `.attr()`),
  `acoustics_test.mjs` (RT60, материалы, зоны), `fx_test.mjs` (времена жизни
  эффектов, лента за целью, поля сил, отсечение по камере).
- C-тест `r2d_reverb_test`: хвост реверберации затухает в маленькой комнате и
  держится в зале (это и есть разница «5×5 против 20×20»).
- C-тест `r2d_payload_test`: разбор контейнера груза под ASan/UBSan (двойное
  освобождение буфера и выход за границы на битом грузе).

### Добавлено
- **Профайлер кадра в движке** (`src/profile.c`, `$.debug.profile()`): зоны
  измеряются монотонным счётчиком SDL — JS-логика, сборка батча, физика,
  ожидание swapchain, загрузка VB/IB, draw-команды, интерфейс, прочее; плюс
  `frame_ms`, `unaccounted_ms` (реальное время минус сумма зон) и пики за
  120 кадров. Внутрикадровые замеры на JS переведены на новый `engine.now()`
  (монотонные миллисекунды): `engine.time` идёт шагами по кадру и для этого
  не годится. Подсистемы `$` размечены и видны в `$.debug.profiler.report()`.
- **DOOM-стайл HUD** в демо «Ведьма»: нижняя панель с лицом героини (лист
  4 выражения × 6 состояний здоровья), числом и полосой HP, иконкой и
  названием оружия, полосой опыта и счётом.

### Исправлено
- Мёртвая зона аналогового ввода в `$`-модуле `input`.
- Уточнения в расчёте времени и твинов (`time`, `tween`).
- `.sprite('картинка.png')` больше не оставляет узел 32×32: размер кадра
  запоминается при создании спрайта, и узел с шириной по умолчанию
  подхватывает размер текстуры (раньше `spriteSize()` всегда возвращал `[0,0]`).
- `$.sound.mute(false)` возвращает прежнюю громкость, а не жёстко 1.0:
  уровень, выставленный `$.sound.volume(...)`, больше не теряется.
- `.alpha()` снова действует на `ui.panel`, `ui.button`, `ui.image` и фон
  `ui.bar`: `packColor()` больше не отбрасывает альфу у цвета-числа.
- `$.scene.load(name, { keepUI: true })` сохраняет интерфейс и при переходе
  с затемнением — `_tick()` больше не затирает опции загрузки.
- Исключение в обработчике `$.window.on()` больше не валит кадр: в `fire()`
  вызывался несуществующий `ctx.reportError`, и собственный `catch` падал.
- `$.camera.follow(узел)` и `follow(обёртка)` работают, а не молча ничего не
  делают (раньше принимались только селектор и индекс).
- `$.layers.fadeTo()` уважает `$.time.pause()` и масштаб времени вместо
  `rawDelta()`.
- Счётчик `tweens` в `$.debug.stats()` и `$.debug.counters()` больше не 0.
- `$.ui.doc(path).unload()` убирает документ из кэша обёрток.
- `$.i18n` в режиме `auto` не держит уничтоженные узлы: `WeakSet` вместо `Set`.
- Груз игры: битый контейнер больше не освобождает буфер вызывающего
  (двойное освобождение кучи) и не читает за границей буфера из-за
  переполнения проверки `offset + size` в футере.
- `--screenshot`: автоматический снимок делается один раз, а не каждый кадр
  (раньше после `--screenshot-at` кадр снимался и записывался на каждом кадре).
- HTTP (встроенный сокетный бэкенд): chunked-ответ больше не обрезается по
  первому нулевому байту, разбор статуса не выходит за буфер, у ответа есть
  предел размера, а CR/LF в запросе отклоняются (request splitting).
- Эхо в `$.audio` больше не пишет за границу буфера на источниках с более
  чем двумя каналами (5.1): линия задержки индексируется по двум каналам.
- `russiano2d build`: переподпись на macOS идёт через `posix_spawn`, а не через
  `system()` — путь из `--out` больше не может выполнить команду оболочки.
- Курсор окна кэшируется (не течёт при частых сменах), логический размер окна
  обновляется при ресайзе, а слоты RmlUi-документов переиспользуются после
  `unload()` — UI больше не умирает после 64 циклов открыть/закрыть.
- Агентский протокол: команда длиннее 64 КиБ больше не разрезается на две
  (одна строка — один ответ), короткая запись ответа досылается до конца.
- Сборка с `-DR2D_ENABLE_IMGUI=OFF` снова линкуется, и без ImGui очередь
  текста очищается каждый кадр.
- Приведение `double` к `int` в JSON и манифесте проекта ограничивается по
  диапазону: `1e300` из команды агента больше не даёт UB.
- Разбор заданий QuickJS: исключение из асинхронного задания забирается и
  логируется, а не остаётся висеть в контексте.
- `$('<sprite>', { src: 'hero.png' })` грузит текстуру, как `.sprite()`:
  раньше `src` оседал в `attrs` и картинка молча не появлялась. То же для
  `{ frames: { src, cols, rows, cw, ch } }` — лист больше не теряется.
- `.attr('id')`, `.attr('hp')`, `.attr('x')` читают свойства узла, а не только
  `attrs` (раньше возвращали `undefined`, хотя `.attr('src')` работал).
  Также `.attr('class')`/`.attr('tag')` отдают добавленные метки.
- `.tag('friendly')` добавляет тег, а не класс: `.tag()` был псевдонимом
  `.addClass()`, хотя документирован как тег.
- `.sprite(path)` и `.frames({ src })` синхронизируют `attrs.src`, поэтому
  `.sprite('tile.png').region(...)` действительно вырезает область.
- `$.world.raycast` проходит сквозь сенсоры: зона-триггер больше не блокирует
  линию видимости и проверку «стою на земле» (Box2D v3 не исключает сенсоры
  сам — теперь они отсеиваются в колбэке луча; начальное перекрытие при этом
  игнорируется, как во встроенном `b2RayCastClosestFcn`, иначе `onFloor()` и
  `onWall()` ловили бы собственное тело узла).
- `$.world.raycast`/`raycastAll`/`lineOfSight` принимают точку и массивом
  `[x, y]` — как `$.sound.playAt` и `$.gfx.draw.*`. Раньше массив молча
  превращался в (0, 0), и луч уходил из угла мира.
- `engine.createBody(null)` и `engine.createJoint(null)` бросают TypeError
  вместо «успеха» с висящим в контексте исключением.
- Ошибка загрузки модуля (не встроен / не прочитан) доходит до JS: раньше
  описательное исключение тут же забиралось из контекста, и игрок видел
  исключение без значения. `last_error` при провале загрузки `$` больше не
  подменяется строкой «неизвестная ошибка».
- `russiano2d build --add <файл>` действительно добавляет файл; при
  переполнении списка файлов прочитанные данные освобождаются; рантайм
  QuickJS освобождается, если не удалось создать контекст.
- Мышь: кнопка вне диапазона (0, отрицательная, больше X2) больше не даёт
  undefined behavior в `SDL_BUTTON_MASK` и не читает чужой бит.
- GUI: дескрипторы файлов из груза отличаются явным набором объектов, а не
  чтением поля внутри чужого `FILE*` через `reinterpret_cast`; при горячей
  перезагрузке документы RmlUi снимаются вместе с JS-контекстом, поэтому
  старые слушатели не вызывают чужой обработчик.
- Утечки: пайплайны и сэмплер при неудачной инициализации рендера,
  transfer-буфер снимка при ошибке отправки командного буфера, `base_path`
  окна при завершении, расшифрованный груз в агентском режиме.
- `$.debug.profiler` копит статистику между кадрами: `start()` каждый кадр
  больше не обнуляет `total`/`calls`/`max`, поэтому `report()` показывает
  прогон целиком, а не последний кадр.
- `$.world.raycast(..., { ignore })` работает: раньше `query(...).toArray()`
  падал с TypeError (query возвращает массив), а теперь список игнорируемых
  тел уходит в движок, и луч ищет следующее препятствие за ними.
  `engine.raycast` принимает необязательный массив id тел для пропуска.
- HTTP: CMake действительно определяет `R2D_HTTP_WITH_CURL` — libcurl
  линковался, но не компилировался, поэтому `$.http` молча терял https и
  редиректы, обещанные в README.
- Длительность звука снова в секундах: `MIX_GetAudioDuration` отдаёт
  сэмпл-кадры, а не миллисекунды, поэтому файл на 74 с показывал 3274 с.
- Демо `light`, `bsp` и `shooter25d`: кнопки RmlUi снова работают —
  `$.ui.doc().on()` подписывает конкретный элемент, а не документ целиком,
  поэтому обработчики повешены на каждый id.
- Демо `shooter25d`: стрелки вверх/вниз больше не дают двойную скорость
  (их уже собирал `$.input.vec`), ЛКМ действительно стреляет, а подпись
  прицела стала `ui.label` и не уезжает вместе с камерой.
- Игра: касание врага наносит урон один раз за кадр, а не по 10 HP с каждого
  врага; в демо физики искры не превышают лимит.
- Тесты: `demos_test` проверяет слушателей кнопок RmlUi; убраны всегда-истинные
  проверки в `agent_protocol_test` и `highlevel_physics_test`; в CI job релиза
  windows-артефакт стал необязательной зависимостью.
- Тряска камеры, узлов и тайлов берёт случайные числа из отдельного
  seeded-генератора, а не из `Math.random()`: при `--seed` и `--fixed-dt`
  прогон снова даёт одинаковые кадры.
- `$.scene.load(name, { ms: 0 })` переключает сцену мгновенно: раньше ноль
  считался «значением по умолчанию» и тихо превращался в 300 мс.
- `$.pool`: свободные (предсозданные) узлы больше не держат физических тел —
  раньше каждый такой узел висел в мире в точке (0,0) и сталкивался, хотя его
  не было ни в `ctx.nodes`, ни в счётчиках.
- `$.tilemap.tileSize()` после первого рендера режет лист заново: вычисленные
  `cols`/`rows` больше не принимаются за явно заданные.
- `$.prefab.save()` не падает на циклическом массиве в `attrs`/`data_store`:
  `sanitize()` охраняет и массивы, а не только объекты.
- `$.anim.stateMachine()` при повторном объявлении снимает слушателей прошлой
  машины (раньше обработчики копились), а `eventsBetween()` возвращает все
  повторы события, попавшие в интервал, — при лаге кадра события циклов
  больше не теряются.
- Циклический `extends` у тем `$.ui` (a→b→a) больше не уводит `resolveTheme`
  в бесконечную рекурсию: цикл рвётся пустой темой и предупреждением.
- `$.tween`: `.delay()` действует и на мгновенный property-твинер — значение
  откатывается и применяется после задержки, а не сразу.

## [0.1.0] — 2026-10-05

Первый публичный релиз движка: ядро на C11, игровая логика на JavaScript,
точка входа — объект `$`. Репозиторий и релизы — на hub.mos.ru. Лицензия авторская: свободное
использование, изменение и распространение (см. `LICENSE`).

### Добавлено
- **Ядро движка.** Окно, ввод, тайминги и GPU-устройство на SDL3 + SDL_GPU
  (Vulkan / Metal / DirectX 12); пакетная отрисовка спрайтов и текстур
  (`src/render.c`), текстовые подсказки поверх сцены (`src/text.c`).
- **Скриптовый слой.** QuickJS-ng 0.10, ES2023 и ES-модули, объект `engine`
  для низкоуровневых вызовов; hot reload `.js` без перезапуска.
- **Высокоуровневое API `$`.** Одна точка входа для игровой логики;
  высокоуровневые модули встраиваются в бинарник и работают и в релизной
  сборке, и без единого `.js` рядом.
- **Физика.** Обёртка над Box2D v3.1: тела, формы, лучи и запросы
  (`src/physics.c`).
- **2D BSP-дерево.** Своя реализация упорядочивания отрезков без z-буфера
  (`src/bsp.c`), демо на произвольной геометрии.
- **2D-свет и тени.** Полигоны видимости на `trylock/visibility` с C-обёрткой
  (`src/light.cpp`), API света и треугольников.
- **Звук и музыка.** SDL3_mixer 3.2: WAV, OGG и MP3, каналы, петли,
  затухания и стриминг музыки.
- **Игровой GUI.** RmlUi 6.3: HUD, меню и инвентарь на HTML/CSS-подобной
  разметке.
- **Отладочный оверлей.** Dear ImGui (ветка docking) — включается по F1.
- **Иконки.** Шрифт Material Design Icons (2235 иконок) встроен в бинарник,
  доступен из скриптов и разметки.
- **Протокол агента.** Режим `--agent`: команды JSON на stdin, ответы на
  stdout; виртуальный ввод, `eval`, снимок состояния, скриншоты, перезапуск.
  Клиент — `tools/agent_client.py`, описание — `docs/AGENT_API.md`.
- **Сборка игры в один файл.** Команда `build` компилирует скрипты в байткод
  QuickJS, упаковывает проект в контейнер и шифрует груз
  ChaCha20-Poly1305 (RFC 8439); режимы `--append` и `--relink`,
  переподпись на macOS, защита от подмены. См. `docs/BUILD.md`.
- **Аудит `$` и восемь подсистем.** Анимация, TileMap, частицы, навигация,
  prefab, аудио-шины, слои и UI-контролы — с документацией и тестами
  (`docs/highlevel/`, `tests/js/`).
- **Демо.** Меню-лаунчер и семь демо: `gallery`, `platformer`, `physics`,
  `bsp`, `light`, `arena`, `shooter25d` (`demos/`, `docs/demos.md`).
- **Тесты.** Агентские тесты `tests/agent/*_test.py` под раннером
  `tools/run_tests.py` (исходы `ok` / `fail` / `skip`), C-тесты разбора JSON и
  ChaCha20-Poly1305 с санитайзерами, юнит-тесты логики `$` под `qjs`.
- **Документация.** `README.md`, `docs/internal/NATIVE.md`, `docs/HIGH_LEVEL_API.md`,
  `docs/AGENT_API.md`, `docs/BUILD.md`, `docs/GAP_ANALYSIS.md`,
  туториалы по платформеру и меню.

### Изменено
- Движок доведён до рабочего состояния: устранены падения на командах агента,
  добавлены недостающие проверки и документация.

### Добавлено
- **Профайлер кадра в движке** (`src/profile.c`, `$.debug.profile()`): зоны
  измеряются монотонным счётчиком SDL — JS-логика, сборка батча, физика,
  ожидание swapchain, загрузка VB/IB, draw-команды, интерфейс, прочее; плюс
  `frame_ms`, `unaccounted_ms` (реальное время минус сумма зон) и пики за
  120 кадров. Внутрикадровые замеры на JS переведены на новый `engine.now()`
  (монотонные миллисекунды): `engine.time` идёт шагами по кадру и для этого
  не годится. Подсистемы `$` размечены и видны в `$.debug.profiler.report()`.
- **DOOM-стайл HUD** в демо «Ведьма»: нижняя панель с лицом героини (лист
  4 выражения × 6 состояний здоровья), числом и полосой HP, иконкой и
  названием оружия, полосой опыта и счётом.

### Исправлено
- Z-тест билбордов относительно стен в демо `shooter25d`.

[Unreleased]: https://hub.mos.ru/dem4ev48/russiano2d/-/compare/v0.1.0...HEAD
[0.1.0]: https://hub.mos.ru/dem4ev48/russiano2d/-/releases/v0.1.0

- Re2DSprite v2: атлас 4096×4096 с ID/глубиной/покрытием/координатами;
  мимика, тело 128×128, подмены частей, hot reload PNG и доноров,
  процедурная ходьба/бег, плечи/колени, интерактивное демо Руси-тян
  в костюмах горничной, купальнике и полиции. v1 сохранён.

- Re2DSprite: уменьшено разрастание тёмных контуров при дискретной проекции;
  выборка представительного texel блока сохраняет исходную палитру,
  совпадающие отсчёты выбираются устойчиво без предпочтения тёмного цвета.
  Увеличены пропорции головы в режиме тела.

- Re2DSprite: opt-in anime projection with continuous atlas patches, supersampled coverage, linear filtering and anime mascot material sources; demo defaults to anime, pixel/v1 remain compatible.

- Re2DSprite anatomy prototype: sculpted anime nose/lips/chin in PNG maps, one-sided facial details, torso/limb volumes and consistent shoulder anchors for profile turns.

- Re2DSprite: непрерывные полосы материала горничной, более спокойные волосы,
  отдельные белые банты и изогнутый хвост; регрессия целостности карт одежды.

- Re2DSprite: восстановлены нижняя челюсть и подбородок; проверка длины
  поверхности кожи ниже рта в готовом атласе.
